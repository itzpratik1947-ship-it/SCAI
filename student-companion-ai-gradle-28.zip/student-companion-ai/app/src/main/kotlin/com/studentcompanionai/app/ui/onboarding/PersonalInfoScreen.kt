
package com.studentcompanionai.app.ui.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll

import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.SelectableDates

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue

import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import androidx.compose.material3.ExperimentalMaterial3Api

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalInfoScreen(
    initialName: String = "",
    initialDateOfBirth: String = "",
    onBack: () -> Unit,
    onContinue: (
        preferredName: String,
        dateOfBirth: String
    ) -> Unit
) {

    var preferredName by rememberSaveable {
        mutableStateOf(initialName)
    }

    var dateOfBirth by rememberSaveable {
        mutableStateOf(initialDateOfBirth)
    }

    var showDatePicker by rememberSaveable {
        mutableStateOf(false)
    }

    val colors = MaterialTheme.colorScheme

    // -----------------------------------------
    // DATE PICKER STATE
    // -----------------------------------------

    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = parseDateOfBirth(dateOfBirth),
        selectableDates = object : SelectableDates {

            override fun isSelectableDate(
                utcTimeMillis: Long
            ): Boolean {

                return utcTimeMillis <= getTodayUtcMillis()
            }

            override fun isSelectableYear(
                year: Int
            ): Boolean {

                val currentYear = Calendar.getInstance()
                    .get(Calendar.YEAR)

                return year <= currentYear
            }
        }
    )


    // =========================================
    // PERSONAL INFORMATION SCREEN
    // =========================================

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {

        TextButton(
            onClick = onBack
        ) {
            Text("← Back")
        }

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        Text(
            text = "Let's get to know you",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = colors.onBackground
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Text(
            text = "First, tell us a little about yourself. This helps us personalise your learning experience.",
            style = MaterialTheme.typography.bodyLarge,
            color = colors.onSurfaceVariant
        )

        Spacer(
            modifier = Modifier.height(28.dp)
        )


        // -------------------------------------
        // PREFERRED NAME
        // -------------------------------------

        Text(
            text = "What should we call you?",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(
            modifier = Modifier.height(10.dp)
        )

        OutlinedTextField(
            value = preferredName,
            onValueChange = {
                preferredName = it
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Your preferred name")
            },
            placeholder = {
                Text("Enter your name")
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp)
        )

        Spacer(
            modifier = Modifier.height(28.dp)
        )


        // -------------------------------------
        // DATE OF BIRTH
        // -------------------------------------

        Text(
            text = "When were you born?",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(
            modifier = Modifier.height(6.dp)
        )

        Text(
            text = "This helps us understand your learning stage and personalise your experience.",
            style = MaterialTheme.typography.bodyMedium,
            color = colors.onSurfaceVariant
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = colors.surfaceVariant.copy(alpha = 0.45f),
            onClick = {
                showDatePicker = true
            }
        ) {

            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {

                Text(
                    text = "Date of Birth",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.onSurfaceVariant
                )

                Text(
                    text = dateOfBirth.takeIf {
                        it.isNotBlank()
                    }?.let {
                        formatDateOfBirth(it)
                    } ?: "Select your date of birth",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (dateOfBirth.isNotBlank()) {
                        FontWeight.SemiBold
                    } else {
                        FontWeight.Normal
                    },
                    color = if (dateOfBirth.isNotBlank()) {
                        colors.onSurface
                    } else {
                        colors.onSurfaceVariant
                    }
                )
            }
        }

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        TextButton(
            onClick = {
                showDatePicker = true
            }
        ) {
            Text("Open calendar")
        }

        Spacer(
            modifier = Modifier.height(32.dp)
        )


        // -------------------------------------
        // CONTINUE
        // -------------------------------------

        Button(
            onClick = {

                onContinue(
                    preferredName.trim(),
                    dateOfBirth
                )
            },
            enabled = preferredName.isNotBlank() &&
                dateOfBirth.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {

            Text(
                text = "Continue",
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        Text(
            text = "You can update these details later in your profile.",
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant
        )
    }


    // =========================================
    // CALENDAR DIALOG
    // =========================================

    if (showDatePicker) {

        DatePickerDialog(

            onDismissRequest = {
                showDatePicker = false
            },

            confirmButton = {

                TextButton(
                    onClick = {

                        datePickerState.selectedDateMillis?.let {
                            dateOfBirth = formatDateOfBirthForStorage(it)
                        }

                        showDatePicker = false
                    },
                    enabled = datePickerState.selectedDateMillis != null
                ) {
                    Text("Confirm")
                }
            },

            dismissButton = {

                TextButton(
                    onClick = {
                        showDatePicker = false
                    }
                ) {
                    Text("Cancel")
                }
            }

        ) {

            DatePicker(
                state = datePickerState,
                title = {
                    Text(" ")
                },
                headline = {
                    DatePickerDefaults.DatePickerHeadline(
                        selectedDateMillis = datePickerState.selectedDateMillis,
                        displayMode = datePickerState.displayMode,
                        dateFormatter = DatePickerDefaults.dateFormatter()
                    )
                },
                showModeToggle = true
            )
        }
    }
}


// =============================================
// DATE HELPERS
// =============================================

private fun getTodayUtcMillis(): Long {

    val calendar = Calendar.getInstance(
        TimeZone.getTimeZone("UTC")
    )

    calendar.set(
        Calendar.HOUR_OF_DAY,
        0
    )

    calendar.set(
        Calendar.MINUTE,
        0
    )

    calendar.set(
        Calendar.SECOND,
        0
    )

    calendar.set(
        Calendar.MILLISECOND,
        0
    )

    return calendar.timeInMillis
}


private fun parseDateOfBirth(
    value: String
): Long? {

    if (value.isBlank()) return null

    return try {

        val formatter = SimpleDateFormat(
            "yyyy-MM-dd",
            Locale.US
        ).apply {
            timeZone = TimeZone.getTimeZone("UTC")
            isLenient = false
        }

        formatter.parse(value)?.time

    } catch (_: Exception) {
        null
    }
}


private fun formatDateOfBirthForStorage(
    millis: Long
): String {

    return SimpleDateFormat(
        "yyyy-MM-dd",
        Locale.US
    ).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date(millis))
}


private fun formatDateOfBirth(
    value: String
): String {

    return try {

        val millis = parseDateOfBirth(value)
            ?: return value

        SimpleDateFormat(
            "dd MMMM yyyy",
            Locale.getDefault()
        ).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date(millis))

    } catch (_: Exception) {
        value
    }
}
