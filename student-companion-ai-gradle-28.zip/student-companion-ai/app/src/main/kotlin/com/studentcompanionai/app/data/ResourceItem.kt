
package com.studentcompanionai.app.data

data class ResourceItem(
    val id: String,
    val title: String,
    val url: String,
    val description: String = "",
    val type: ResourceType = ResourceType.WEBSITE,
    val provider: String = "",
    val thumbnailUrl: String = "",
    val author: String = "",
    val languageCode: String = "en",
    val subject: String = "",
    val topic: String = "",
    val difficulty: String = "",
    val durationSeconds: Long = 0L,
    val isFree: Boolean = false,
    val publishedAt: String = "",
    val retrievedAt: Long = System.currentTimeMillis(),
    val relevanceScore: Double = 0.0
) {
    val isVideo: Boolean
        get() = type == ResourceType.VIDEO

    val hasValidUrl: Boolean
        get() = url.startsWith("https://", true) ||
                url.startsWith("http://", true)
}

enum class ResourceType {
    VIDEO,
    WEBSITE,
    ARTICLE,
    DOCUMENTATION
}

enum class ResourceLanguage(
    val code: String,
    val displayName: String
) {
    ENGLISH("en", "English"),
    HINDI("hi", "Hindi")
}

data class SavedResource(
    val resource: ResourceItem,
    val savedAt: Long = System.currentTimeMillis(),
    val lastOpenedAt: Long = 0L,
    val openCount: Int = 0,
    val linkedPlanId: String? = null,
    val linkedActivityId: String? = null
)

// --------------------------------------------------
// RESOURCE CONVERSION
// --------------------------------------------------

/**
 * Converts a discovered resource into the existing
 * LearningResource model used by LearningPlan.
 *
 * This allows resources to be attached directly to
 * learning activities and StudyTask objects.
 */
fun ResourceItem.toLearningResource(
    activityTopic: String = "",
    activityMinutes: Int = 0
): LearningResource {

    val learningResourceType = when (type) {
        ResourceType.VIDEO ->
            LearningResourceType.VIDEO

        ResourceType.WEBSITE ->
            LearningResourceType.WEBSITE

        ResourceType.ARTICLE ->
            LearningResourceType.ARTICLE

        ResourceType.DOCUMENTATION ->
            LearningResourceType.DOCUMENT
    }

    val durationMinutes = if (durationSeconds > 0L) {
        ((durationSeconds + 59L) / 60L)
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()
    } else {
        0
    }

    return LearningResource(
        id = id,
        title = title,
        url = url,
        type = learningResourceType,
        provider = provider,
        description = description,
        estimatedMinutes = durationMinutes,
        allocatedMinutes = 0,
        topic = topic.ifBlank {
            activityTopic
        }.ifBlank {
            title
        }
    )
}

/**
 * Converts an attached LearningResource back into
 * ResourceItem for opening, history and bookmarks.
 *
 * Fields unavailable in LearningResource use safe
 * defaults rather than invented metadata.
 */
fun LearningResource.toResourceItem(
    subject: String = ""
): ResourceItem {

    val resourceType = when (type) {
        LearningResourceType.VIDEO ->
            ResourceType.VIDEO

        LearningResourceType.ARTICLE ->
            ResourceType.ARTICLE

        LearningResourceType.DOCUMENT ->
            ResourceType.DOCUMENTATION

        LearningResourceType.WEBSITE,
        LearningResourceType.COURSE,
        LearningResourceType.BOOK,
        LearningResourceType.OTHER ->
            ResourceType.WEBSITE
    }

    return ResourceItem(
        id = id,
        title = title,
        url = url,
        description = description,
        type = resourceType,
        provider = provider,
        subject = subject,
        topic = topic,
        durationSeconds = estimatedMinutes
            .coerceAtLeast(0)
            .toLong() * 60L,
        isFree = false
    )
}
