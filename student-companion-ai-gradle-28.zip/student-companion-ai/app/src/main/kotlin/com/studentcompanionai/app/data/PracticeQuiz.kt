
package com.studentcompanionai.app.data

import java.util.UUID

/**
 * Supported question formats.
 */
enum class PracticeQuestionType {
    MCQ,
    SHORT_ANSWER,
    PROBLEM_SOLVING
}

/**
 * Represents one question in a practice quiz.
 *
 * MCQ questions use options and correctAnswerIndex.
 * Short-answer and problem-solving questions use expectedAnswer
 * and evaluationCriteria.
 */
data class PracticeQuestion(
    val id: String,
    val question: String,
    val options: List<String> = emptyList(),
    val correctAnswerIndex: Int = -1,
    val explanation: String = "",
    val topic: String = "",
    val difficulty: String = "MEDIUM",
    val type: PracticeQuestionType = PracticeQuestionType.MCQ,
    val expectedAnswer: String = "",
    val evaluationCriteria: String = ""
) {
    init {
        require(question.isNotBlank()) {
            "Question cannot be empty."
        }

        when (type) {

            PracticeQuestionType.MCQ -> {

                require(options.size == 4) {
                    "An MCQ question must have exactly four options."
                }

                require(options.all { it.isNotBlank() }) {
                    "MCQ options cannot be empty."
                }

                require(options.distinct().size == options.size) {
                    "MCQ options must be unique."
                }

                require(correctAnswerIndex in options.indices) {
                    "Correct answer index must refer to a valid option."
                }
            }

            PracticeQuestionType.SHORT_ANSWER,
            PracticeQuestionType.PROBLEM_SOLVING -> {

                require(options.isEmpty()) {
                    "Written-answer questions cannot contain MCQ options."
                }

                require(expectedAnswer.isNotBlank()) {
                    "Written-answer questions must contain an expected answer."
                }

                require(evaluationCriteria.isNotBlank()) {
                    "Written-answer questions must contain evaluation criteria."
                }

                require(correctAnswerIndex == -1) {
                    "Written-answer questions cannot have an MCQ answer index."
                }
            }
        }
    }
}

/**
 * Represents a complete generated practice quiz.
 */
data class PracticeQuiz(
    val id: String,
    val title: String,
    val subject: String,
    val questions: List<PracticeQuestion>,
    val createdAt: Long = System.currentTimeMillis(),
    val questionFormat: String = "MCQ"
) {
    val totalQuestions: Int
        get() = questions.size
}

/**
 * Represents one submitted answer.
 *
 * For MCQs:
 * selectedAnswerIndex stores the selected option.
 *
 * For written answers:
 * selectedAnswerIndex remains -1 and writtenAnswer stores
 * the learner's actual response.
 */
data class PracticeAnswer(
    val questionId: String,
    val selectedAnswerIndex: Int,
    val isCorrect: Boolean,
    val topic: String = "",
    val difficulty: String = "MEDIUM",
    val questionType: PracticeQuestionType = PracticeQuestionType.MCQ,
    val writtenAnswer: String = "",
    val expectedAnswer: String = "",
    val evaluationFeedback: String = "",
    val isEvaluated: Boolean = true
)

/**
 * Represents one completed quiz attempt.
 *
 * attemptId uniquely identifies an individual attempt.
 * It remains unchanged throughout that attempt and must be
 * reused for history storage and XP transaction deduplication.
 *
 * A new quiz attempt must receive a new attemptId.
 */
data class PracticeQuizResult(
    val quizId: String,
    val quizTitle: String,
    val subject: String,
    val answers: List<PracticeAnswer>,
    val completedAt: Long = System.currentTimeMillis(),
    val attemptId: String = UUID.randomUUID().toString()
) {

    val totalQuestions: Int
        get() = answers.size

    val evaluatedAnswers: Int
        get() = answers.count {
            it.isEvaluated
        }

    val correctAnswers: Int
        get() = answers.count {
            it.isEvaluated && it.isCorrect
        }

    val incorrectAnswers: Int
        get() = answers.count {
            it.isEvaluated && !it.isCorrect
        }

    val pendingEvaluationAnswers: Int
        get() = answers.count {
            !it.isEvaluated
        }

    val scorePercent: Int
        get() = if (evaluatedAnswers == 0) {
            0
        } else {
            (correctAnswers * 100) / evaluatedAnswers
        }
}
