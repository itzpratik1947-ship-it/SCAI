
package com.studentcompanionai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.LearningCoachProfile
import com.studentcompanionai.app.data.LearningLevel
import com.studentcompanionai.app.data.LearningStyle
import com.studentcompanionai.app.data.StudentStorage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LearningCoachSetupScreen(
    onBackClick: () -> Unit,
    onContinue: (LearningCoachProfile) -> Unit
) {
    val context = LocalContext.current.applicationContext
    val uid = FirebaseAuth.getInstance().currentUser?.uid

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    val coroutineScope = rememberCoroutineScope()

    var existingProfile by remember(uid) {
        mutableStateOf<LearningCoachProfile?>(null)
    }

    var isLoading by remember(uid) {
        mutableStateOf(true)
    }

    var isSaving by rememberSaveable(uid) {
        mutableStateOf(false)
    }

    var goal by rememberSaveable(uid) {
        mutableStateOf("")
    }

    var subject by rememberSaveable(uid) {
        mutableStateOf("")
    }

    var targetDays by rememberSaveable(uid) {
        mutableStateOf("30")
    }

    var dailyMinutes by rememberSaveable(uid) {
        mutableStateOf("45")
    }

    var selectedLevel by rememberSaveable(uid) {
        mutableStateOf(LearningLevel.BEGINNER)
    }

    var selectedStyle by rememberSaveable(uid) {
        mutableStateOf(LearningStyle.MIXED)
    }

    var errorMessage by rememberSaveable(uid) {
        mutableStateOf("")
    }

    // ---------------------------------------------------------
    // LOAD THE EXISTING COMPLETE LEARNER PROFILE
    // ---------------------------------------------------------

    LaunchedEffect(uid) {
        existingProfile = null
        isLoading = true
        errorMessage = ""

        if (uid == null) {
            isLoading = false
            errorMessage = "Please sign in to create your learning profile."
            return@LaunchedEffect
        }

        try {
            val profile = withContext(Dispatchers.IO) {
                storage.loadLearningCoachProfile()
            }

            if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                return@LaunchedEffect
            }

            existingProfile = profile

            if (profile != null) {
                goal = profile.learningGoal
                subject = profile.subject
                targetDays = profile.targetDays.toString()
                dailyMinutes = profile.dailyStudyMinutes.toString()
                selectedLevel = profile.currentLevel
                selectedStyle = profile.preferredLearningStyle
            }

        } catch (exception: CancellationException) {
            throw exception

        } catch (exception: Exception) {
            if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                errorMessage = exception.localizedMessage
                    ?: "Unable to load your learning profile."
            }

        } finally {
            if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                isLoading = false
            }
        }
    }

    // ---------------------------------------------------------
    // UI
    // ---------------------------------------------------------

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        Text(
            text = "Your Learning Coach",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "Tell us what you want to learn. Your coach will use these details to personalize your learning journey.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (isLoading) {
            Text("Loading your learning profile...")
            return@Column
        }

        OutlinedTextField(
            value = goal,
            onValueChange = {
                goal = it
                errorMessage = ""
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("What is your learning goal?")
            },
            placeholder = {
                Text("Example: Prepare for my physics exam")
            },
            minLines = 2,
            maxLines = 4,
            enabled = !isSaving
        )

        OutlinedTextField(
            value = subject,
            onValueChange = {
                subject = it
                errorMessage = ""
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Subject or skill")
            },
            placeholder = {
                Text("Physics, Python, English, etc.")
            },
            singleLine = true,
            enabled = !isSaving
        )

        // -----------------------------------------------------
        // CURRENT LEARNING LEVEL
        // -----------------------------------------------------

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainer
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Your current level",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                LearningLevel.values().forEach { level ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedLevel == level,
                            onClick = {
                                selectedLevel = level
                            },
                            enabled = !isSaving
                        )

                        Spacer(Modifier.width(8.dp))

                        Text(
                            text = level.displayName,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // -----------------------------------------------------
        // TARGET DURATION
        // -----------------------------------------------------

        OutlinedTextField(
            value = targetDays,
            onValueChange = {
                targetDays = it.filter(Char::isDigit).take(3)
                errorMessage = ""
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Target duration (days)")
            },
            placeholder = {
                Text("30")
            },
            supportingText = {
                Text("Choose between 1 and 90 days.")
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number
            ),
            singleLine = true,
            enabled = !isSaving
        )

        // -----------------------------------------------------
        // DAILY STUDY TIME
        // -----------------------------------------------------

        OutlinedTextField(
            value = dailyMinutes,
            onValueChange = {
                dailyMinutes = it.filter(Char::isDigit).take(3)
                errorMessage = ""
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Daily study time (minutes)")
            },
            placeholder = {
                Text("45")
            },
            supportingText = {
                Text("Choose between 10 and 600 minutes.")
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number
            ),
            singleLine = true,
            enabled = !isSaving
        )

        // -----------------------------------------------------
        // LEARNING STYLE
        // -----------------------------------------------------

        Text(
            text = "How do you prefer to learn?",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )

        LearningStyle.values().forEach { style ->
            FilterChip(
                selected = selectedStyle == style,
                onClick = {
                    selectedStyle = style
                },
                label = {
                    Text(style.displayName)
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isSaving
            )
        }

        // -----------------------------------------------------
        // ERROR MESSAGE
        // -----------------------------------------------------

        if (errorMessage.isNotBlank()) {
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Spacer(Modifier.height(4.dp))

        // -----------------------------------------------------
        // SAVE PROFILE
        // -----------------------------------------------------

        Button(
            onClick = {

                if (isSaving) {
                    return@Button
                }

                if (uid == null ||
                    FirebaseAuth.getInstance().currentUser?.uid != uid
                ) {
                    errorMessage = "Your account changed. Please sign in again."
                    return@Button
                }

                val days = targetDays.toIntOrNull()
                val minutes = dailyMinutes.toIntOrNull()

                errorMessage = when {
                    goal.isBlank() ->
                        "Please enter your learning goal."

                    subject.isBlank() ->
                        "Please enter a subject or skill."

                    days == null || days !in 1..90 ->
                        "Duration must be between 1 and 90 days."

                    minutes == null || minutes !in 10..600 ->
                        "Daily study time must be between 10 and 600 minutes."

                    else -> ""
                }

                if (errorMessage.isNotBlank()) {
                    return@Button
                }

                val previousProfile = existingProfile
                val now = System.currentTimeMillis()

                val profileDetailsChanged =
                    previousProfile == null ||
                    previousProfile.learningGoal != goal.trim() ||
                    previousProfile.subject != subject.trim() ||
                    previousProfile.currentLevel != selectedLevel ||
                    previousProfile.targetDays != days ||
                    previousProfile.dailyStudyMinutes != minutes ||
                    previousProfile.preferredLearningStyle != selectedStyle

                // IMPORTANT:
                // Update the existing profile instead of creating
                // a new incomplete profile.
                //
                // This preserves onboarding information such as:
                // preferredName, education, subjects, schedule,
                // focus preferences and profileCompleted.

                val updatedProfile = if (previousProfile != null) {

                    previousProfile.copy(
                        learningGoal = goal.trim(),
                        subject = subject.trim(),
                        currentLevel = selectedLevel,
                        targetDays = days!!,
                        dailyStudyMinutes = minutes!!,
                        preferredLearningStyle = selectedStyle,
                        updatedAt = if (profileDetailsChanged) {
                            now
                        } else {
                            previousProfile.updatedAt
                        }
                    )

                } else {

                    LearningCoachProfile(
                        learningGoal = goal.trim(),
                        subject = subject.trim(),
                        currentLevel = selectedLevel,
                        targetDays = days!!,
                        dailyStudyMinutes = minutes!!,
                        preferredLearningStyle = selectedStyle,
                        createdAt = now,
                        updatedAt = now
                    )
                }

                isSaving = true
                errorMessage = ""

                coroutineScope.launch {

                    try {
                        // Verify the account before saving.
                        if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                            errorMessage =
                                "Your account changed. Please sign in again."
                            return@launch
                        }

                        withContext(Dispatchers.IO) {
                            storage.saveLearningCoachProfile(updatedProfile)
                        }

                        // Verify the account again before navigating.
                        if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                            errorMessage =
                                "Your account changed. Please sign in again."
                            return@launch
                        }

                        existingProfile = updatedProfile

                        onContinue(updatedProfile)

                    } catch (exception: CancellationException) {
                        throw exception

                    } catch (exception: Exception) {
                        errorMessage = exception.localizedMessage
                            ?: "Unable to save your learning profile."

                    } finally {
                        isSaving = false
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            enabled = uid != null && !isLoading && !isSaving
        ) {
            Text(
                when {
                    isSaving -> "Saving..."

                    existingProfile != null ->
                        "Update Learning Profile"

                    else ->
                        "Continue to My Learning Coach"
                }
            )
        }

        Text(
            text = "You can refine your goals as you make progress.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
