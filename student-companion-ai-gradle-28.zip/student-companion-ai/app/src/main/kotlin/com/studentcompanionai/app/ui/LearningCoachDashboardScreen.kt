package com.studentcompanionai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.AssessmentAnswerEvaluation
import com.studentcompanionai.app.data.InitialAssessmentEvaluator
import com.studentcompanionai.app.data.InitialAssessmentGenerator
import com.studentcompanionai.app.data.InitialAssessmentQuestion
import com.studentcompanionai.app.data.InitialAssessmentResponse
import com.studentcompanionai.app.data.InitialAssessmentResult
import com.studentcompanionai.app.data.InitialKnowledgeAnalyzer
import com.studentcompanionai.app.data.LearningCoachEngine
import com.studentcompanionai.app.data.LearningCoachProfile
import com.studentcompanionai.app.data.LearningPlan
import com.studentcompanionai.app.data.LearningPlanGenerator
import com.studentcompanionai.app.data.LearningPlanValidator
import com.studentcompanionai.app.data.StudentStorage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private data class CoachChatMessage(
    val text: String,
    val fromLearner: Boolean
)

@Composable
fun LearningCoachDashboardScreen(
    profile: LearningCoachProfile,
    onBackClick: () -> Unit,
    onPlanGenerated: (LearningPlan) -> Unit
) {
    // --------------------------------------------------
    // STORAGE AND ACCOUNT
    // --------------------------------------------------

    val context = LocalContext.current.applicationContext
    val uid = FirebaseAuth.getInstance().currentUser?.uid

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    val engine = remember(uid) {
        LearningCoachEngine()
    }

    val scope = rememberCoroutineScope()

    var activeProfile by remember(uid, profile) {
        mutableStateOf(profile)
    }

    var profileLoading by remember(uid) {
        mutableStateOf(true)
    }

    // --------------------------------------------------
    // SCREEN STATE
    // --------------------------------------------------

    val messages = remember(uid, profile) {
        mutableStateListOf<CoachChatMessage>()
    }

    var strategy by remember(uid, profile) {
        mutableStateOf("")
    }

    var messageInput by remember(uid) {
        mutableStateOf("")
    }

    var isGeneratingStrategy by remember(uid) {
        mutableStateOf(false)
    }

    var isSendingMessage by remember(uid) {
        mutableStateOf(false)
    }

    var isGeneratingPlan by remember(uid) {
        mutableStateOf(false)
    }

    var errorMessage by remember(uid) {
        mutableStateOf("")
    }

    var warningMessage by remember(uid) {
        mutableStateOf("")
    }

    // --------------------------------------------------
    // ASSESSMENT STATE
    // --------------------------------------------------

    var assessmentQuestions by remember(uid) {
        mutableStateOf<List<InitialAssessmentQuestion>?>(null)
    }

    var assessmentResult by remember(uid) {
        mutableStateOf<InitialAssessmentResult?>(null)
    }

    var isAssessmentVisible by remember(uid) {
        mutableStateOf(false)
    }

    var isGeneratingAssessment by remember(uid) {
        mutableStateOf(false)
    }

    var isEvaluatingAssessment by remember(uid) {
        mutableStateOf(false)
    }

    // --------------------------------------------------
    // ACCOUNT VALIDATION
    // --------------------------------------------------

    fun isCurrentAccountValid(): Boolean {
        return uid != null &&
            FirebaseAuth.getInstance().currentUser?.uid == uid
    }

    // --------------------------------------------------
    // LOAD LATEST PROFILE
    // --------------------------------------------------

    LaunchedEffect(uid, profile) {
        activeProfile = profile
        profileLoading = true

        strategy = ""
        messages.clear()

        assessmentQuestions = null
        assessmentResult = null
        isAssessmentVisible = false

        errorMessage = ""
        warningMessage = ""

        if (uid == null) {
            profileLoading = false
            errorMessage = "Please sign in to access your Learning Coach."
            return@LaunchedEffect
        }

        try {
            val savedProfile = withContext(Dispatchers.IO) {
                storage.loadLearningCoachProfile()
            }

            if (!isCurrentAccountValid()) {
                return@LaunchedEffect
            }

            activeProfile = savedProfile ?: profile

        } catch (e: CancellationException) {
            throw e

        } catch (e: Exception) {
            if (isCurrentAccountValid()) {
                errorMessage = e.message
                    ?.takeIf { it.isNotBlank() }
                    ?: "Unable to load your learning profile."
            }

        } finally {
            if (isCurrentAccountValid()) {
                profileLoading = false
            }
        }
    }

    // --------------------------------------------------
    // FEATURE AVAILABILITY
    // --------------------------------------------------

    val canGeneratePlan =
        uid != null &&
            !profileLoading &&
            activeProfile.isValid() &&
            activeProfile.targetDays in 1..90 &&
            activeProfile.dailyStudyMinutes in 10..600

    val canGenerateAssessment =
        uid != null &&
            !profileLoading &&
            activeProfile.isValid()

    // --------------------------------------------------
    // GENERATE INITIAL ASSESSMENT
    // --------------------------------------------------

    fun generateInitialAssessment() {
        if (!isCurrentAccountValid()) {
            errorMessage = "Your account changed. Please sign in again."
            return
        }

        if (
            isGeneratingAssessment ||
            isEvaluatingAssessment ||
            isGeneratingPlan ||
            isGeneratingStrategy
        ) {
            return
        }

        if (!activeProfile.isValid()) {
            errorMessage = "Your learning profile is incomplete. Update it first."
            return
        }

        scope.launch {
            isGeneratingAssessment = true
            errorMessage = ""
            warningMessage = ""

            try {
                val questions = withContext(Dispatchers.IO) {
                    InitialAssessmentGenerator().generateAssessment(
                        profile = activeProfile,
                        questionCount = 12
                    )
                }

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                require(questions.size == 12) {
                    "The assessment must contain exactly 12 questions."
                }

                assessmentQuestions = questions
                assessmentResult = null
                isAssessmentVisible = true

            } catch (e: CancellationException) {
                throw e

            } catch (e: Exception) {
                if (isCurrentAccountValid()) {
                    errorMessage = e.message
                        ?.takeIf { it.isNotBlank() }
                        ?: "Unable to generate your assessment. Please try again."
                }

            } finally {
                if (isCurrentAccountValid()) {
                    isGeneratingAssessment = false
                }
            }
        }
    }

    // --------------------------------------------------
    // SUBMIT AND EVALUATE ASSESSMENT
    // --------------------------------------------------

    fun submitInitialAssessment(
        responses: List<InitialAssessmentResponse>
    ) {
        if (!isCurrentAccountValid()) {
            errorMessage = "Your account changed. Please sign in again."
            return
        }

        val questions = assessmentQuestions

        if (
            questions.isNullOrEmpty() ||
            isEvaluatingAssessment ||
            isGeneratingAssessment
        ) {
            return
        }

        isAssessmentVisible = false
        isEvaluatingAssessment = true

        errorMessage = ""
        warningMessage = ""

        scope.launch {
            try {
                // 1. Evaluate answers.

                val evaluations: List<AssessmentAnswerEvaluation> =
                    InitialAssessmentEvaluator().evaluateResponses(
                        questions = questions,
                        responses = responses
                    )

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                // 2. Analyze topic-wise knowledge.

                val analyzer = InitialKnowledgeAnalyzer()

                val topicResults = analyzer.analyzeTopics(
                    questions = questions,
                    evaluations = evaluations
                )

                // 3. Calculate score.

                val overallScore = analyzer.calculateOverallScore(
                    evaluations = evaluations
                )

                val totalMarks = questions.sumOf {
                    it.maximumMarks.toDouble()
                }

                val awardedMarks = evaluations.sumOf {
                    it.awardedMarks
                }

                // 4. Create result.

                val result = InitialAssessmentResult(
                    id = UUID.randomUUID().toString(),
                    profileSubject = activeProfile.subject,
                    totalQuestions = questions.size,
                    totalMarks = totalMarks,
                    awardedMarks = awardedMarks,
                    overallScorePercent = overallScore,
                    responses = responses,
                    evaluations = evaluations,
                    topicResults = topicResults
                )

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                // 5. Save result.

                withContext(Dispatchers.IO) {
                    storage.saveInitialAssessmentResult(result)
                }

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                // 6. Display result.

                assessmentResult = result
                assessmentQuestions = null

            } catch (e: CancellationException) {
                throw e

            } catch (e: Exception) {
                if (isCurrentAccountValid()) {
                    errorMessage = e.message
                        ?.takeIf { it.isNotBlank() }
                        ?: "Unable to evaluate your assessment. Please try again."

                    // Keep the questions available for retry.
                    isAssessmentVisible = true
                }

            } finally {
                if (isCurrentAccountValid()) {
                    isEvaluatingAssessment = false
                }
            }
        }
    }

    // --------------------------------------------------
    // GENERATE LEARNING PLAN
    // --------------------------------------------------

    fun generateLearningPlan() {
        if (!isCurrentAccountValid()) {
            errorMessage = "Your account changed. Please sign in again."
            return
        }

        if (
            isGeneratingPlan ||
            isGeneratingAssessment ||
            isEvaluatingAssessment ||
            isGeneratingStrategy
        ) {
            return
        }

        if (!activeProfile.isValid()) {
            errorMessage = "Your learning profile is incomplete."
            return
        }

        if (activeProfile.targetDays !in 1..90) {
            errorMessage =
                "Learning plans currently support durations between 1 and 90 days. " +
                    "Update your Coach profile."
            return
        }

        if (activeProfile.dailyStudyMinutes !in 10..600) {
            errorMessage =
                "Daily study time must be between 10 and 600 minutes."
            return
        }

        scope.launch {
            isGeneratingPlan = true
            errorMessage = ""
            warningMessage = ""

            try {
                // 1. Retrieve the latest assessment.

                val latestAssessment = withContext(Dispatchers.IO) {
                    storage.getLatestInitialAssessmentResult()
                }

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                // 2. Generate the plan.

                val plan = withContext(Dispatchers.IO) {
                    LearningPlanGenerator().generatePlan(
                        goal = activeProfile.learningGoal.trim(),
                        subject = activeProfile.subject.trim(),
                        currentLevel = activeProfile.currentLevel.displayName,
                        targetDays = activeProfile.targetDays,
                        dailyStudyMinutes = activeProfile.dailyStudyMinutes,
                        assessmentResult = latestAssessment
                    )
                }

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                // 3. Validate the plan.

                val validation = LearningPlanValidator().validate(
                    plan = plan,
                    assessmentResult = latestAssessment
                )

                if (!validation.isValid) {
                    throw IllegalStateException(
                        "The generated learning plan failed validation:\n" +
                            validation.errors.joinToString("\n")
                    )
                }

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                // 4. Display non-blocking warnings.

                warningMessage = validation.warnings
                    .takeIf { it.isNotEmpty() }
                    ?.joinToString("\n") { "• $it" }
                    ?: ""

                // 5. Save validated plan.

                withContext(Dispatchers.IO) {
                    storage.saveLearningPlan(plan)
                }

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                // 6. Navigate to the plan.

                onPlanGenerated(plan)

            } catch (e: CancellationException) {
                throw e

            } catch (e: Exception) {
                if (isCurrentAccountValid()) {
                    errorMessage = e.message
                        ?.takeIf { it.isNotBlank() }
                        ?: "Unable to generate your learning plan. " +
                            "Check your connection and try again."
                }

            } finally {
                if (isCurrentAccountValid()) {
                    isGeneratingPlan = false
                }
            }
        }
    }

    // --------------------------------------------------
    // SEND MESSAGE TO LEARNING COACH
    // --------------------------------------------------

    fun sendMessage() {
        if (!isCurrentAccountValid()) {
            errorMessage = "Your account changed. Please sign in again."
            return
        }

        val question = messageInput.trim()

        if (
            question.isBlank() ||
            isSendingMessage ||
            isGeneratingStrategy ||
            isGeneratingPlan ||
            isGeneratingAssessment ||
            isEvaluatingAssessment ||
            strategy.isBlank()
        ) {
            return
        }

        messageInput = ""
        errorMessage = ""

        messages.add(
            CoachChatMessage(
                text = question,
                fromLearner = true
            )
        )

        scope.launch {
            isSendingMessage = true

            try {
                val recentContext = messages
                    .takeLast(8)
                    .joinToString("\n") { message ->
                        val speaker = if (message.fromLearner) {
                            "Learner"
                        } else {
                            "Coach"
                        }

                        "$speaker: ${message.text}"
                    }

                val answer = engine.respondToLearner(
                    profile = activeProfile,
                    learnerMessage = question,
                    recentContext = recentContext
                )

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                messages.add(
                    CoachChatMessage(
                        text = answer,
                        fromLearner = false
                    )
                )

            } catch (e: CancellationException) {
                throw e

            } catch (e: Exception) {
                if (isCurrentAccountValid()) {
                    errorMessage = e.message
                        ?.takeIf { it.isNotBlank() }
                        ?: "Unable to get a response. Please try again."
                }

            } finally {
                if (isCurrentAccountValid()) {
                    isSendingMessage = false
                }
            }
        }
    }

    // --------------------------------------------------
    // GENERATE LEARNING STRATEGY
    // --------------------------------------------------

    suspend fun generateStrategy() {
        if (!isCurrentAccountValid()) {
            errorMessage = "Your account changed. Please sign in again."
            return
        }

        if (
            profileLoading ||
            isGeneratingStrategy ||
            strategy.isNotBlank()
        ) {
            return
        }

        isGeneratingStrategy = true
        errorMessage = ""

        try {
            val generatedStrategy =
                engine.createLearningStrategy(activeProfile)

            if (isCurrentAccountValid()) {
                strategy = generatedStrategy
            }

        } catch (e: CancellationException) {
            throw e

        } catch (e: Exception) {
            if (isCurrentAccountValid()) {
                errorMessage = e.message
                    ?.takeIf { it.isNotBlank() }
                    ?: "Unable to generate your learning strategy."
            }

        } finally {
            if (isCurrentAccountValid()) {
                isGeneratingStrategy = false
            }
        }
    }

    LaunchedEffect(uid, activeProfile, profileLoading) {
        if (
            !profileLoading &&
            isCurrentAccountValid() &&
            strategy.isBlank()
        ) {
            generateStrategy()
        }
    }

    // --------------------------------------------------
    // PROFILE LOADING UI
    // --------------------------------------------------

    if (profileLoading) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator()

            Spacer(modifier = Modifier.height(16.dp))

            Text("Loading your Learning Coach...")
        }

        return
    }

    // --------------------------------------------------
    // AUTHENTICATION UI
    // --------------------------------------------------

    if (uid == null || !isCurrentAccountValid()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Authentication required",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text("Please sign in to access your Learning Coach.")

            Spacer(modifier = Modifier.height(16.dp))

            
        }

        return
    }

    // --------------------------------------------------
    // INITIAL ASSESSMENT UI
    // --------------------------------------------------

    if (isAssessmentVisible && assessmentQuestions != null) {
        InitialAssessmentScreen(
            questions = assessmentQuestions!!,
            onBackClick = {
                isAssessmentVisible = false
                assessmentQuestions = null
            },
            onAssessmentSubmitted = { responses ->
                submitInitialAssessment(responses)
            }
        )

        return
    }

    // --------------------------------------------------
    // ASSESSMENT EVALUATION LOADING UI
    // --------------------------------------------------

    if (isEvaluatingAssessment) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator()

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Analyzing your knowledge...",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Your answers are being evaluated. " +
                    "Your topic-wise knowledge profile is being prepared.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        return
    }

    // --------------------------------------------------
    // ASSESSMENT RESULT UI
    // --------------------------------------------------

    assessmentResult?.let { result ->
        InitialAssessmentResultScreen(
            result = result,
            onBackClick = {
                assessmentResult = null
            },
            onContinueLearning = {
                assessmentResult = null
            }
        )

        return
    }

    // --------------------------------------------------
    // MAIN DASHBOARD
    // --------------------------------------------------

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // HEADER

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Spacer(modifier = Modifier.weight(1f))

            Text(
                text = "AI Learning Coach",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // LEARNER PROFILE CARD

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = activeProfile.subject,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )

                Text(
                    text = activeProfile.learningGoal,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )

                Text(
                    text = "${activeProfile.currentLevel.displayName} • " +
                        "${activeProfile.targetDays} days • " +
                        "${activeProfile.dailyStudyMinutes} min/day",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )

                Text(
                    text = activeProfile.preferredLearningStyle.displayName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // INITIAL KNOWLEDGE ASSESSMENT

        Button(
            onClick = { generateInitialAssessment() },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            enabled = canGenerateAssessment &&
                !isGeneratingAssessment &&
                !isEvaluatingAssessment &&
                !isGeneratingPlan &&
                !isGeneratingStrategy
        ) {
            if (isGeneratingAssessment) {
                CircularProgressIndicator(
                    modifier = Modifier.height(22.dp),
                    strokeWidth = 2.dp
                )

                Text("  Generating diagnostic assessment...")
            } else {
                Text("Start Initial Knowledge Assessment")
            }
        }

        Text(
            text = "Discover your current knowledge through 12 diagnostic " +
                "questions covering different topics. Your answers will help " +
                "personalize your learning journey.",
            modifier = Modifier.padding(
                horizontal = 4.dp,
                vertical = 6.dp
            ),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // GENERATE LEARNING PLAN

        Button(
            onClick = { generateLearningPlan() },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            enabled = canGeneratePlan &&
                !isGeneratingPlan &&
                !isGeneratingAssessment &&
                !isEvaluatingAssessment &&
                !isGeneratingStrategy
        ) {
            if (isGeneratingPlan) {
                CircularProgressIndicator(
                    modifier = Modifier.height(22.dp),
                    strokeWidth = 2.dp
                )

                Text("  Generating your learning roadmap...")
            } else {
                Text("Generate My Complete Learning Plan")
            }
        }

        Text(
            text = if (isGeneratingPlan) {
                "Your Coach is creating your day-by-day learning roadmap. " +
                    "This may take a little time."
            } else {
                "Your Coach will create a personalized plan with daily " +
                    "objectives, learning activities, practice, revision and tests."
            },
            modifier = Modifier.padding(
                horizontal = 4.dp,
                vertical = 6.dp
            ),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // ERROR MESSAGE

        if (errorMessage.isNotBlank()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Text(
                    text = errorMessage,
                    modifier = Modifier.padding(12.dp),
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // VALIDATION WARNINGS

        if (warningMessage.isNotBlank()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                )
            ) {
                Text(
                    text = "Learning plan notes:\n$warningMessage",
                    modifier = Modifier.padding(12.dp),
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        HorizontalDivider(
            modifier = Modifier.padding(vertical = 12.dp)
        )

        // LEARNING STRATEGY HEADING

        Text(
            text = "Your learning strategy",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        // STRATEGY LOADING

        if (isGeneratingStrategy) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator()

                Text(
                    text = "Building your strategy...",
                    modifier = Modifier.padding(start = 12.dp)
                )
            }

        // STRATEGY AND CHAT

        } else if (strategy.isNotBlank()) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = strategy,
                            modifier = Modifier.padding(14.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                item {
                    Text(
                        text = "Ask your coach",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(messages) { message ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (message.fromLearner) {
                                MaterialTheme.colorScheme.secondaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            }
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Text(
                                text = if (message.fromLearner) {
                                    "You"
                                } else {
                                    "Learning Coach"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(text = message.text)
                        }
                    }
                }

                if (isSendingMessage) {
                    item {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator()

                            Text(
                                text = "Your coach is thinking...",
                                modifier = Modifier.padding(start = 12.dp)
                            )
                        }
                    }
                }
            }

        // STRATEGY GENERATION FAILED

        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Your learning strategy will appear here.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    enabled = !isGeneratingStrategy &&
                        isCurrentAccountValid(),
                    onClick = {
                        scope.launch {
                            generateStrategy()
                        }
                    }
                ) {
                    Text("Try Again")
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // COACH MESSAGE INPUT

        OutlinedTextField(
            value = messageInput,
            onValueChange = {
                messageInput = it
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Ask your learning coach")
            },
            placeholder = {
                Text("Explain a concept, suggest practice...")
            },
            enabled = strategy.isNotBlank() &&
                !isSendingMessage &&
                !isGeneratingStrategy &&
                !isGeneratingPlan &&
                !isGeneratingAssessment &&
                !isEvaluatingAssessment &&
                isCurrentAccountValid(),
            keyboardOptions = KeyboardOptions(
                imeAction = ImeAction.Send
            ),
            keyboardActions = KeyboardActions(
                onSend = {
                    sendMessage()
                }
            ),
            trailingIcon = {
                TextButton(
                    enabled = messageInput.isNotBlank() &&
                        !isSendingMessage &&
                        !isGeneratingStrategy &&
                        !isGeneratingPlan &&
                        !isGeneratingAssessment &&
                        !isEvaluatingAssessment &&
                        strategy.isNotBlank() &&
                        isCurrentAccountValid(),
                    onClick = {
                        sendMessage()
                    }
                ) {
                    Text("Send")
                }
            },
            maxLines = 3
        )
    }
}