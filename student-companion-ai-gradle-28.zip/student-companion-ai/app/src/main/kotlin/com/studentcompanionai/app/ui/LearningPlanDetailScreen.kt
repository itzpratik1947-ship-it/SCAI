
package com.studentcompanionai.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.LearningActivity
import com.studentcompanionai.app.data.LearningDay
import com.studentcompanionai.app.data.LearningPlan
import com.studentcompanionai.app.data.LearningPlanStatus
import com.studentcompanionai.app.data.LearningResource
import com.studentcompanionai.app.data.ResourceStorage
import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.data.toResourceItem
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiSectionTitle
import com.studentcompanionai.app.ui.components.ScaiTopBar
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun LearningPlanDetailScreen(
    plan: LearningPlan,
    onBackClick: () -> Unit = {},
    onPlanUpdated: (LearningPlan) -> Unit = {}
) {
    // ACCOUNT AND STORAGE

    val context = LocalContext.current.applicationContext
    val uid = FirebaseAuth.getInstance().currentUser?.uid

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    val resourceStorage = remember(uid) {
        ResourceStorage(accountUid = uid.orEmpty())
    }

    val scope = rememberCoroutineScope()

    val saveMutex = remember(plan.id, uid) {
        Mutex()
    }

    var currentPlan by remember(plan.id, uid) {
        mutableStateOf(plan)
    }

    var saveError by remember(plan.id, uid) {
        mutableStateOf<String?>(null)
    }

    var saving by remember(plan.id, uid) {
        mutableStateOf(false)
    }

    val canCompleteActivities =
        currentPlan.status == LearningPlanStatus.ACTIVE

    // LOAD LATEST SAVED PLAN

    LaunchedEffect(plan.id, uid) {
        if (uid == null) {
            saveError = "Sign in to access this learning plan."
            return@LaunchedEffect
        }

        try {
            val savedPlan = withContext(Dispatchers.IO) {
                storage.getLearningPlanById(plan.id)
            }

            if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                return@LaunchedEffect
            }

            currentPlan = savedPlan ?: plan

        } catch (exception: CancellationException) {
            throw exception
        } catch (exception: Exception) {
            saveError = exception.localizedMessage
                ?: "Could not load the saved learning plan."
        }
    }

    // SAVE PLAN

    fun persistPlan(updatedPlan: LearningPlan) {
        if (
            uid == null ||
            FirebaseAuth.getInstance().currentUser?.uid != uid
        ) {
            saveError =
                "Your account changed. Sign in again to save progress."
            return
        }

        val timestampedPlan = updatedPlan.copy(
            updatedAt = System.currentTimeMillis()
        )

        currentPlan = timestampedPlan
        saveError = null
        onPlanUpdated(timestampedPlan)

        scope.launch {
            if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                return@launch
            }

            saving = true

            try {
                saveMutex.withLock {
                    if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                        return@withLock
                    }

                    withContext(Dispatchers.IO) {
                        storage.saveLearningPlan(timestampedPlan)
                    }
                }
            } catch (exception: CancellationException) {
                throw exception
            } catch (exception: Exception) {
                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                    saveError = exception.localizedMessage
                        ?: "Could not save your progress."
                }
            } finally {
                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                    saving = false
                }
            }
        }
    }

    // OPEN LEARNING RESOURCE

    fun openLearningResource(resource: LearningResource) {
        val url = resource.url.trim()

        if (
            !url.startsWith("https://", ignoreCase = true) &&
            !url.startsWith("http://", ignoreCase = true)
        ) {
            saveError = "This resource has an invalid web address."
            return
        }

        if (
            uid == null ||
            FirebaseAuth.getInstance().currentUser?.uid != uid
        ) {
            saveError = "Sign in to open learning resources."
            return
        }

        val resourceItem = resource.toResourceItem(
            subject = currentPlan.subject
        )

        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    resourceStorage.recordResourceOpened(resourceItem)
                }
            }
        }

        runCatching {
            val intent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse(url)
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            context.startActivity(intent)
        }.onFailure {
            saveError = "No browser is available to open this resource."
        }
    }

    // ACTIVATE PLAN WITHOUT CREATING TASKS

    fun activatePlan() {
        if (
            currentPlan.status != LearningPlanStatus.DRAFT ||
            saving
        ) {
            return
        }

        if (
            uid == null ||
            FirebaseAuth.getInstance().currentUser?.uid != uid
        ) {
            saveError = "Sign in to activate this learning plan."
            return
        }

        if (currentPlan.days.isEmpty()) {
            saveError = "This learning plan has no learning days."
            return
        }

        val calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val startDate = calendar.timeInMillis

        val scheduledDays = currentPlan.days.map { day ->
            val dayCalendar = calendar.clone() as Calendar

            dayCalendar.add(
                Calendar.DAY_OF_YEAR,
                day.dayNumber - 1
            )

            day.copy(
                scheduledDate = dayCalendar.timeInMillis
            )
        }

        val activatedPlan = currentPlan.copy(
            startDate = startDate,
            status = LearningPlanStatus.ACTIVE,
            days = scheduledDays,
            updatedAt = System.currentTimeMillis()
        )

        saveError = null
        saving = true

        scope.launch {
            try {
                saveMutex.withLock {
                    if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                        throw IllegalStateException(
                            "Your account changed. Please sign in again."
                        )
                    }

                    withContext(Dispatchers.IO) {
                        // Activating a plan only updates the plan itself.
                        // Learning activities remain inside the roadmap.
                        // No StudyTask objects are created or saved here.
                        storage.saveLearningPlan(activatedPlan)
                    }
                }

                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                    currentPlan = activatedPlan
                    onPlanUpdated(activatedPlan)
                }

            } catch (exception: CancellationException) {
                throw exception
            } catch (exception: Exception) {
                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                    saveError = exception.localizedMessage
                        ?: "Could not activate the learning plan."
                }
            } finally {
                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                    saving = false
                }
            }
        }
    }

    // DAY COMPLETION

    fun updateDay(dayNumber: Int, completed: Boolean) {
        if (!canCompleteActivities) return

        val updatedDays = currentPlan.days.map { day ->
            if (day.dayNumber == dayNumber) {
                day.copy(isCompleted = completed)
            } else {
                day
            }
        }

        val allDaysCompleted =
            updatedDays.isNotEmpty() &&
                updatedDays.all { it.isCompleted }

        val updatedStatus = if (allDaysCompleted) {
            LearningPlanStatus.COMPLETED
        } else {
            LearningPlanStatus.ACTIVE
        }

        persistPlan(
            currentPlan.copy(
                days = updatedDays,
                status = updatedStatus
            )
        )
    }

    // ACTIVITY COMPLETION

    fun updateActivity(
        dayNumber: Int,
        activityId: String,
        completed: Boolean
    ) {
        if (!canCompleteActivities) return

        val updatedDays = currentPlan.days.map { day ->
            if (day.dayNumber == dayNumber) {

                val updatedActivities = day.activities.map { activity ->
                    if (activity.id == activityId) {
                        activity.copy(
                            isCompleted = completed,
                            completedAt = if (completed) {
                                System.currentTimeMillis()
                            } else {
                                0L
                            }
                        )
                    } else {
                        activity
                    }
                }

                val allActivitiesCompleted =
                    updatedActivities.isNotEmpty() &&
                        updatedActivities.all { it.isCompleted }

                day.copy(
                    activities = updatedActivities,
                    isCompleted = allActivitiesCompleted
                )

            } else {
                day
            }
        }

        val allDaysCompleted =
            updatedDays.isNotEmpty() &&
                updatedDays.all { it.isCompleted }

        val updatedStatus = if (allDaysCompleted) {
            LearningPlanStatus.COMPLETED
        } else {
            LearningPlanStatus.ACTIVE
        }

        persistPlan(
            currentPlan.copy(
                days = updatedDays,
                status = updatedStatus
            )
        )
    }

    // UI

    ScaiScreen(
        scrollable = true
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {

            // HEADER

            ScaiTopBar(
                title = "Learning plan",
                subtitle = "Your roadmap and daily progress"
            )

            // PLAN TITLE AND DESCRIPTION

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = currentPlan.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = currentPlan.goal,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PlanMetadata(currentPlan.subject)
                    PlanMetadata(currentPlan.currentLevel)
                }
            }

            ScaiDivider()

            // PROGRESS OVERVIEW

            ScaiCard {
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Your progress",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        Text(
                            text = "${currentPlan.progressPercent}%",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    LinearProgressIndicator(
                        progress = {
                            (currentPlan.progressPercent / 100f)
                                .coerceIn(0f, 1f)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp),
                        color = MaterialTheme.colorScheme.onSurface,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "${currentPlan.completedDays}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Days completed",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Column(
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = "${currentPlan.totalDays}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Total days",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant
                    )

                    SummaryRow(
                        "Daily study time",
                        "${currentPlan.dailyStudyMinutes} minutes"
                    )

                    SummaryRow(
                        "Target duration",
                        "${currentPlan.targetDays} days"
                    )

                    SummaryRow(
                        "Total activities",
                        currentPlan.days.sumOf {
                            it.activities.size
                        }.toString()
                    )

                    SummaryRow(
                        "Status",
                        currentPlan.status.name.replace("_", " ")
                    )

                    if (currentPlan.startDate > 0L) {
                        SummaryRow(
                            "Started",
                            formatDate(currentPlan.startDate)
                        )
                    }

                    if (saving) {
                        Text(
                            text = "Saving changes...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    saveError?.let { error ->
                        Text(
                            text = error,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            // PLAN STATUS ACTION

            when (currentPlan.status) {
                LearningPlanStatus.DRAFT -> {
                    ScaiCard {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Ready to begin?",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )

                            Text(
                                text = "Activate this plan to begin tracking your progress. " +
                                    "Activities stay inside this learning roadmap " +
                                    "and are never added to Tasks automatically.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            ScaiPrimaryButton(
                                text = if (saving) {
                                    "Activating..."
                                } else {
                                    "Activate learning plan"
                                },
                                onClick = {
                                    activatePlan()
                                },
                                enabled = !saving
                            )
                        }
                    }
                }

                LearningPlanStatus.ACTIVE -> {
                    StatusMessage(
                        title = "Plan active",
                        description = "Complete your activities to make progress."
                    )
                }

                LearningPlanStatus.PAUSED -> {
                    StatusMessage(
                        title = "Plan paused",
                        description = "Activities are disabled while this plan is paused."
                    )
                }

                LearningPlanStatus.COMPLETED -> {
                    StatusMessage(
                        title = "Plan completed",
                        description = "You have completed this learning plan."
                    )
                }

                LearningPlanStatus.CANCELLED -> {
                    StatusMessage(
                        title = "Plan cancelled",
                        description = "This learning plan has been cancelled."
                    )
                }
            }

            // DAY-WISE ROADMAP

            ScaiSectionTitle(
                title = "Your learning roadmap",
                description = "Work through each day and complete its activities."
            )

            currentPlan.days.forEach { day ->
                LearningDayCard(
                    day = day,
                    enabled = canCompleteActivities,
                    onDayCompletionChanged = { completed ->
                        updateDay(
                            day.dayNumber,
                            completed
                        )
                    },
                    onActivityCompletionChanged = { activity, completed ->
                        updateActivity(
                            day.dayNumber,
                            activity.id,
                            completed
                        )
                    },
                    onResourceClick = { resource ->
                        openLearningResource(resource)
                    }
                )
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}

// =====================================================
// STATUS MESSAGE
// =====================================================

@Composable
private fun StatusMessage(
    title: String,
    description: String
) {
    ScaiCard {
        Column(
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// =====================================================
// PLAN METADATA
// =====================================================

@Composable
private fun PlanMetadata(
    value: String
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Text(
            text = value,
            modifier = Modifier.padding(
                horizontal = 10.dp,
                vertical = 6.dp
            ),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

// =====================================================
// DATE FORMATTING
// =====================================================

private fun formatDate(timestamp: Long): String {
    return SimpleDateFormat(
        "dd MMM yyyy",
        Locale.getDefault()
    ).format(Date(timestamp))
}

// =====================================================
// SUMMARY ROW
// =====================================================

@Composable
private fun SummaryRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.width(12.dp))

        Text(
            text = value,
            fontWeight = FontWeight.Medium,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

// =====================================================
// LEARNING DAY CARD
// =====================================================

@Composable
private fun LearningDayCard(
    day: LearningDay,
    enabled: Boolean,
    onDayCompletionChanged: (Boolean) -> Unit,
    onActivityCompletionChanged: (LearningActivity, Boolean) -> Unit,
    onResourceClick: (LearningResource) -> Unit
) {
    ScaiCard {
        Column(
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            // DAY HEADER

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "DAY ${day.dayNumber}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = day.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = "${day.estimatedMinutes} minutes",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (day.scheduledDate > 0L) {
                        Text(
                            text = formatDate(day.scheduledDate),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Checkbox(
                    checked = day.isCompleted,
                    enabled = enabled,
                    onCheckedChange = onDayCompletionChanged
                )
            }

            // OBJECTIVES

            if (day.objectives.isNotEmpty()) {
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant
                )

                Text(
                    text = "Objectives",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )

                day.objectives.forEach { objective ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "•",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text(
                            text = objective,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // ACTIVITIES

            if (day.activities.isNotEmpty()) {
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant
                )

                Text(
                    text = "Activities",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )

                day.activities.forEachIndexed { index, activity ->
                    ActivityItem(
                        activity = activity,
                        enabled = enabled,
                        onCompletionChanged = { completed ->
                            onActivityCompletionChanged(
                                activity,
                                completed
                            )
                        },
                        onResourceClick = onResourceClick
                    )

                    if (index != day.activities.lastIndex) {
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                }
            }
        }
    }
}

// =====================================================
// ACTIVITY ITEM
// =====================================================

@Composable
private fun ActivityItem(
    activity: LearningActivity,
    enabled: Boolean,
    onCompletionChanged: (Boolean) -> Unit,
    onResourceClick: (LearningResource) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            Checkbox(
                checked = activity.isCompleted,
                enabled = enabled,
                onCheckedChange = onCompletionChanged
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(top = 10.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text(
                    text = activity.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )

                Text(
                    text = "${activity.type.name.replace("_", " ")} · " +
                        "${activity.estimatedMinutes} min",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (activity.description.isNotBlank()) {
                    Text(
                        text = activity.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // LEARNING RESOURCES

        if (activity.resources.isNotEmpty()) {
            Column(
                modifier = Modifier.padding(start = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Learning resources",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                activity.resources.forEach { resource ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onResourceClick(resource)
                            },
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.outlineVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = resource.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )

                            Text(
                                text = buildString {
                                    append(resource.type.name.replace("_", " "))

                                    if (resource.provider.isNotBlank()) {
                                        append(" · ")
                                        append(resource.provider)
                                    }
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Text(
                                text = "Open resource  ↗",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
