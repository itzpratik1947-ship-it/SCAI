package com.studentcompanionai.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.AIChatActionManager
import com.studentcompanionai.app.data.LearningCoachProfile
import com.studentcompanionai.app.data.LearningPlan
import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.data.StudyAIService
import com.studentcompanionai.app.data.TaskActionResult
import com.studentcompanionai.app.data.TaskActionStatus
import com.studentcompanionai.app.ui.components.ScaiIconButton
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiTopBar
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class ChatMessage(
    val text: String,
    val isUser: Boolean
)

private enum class AITabMode {
    CHAT,
    PLANNER
}

@Composable
fun AIChatScreen(
    onMenuClick: () -> Unit,
    onWikipediaClick: () -> Unit,
    onPlanGenerated: (LearningPlan) -> Unit = {}
) {
    val colors = MaterialTheme.colorScheme
    val context = LocalContext.current.applicationContext
    val currentUid = FirebaseAuth.getInstance().currentUser?.uid

    val aiService = remember { StudyAIService() }

    val studentStorage = remember(context, currentUid) {
        StudentStorage(context, currentUid)
    }

    val taskActionManager = remember(studentStorage, currentUid) {
        currentUid?.let { uid ->
            AIChatActionManager(
                storage = studentStorage,
                accountUid = uid
            )
        }
    }

    var selectedMode by remember(currentUid) {
        mutableStateOf(AITabMode.CHAT)
    }

    var learnerProfile by remember(currentUid) {
        mutableStateOf<LearningCoachProfile?>(null)
    }

    var learnerContext by remember(currentUid) {
        mutableStateOf("")
    }

    var isProfileLoading by remember(currentUid) {
        mutableStateOf(true)
    }

    var profileLoadError by remember(currentUid) {
        mutableStateOf(false)
    }

    LaunchedEffect(currentUid) {
        learnerProfile = null
        learnerContext = ""
        profileLoadError = false

        if (currentUid == null) {
            isProfileLoading = false
            profileLoadError = true
            return@LaunchedEffect
        }

        isProfileLoading = true

        try {
            val profile = withContext(Dispatchers.IO) {
                studentStorage.loadLearningCoachProfile()
            }

            if (FirebaseAuth.getInstance().currentUser?.uid != currentUid) {
                return@LaunchedEffect
            }

            learnerProfile = profile
            learnerContext = profile?.let { buildLearnerContext(it) } ?: ""
        } catch (exception: CancellationException) {
            throw exception
        } catch (exception: Exception) {
            profileLoadError = true
            android.util.Log.e(
                "AIChatScreen",
                "Unable to load learner profile",
                exception
            )
        } finally {
            if (FirebaseAuth.getInstance().currentUser?.uid == currentUid) {
                isProfileLoading = false
            }
        }
    }

    val messages = remember(currentUid) {
        mutableStateListOf(
            ChatMessage(
                text = """
                    Welcome to Student Companion AI!

                    Ask a question, request an explanation, create revision notes, solve a doubt, or practise a topic.

                    You can also ask me to create a task in your Tasks list.
                """.trimIndent(),
                isUser = false
            )
        )
    }

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    var input by remember(currentUid) { mutableStateOf("") }
    var isLoading by remember(currentUid) { mutableStateOf(false) }
    var toolsMenuExpanded by remember { mutableStateOf(false) }

    // Remembers a task-creation request that is waiting for its title/details.
    // The account key ensures this state is never carried into another account.
    var isAwaitingTaskDetails by remember(currentUid) {
        mutableStateOf(false)
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.text) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    fun sendMessage() {
        val question = input.trim()

        if (question.isBlank() || isLoading || isProfileLoading) return

        if (currentUid == null ||
            FirebaseAuth.getInstance().currentUser?.uid != currentUid
        ) {
            messages.add(
                ChatMessage(
                    "Please sign in to use your AI Learning Coach.",
                    false
                )
            )
            return
        }

        input = ""
        messages.add(ChatMessage(question, true))
        messages.add(ChatMessage("", false))

        val answerIndex = messages.lastIndex
        isLoading = true

        scope.launch {
            try {
                if (FirebaseAuth.getInstance().currentUser?.uid != currentUid) {
                    throw IllegalStateException(
                        "Your account changed. Please sign in again."
                    )
                }

                // Task actions are handled locally. If a previous message
                // started task creation and asked for details, interpret the
                // next relevant message as those details instead of sending
                // it to Gemini as an unrelated educational question.
                var taskActionHandled = false

                if (isAwaitingTaskDetails) {
                    when {
                        isTaskCreationCancellation(question) -> {
                            isAwaitingTaskDetails = false
                            taskActionHandled = true

                            if (
                                FirebaseAuth.getInstance().currentUser?.uid == currentUid &&
                                answerIndex in messages.indices
                            ) {
                                messages[answerIndex] = ChatMessage(
                                    "Task creation cancelled.",
                                    false
                                )
                            }
                        }

                        isClearlyUnrelatedQuestion(question) -> {
                            // The user changed direction. Clear the pending
                            // task request and let Gemini answer normally.
                            isAwaitingTaskDetails = false
                        }

                        else -> {
                            val taskResult = withContext(Dispatchers.IO) {
                                taskActionManager?.handleTaskCommand(
                                    prepareTaskCreationCommand(
                                        "create a task ${normalizeTaskDetails(question)}"
                                    )
                                )
                            }

                            if (
                                taskResult != null &&
                                taskResult.status != TaskActionStatus.NOT_A_TASK_COMMAND
                            ) {
                                taskActionHandled = true
                                isAwaitingTaskDetails =
                                    taskResult.status == TaskActionStatus.NEEDS_TASK_DETAILS

                                if (
                                    FirebaseAuth.getInstance().currentUser?.uid == currentUid &&
                                    answerIndex in messages.indices
                                ) {
                                    messages[answerIndex] = ChatMessage(
                                        formatTaskActionResult(taskResult),
                                        false
                                    )
                                }
                            } else {
                                isAwaitingTaskDetails = false
                            }
                        }
                    }
                } else if (shouldAttemptTaskCreation(question)) {
                    val taskResult = withContext(Dispatchers.IO) {
                        taskActionManager?.handleTaskCommand(
                            prepareTaskCreationCommand(question)
                        )
                    }

                    if (
                        taskResult != null &&
                        taskResult.status != TaskActionStatus.NOT_A_TASK_COMMAND
                    ) {
                        taskActionHandled = true
                        isAwaitingTaskDetails =
                            taskResult.status == TaskActionStatus.NEEDS_TASK_DETAILS

                        if (
                            FirebaseAuth.getInstance().currentUser?.uid == currentUid &&
                            answerIndex in messages.indices
                        ) {
                            messages[answerIndex] = ChatMessage(
                                formatTaskActionResult(taskResult),
                                false
                            )
                        }
                    }
                }

                if (!taskActionHandled) {
                    if (FirebaseAuth.getInstance().currentUser?.uid != currentUid) {
                        throw IllegalStateException(
                            "Your account changed. Please sign in again."
                        )
                    }

                    val answer = aiService.generateReply(
                        userMessage = question,
                        learnerContext = learnerContext,
                        onPartialResponse = { partial ->
                            if (
                                FirebaseAuth.getInstance().currentUser?.uid == currentUid &&
                                answerIndex in messages.indices
                            ) {
                                messages[answerIndex] = ChatMessage(partial, false)
                            }
                        }
                    )

                    if (
                        FirebaseAuth.getInstance().currentUser?.uid == currentUid &&
                        answerIndex in messages.indices
                    ) {
                        messages[answerIndex] = ChatMessage(answer, false)
                    }
                }
            } catch (exception: CancellationException) {
                throw exception
            } catch (exception: Exception) {
                android.util.Log.e(
                    "AIChatScreen",
                    "Unable to complete chat request",
                    exception
                )

                if (FirebaseAuth.getInstance().currentUser?.uid == currentUid &&
                    answerIndex in messages.indices
                ) {
                    messages[answerIndex] = ChatMessage(
                        "I couldn't complete that request. Please try again.",
                        false
                    )
                }
            } finally {
                if (FirebaseAuth.getInstance().currentUser?.uid == currentUid) {
                    isLoading = false
                }
            }
        }
    }

    ScaiScreen(
        scrollable = false,
        modifier = Modifier.fillMaxSize()
    ) {
        ScaiTopBar(
            title = if (selectedMode == AITabMode.CHAT) {
                "Chat"
            } else {
                "Learning planner"
            },
            subtitle = null,
            onMenuClick = onMenuClick,
            actions = {
                Box {
                    ScaiIconButton(
                        symbol = "⋯",
                        contentDescription = "Chat tools",
                        onClick = { toolsMenuExpanded = true }
                    )

                    DropdownMenu(
                        expanded = toolsMenuExpanded,
                        onDismissRequest = { toolsMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Chat view") },
                            onClick = {
                                toolsMenuExpanded = false
                                selectedMode = AITabMode.CHAT
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Learning planner") },
                            onClick = {
                                toolsMenuExpanded = false
                                selectedMode = AITabMode.PLANNER
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Search Wikipedia") },
                            onClick = {
                                toolsMenuExpanded = false
                                onWikipediaClick()
                            }
                        )
                    }
                }
            }
        )

        if (selectedMode == AITabMode.PLANNER) {
            LearningPlanCreateScreen(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                showBackButton = false,
                onPlanGenerated = { plan ->
                    if (FirebaseAuth.getInstance().currentUser?.uid == currentUid) {
                        onPlanGenerated(plan)
                    }
                }
            )
        } else {
            if (profileLoadError) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    color = colors.surfaceVariant,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "Your learner profile could not be loaded. AI responses may not be personalised.",
                        color = colors.onSurfaceVariant,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(11.dp)
                    )
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    top = 10.dp,
                    bottom = 12.dp
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(messages) { _, message ->
                    ChatBubble(message = message)
                }

                if (isLoading && messages.lastOrNull()?.text.isNullOrBlank()) {
                    item {
                        Row(
                            modifier = Modifier.padding(start = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Thinking...",
                                color = colors.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                shape = RoundedCornerShape(20.dp),
                color = colors.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(
                        horizontal = 14.dp,
                        vertical = 9.dp
                    ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 10.dp),
                        enabled = !isLoading && !isProfileLoading,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = colors.onSurface
                        ),
                        cursorBrush = SolidColor(colors.onSurface),
                        maxLines = 5,
                        decorationBox = { innerTextField ->
                            Box {
                                if (input.isEmpty()) {
                                    Text(
                                        text = when {
                                            isProfileLoading -> "Loading learner profile..."
                                            isLoading -> "Generating response..."
                                            else -> "Ask anything..."
                                        },
                                        color = colors.onSurfaceVariant,
                                        fontSize = 14.sp
                                    )
                                }
                                innerTextField()
                            }
                        }
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Surface(
                        onClick = { sendMessage() },
                        enabled = input.isNotBlank() &&
                            !isLoading &&
                            !isProfileLoading,
                        shape = CircleShape,
                        color = if (input.isNotBlank() &&
                            !isLoading &&
                            !isProfileLoading
                        ) {
                            colors.onSurface
                        } else {
                            colors.surface
                        },
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "↑",
                                color = if (input.isNotBlank() &&
                                    !isLoading &&
                                    !isProfileLoading
                                ) {
                                    colors.surface
                                } else {
                                    colors.onSurfaceVariant
                                },
                                fontSize = 22.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Text(
                text = "AI can make mistakes. Verify important information.",
                color = colors.onSurfaceVariant,
                fontSize = 10.sp,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 7.dp, bottom = 5.dp)
            )
        }
    }
}

// Detect an explicit cancellation while SCAI is waiting for task details.
private fun isTaskCreationCancellation(message: String): Boolean {
    return Regex(
        """(?i)^\s*(?:cancel|cancel it|never mind|nevermind|forget it|stop|stop creating(?: the)? task|don't create(?: the)? task|do not create(?: the)? task)\s*[.!]*$"""
    ).matches(message)
}

// If the user changes direction while task details are pending, do not
// accidentally save an educational question as a task title.
private fun isClearlyUnrelatedQuestion(message: String): Boolean {
    val text = message.trim()

    val questionOrInstructionStart = Regex(
        """(?i)^(?:how|what|why|when|where|which|who|explain|describe|teach|tell me|show me|can you explain|could you explain|i want to know|i was wondering|is it|are there|does it|should i)\b"""
    )

    return questionOrInstructionStart.containsMatchIn(text) ||
        text.endsWith("?")
}

// Avoid treating explanations or negative instructions as task creation.
// The action manager remains responsible for final command detection.
private fun shouldAttemptTaskCreation(message: String): Boolean {
    val text = message.trim()
    if (text.isEmpty()) return false

    val informationalStart = Regex(
        """(?i)^(how|what|why|when|where|which|explain|describe|teach|tell|show|is|are|does|should i|can i|could i|do not|don't|never)\b"""
    )
    if (informationalStart.containsMatchIn(text)) return false

    val informationalPhrase = Regex(
        """(?i)\b(how to|how do i|what is|what happens if)\s+(?:\w+\s+){0,3}(create|add|make|save)\b"""
    )
    if (informationalPhrase.containsMatchIn(text)) return false

    val negativeCommand = Regex(
        """(?i)\b(don't|do not|never)\s+(?:\w+\s+){0,3}(create|add|make|save)\b"""
    )
    if (negativeCommand.containsMatchIn(text)) return false

    return true
}

// Normalize the user's follow-up before turning it into a task command.
// Keep the requested action (for example, "complete") while removing
// conversational framing (for example, "I want to") and possessives.
private fun normalizeTaskDetails(message: String): String {
    var title = message.trim()

    title = title.replaceFirst(
        Regex(
            """(?i)^(?:i\s+want\s+to|i\s+need\s+to|i\s+have\s+to|i\s+would\s+like\s+to|i'd\s+like\s+to|please)\s+"""
        ),
        ""
    )

    title = title.replace(
        Regex("""(?i)\bmy\s+"""),
        ""
    )

    title = title
        .replace(Regex("""^[\s.!?,;:]+|[\s.!?,;:]+$"""), "")
        .trim()

    if (title.isEmpty()) return title

    return title.replaceFirstChar { character ->
        if (character.isLowerCase()) character.titlecase() else character.toString()
    }
}

// Convert a few common direct requests to the simple command shape
// supported by the existing AIChatActionManager. No Gemini text is
// interpreted as permission to change saved tasks.
private fun prepareTaskCreationCommand(message: String): String {
    val direct = message.trim().replaceFirst(
        Regex("""(?i)^(?:(?:please\s+)|(?:(?:can|could|would)\s+you\s+(?:please\s+)?))"""),
        ""
    ).trim()

    val addToList = Regex(
        """(?i)^add\s+(.+?)\s+to\s+my\s+(?:tasks|task\s+list)\s*[.!?]*$"""
    ).matchEntire(direct)

    if (addToList != null) {
        val title = addToList.groupValues[1].trim()
        if (title.isNotBlank()) return "create a task $title"
    }

    val directTask = Regex(
        """(?i)^(?:create|add|make|save)\s+(?:me\s+)?(?:a\s+)?(?:new\s+)?(?:task|to-do|todo)\s+(?:(?:for|about|named|called|to)\s+)?(.+?)\s*[.!?]*$"""
    ).matchEntire(direct)

    if (directTask != null) {
        val title = directTask.groupValues[1].trim().trimEnd('.', '!', '?')
        if (title.isNotBlank()) return "create a task $title"
    }

    return message
}

private fun formatTaskActionResult(result: TaskActionResult): String {
    return when (result.status) {
        TaskActionStatus.CREATED -> {
            val title = result.task?.title
            if (title.isNullOrBlank()) {
                "Task created successfully. You can find it in Tasks."
            } else {
                "Task created: **$title**\n\nYou can find it in Tasks."
            }
        }
        TaskActionStatus.ALREADY_EXISTS -> {
            val title = result.task?.title
            if (title.isNullOrBlank()) {
                result.message
            } else {
                "A pending task named **$title** already exists in your Tasks list."
            }
        }
        TaskActionStatus.NEEDS_TASK_DETAILS,
        TaskActionStatus.ACCOUNT_CHANGED,
        TaskActionStatus.FAILED,
        TaskActionStatus.NOT_A_TASK_COMMAND -> result.message
    }
}

// ==================================================
// LEARNER CONTEXT BUILDER
// ==================================================

private fun buildLearnerContext(profile: LearningCoachProfile): String {
    return buildString {
        appendLine("LEARNER PROFILE")
        appendLine("Use these details to personalise educational assistance.")
        appendLine()

        appendLine("PERSONAL INFORMATION")
        appendLine("Preferred name: ${profile.preferredName.ifBlank { "Not provided" }}")
        appendLine("User type: ${profile.userType.displayName}")

        // Date of birth is intentionally excluded.

        appendLine()
        appendLine("EDUCATIONAL BACKGROUND")
        appendLine("Education category: ${profile.educationCategory.displayName}")
        appendLine("Qualification: ${profile.qualification.ifBlank { "Not provided" }}")
        appendLine("Stream: ${profile.stream.ifBlank { "Not provided" }}")
        appendLine("Specialization: ${profile.specialization.ifBlank { "Not provided" }}")
        appendLine("Academic year: ${profile.academicYear.ifBlank { "Not provided" }}")
        appendLine("Semester: ${profile.semester.ifBlank { "Not provided" }}")
        appendLine("Institution: ${profile.institution.ifBlank { "Not provided" }}")
        appendLine("Board or university: ${profile.boardOrUniversity.ifBlank { "Not provided" }}")
        appendLine("Academic subjects: ${profile.subjects.joinToString().ifBlank { "Not provided" }}")

        appendLine()
        appendLine("LEARNING GOALS")
        appendLine("Main goal: ${profile.learningGoal.ifBlank { "Not configured" }}")
        appendLine("Main subject or skill: ${profile.subject.ifBlank { "Not configured" }}")
        appendLine("Current learning level: ${profile.currentLevel.displayName}")
        appendLine("Target duration: ${profile.targetDays} days")
        appendLine("Daily study target: ${profile.dailyStudyMinutes} minutes")
        appendLine("Preferred learning style: ${profile.preferredLearningStyle.displayName}")
        appendLine("Secondary goals: ${profile.secondaryGoals.joinToString().ifBlank { "None provided" }}")
        appendLine("Target achievement: ${profile.targetAchievement.ifBlank { "Not specified" }}")

        if (profile.learningTracks.isNotEmpty()) {
            appendLine()
            appendLine("ADDITIONAL LEARNING TRACKS")
            profile.learningTracks.forEach { track ->
                appendLine(
                    "- ${track.title}; " +
                        "Category: ${track.category.ifBlank { "Not specified" }}; " +
                        "Level: ${track.currentLevel.displayName}; " +
                        "Target: ${track.targetAchievement.ifBlank { "Not specified" }}; " +
                        "Duration: ${track.targetDays} days; " +
                        "Primary: ${track.isPrimary}"
                )
            }
        }

        appendLine()
        appendLine("DAILY SCHEDULE")
        appendLine("Wake time: ${profile.wakeTime.ifBlank { "Not specified" }}")
        appendLine("Sleep time: ${profile.sleepTime.ifBlank { "Not specified" }}")
        appendLine("Available days: ${profile.availableDays.joinToString().ifBlank { "Not specified" }}")
        appendLine("Available study slots:")
        if (profile.availableSlots.isEmpty()) {
            appendLine("- Not specified")
        } else {
            profile.availableSlots.forEach { slot ->
                appendLine(
                    "- ${slot.day}: ${slot.startTime} to ${slot.endTime}" +
                        if (slot.label.isNotBlank()) " (${slot.label})" else ""
                )
            }
        }

        appendLine("Occupied schedule slots:")
        if (profile.occupiedSlots.isEmpty()) {
            appendLine("- Not specified")
        } else {
            profile.occupiedSlots.forEach { slot ->
                appendLine(
                    "- ${slot.day}: ${slot.startTime} to ${slot.endTime}" +
                        if (slot.label.isNotBlank()) " (${slot.label})" else ""
                )
            }
        }

        appendLine()
        appendLine("FOCUS PREFERENCES")
        appendLine("Focus session duration: ${profile.focusDuration} minutes")
        appendLine("Break duration: ${profile.breakDuration} minutes")
        appendLine("Daily focus target: ${profile.dailyFocusTarget} sessions")
        appendLine("Preferred focus time: ${profile.preferredFocusTime.displayName}")

        appendLine()
        appendLine("LEARNING PREFERENCES")
        appendLine("Preferred language: ${profile.preferredLanguage.ifBlank { "Not specified" }}")
        appendLine("Preferred difficulty: ${profile.preferredDifficulty.displayName}")
        appendLine("Areas of difficulty: ${profile.areasOfDifficulty.joinToString().ifBlank { "Not specified" }}")

        appendLine()
        appendLine("NOTIFICATION PREFERENCES")
        appendLine("Study reminders: ${profile.notificationPreferences.studyReminders}")
        appendLine("Learning plan reminders: ${profile.notificationPreferences.learningPlanReminders}")
        appendLine("Focus reminders: ${profile.notificationPreferences.focusReminders}")
        appendLine("Daily progress summary: ${profile.notificationPreferences.dailyProgressSummary}")

        appendLine()
        appendLine("Profile completed: ${profile.profileCompleted}")
    }
}

// ==================================================
// CHAT BUBBLE
// ==================================================

@Composable
private fun ChatBubble(message: ChatMessage) {
    val colors = MaterialTheme.colorScheme

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (message.isUser) 16.dp else 5.dp,
                bottomEnd = if (message.isUser) 5.dp else 16.dp
            ),
            color = if (message.isUser) colors.primaryContainer else colors.surfaceVariant,
            modifier = Modifier.fillMaxWidth(if (message.isUser) 0.86f else 0.96f)
        ) {
            if (message.isUser) {
                Text(
                    text = message.text,
                    color = colors.onPrimaryContainer,
                    fontSize = 14.sp,
                    lineHeight = 21.sp,
                    modifier = Modifier.padding(14.dp)
                )
            } else {
                MarkdownMessage(
                    text = message.text.ifBlank { "Thinking..." },
                    modifier = Modifier.padding(14.dp)
                )
            }
        }
    }
}

// ==================================================
// MARKDOWN MESSAGE RENDERER
// ==================================================

@Composable
private fun MarkdownMessage(
    text: String,
    modifier: Modifier = Modifier
) {
    val colors = MaterialTheme.colorScheme
    val lines = text.split("\n")

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        var index = 0
        while (index < lines.size) {
            val line = lines[index]

            if (line.trimStart().startsWith("```")) {
                val language = line.trim().removePrefix("```").trim()
                index++
                val codeLines = mutableListOf<String>()

                while (index < lines.size &&
                    !lines[index].trimStart().startsWith("```")
                ) {
                    codeLines.add(lines[index])
                    index++
                }

                if (index < lines.size &&
                    lines[index].trimStart().startsWith("```")
                ) {
                    index++
                }

                CodeMessageBlock(
                    code = codeLines.joinToString("\n"),
                    language = language
                )
                continue
            }

            if (line.isBlank()) {
                Spacer(Modifier.height(4.dp))
                index++
                continue
            }

            val trimmed = line.trim()
            when {
                trimmed.startsWith("### ") -> {
                    Text(
                        text = inlineMarkdown(
                            trimmed.removePrefix("### "),
                            colors.onSurface,
                            colors.primary,
                            colors.surfaceVariant
                        ),
                        color = colors.onSurface,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                trimmed.startsWith("## ") -> {
                    Text(
                        text = inlineMarkdown(
                            trimmed.removePrefix("## "),
                            colors.onSurface,
                            colors.primary,
                            colors.surfaceVariant
                        ),
                        color = colors.onSurface,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                trimmed.startsWith("# ") -> {
                    Text(
                        text = inlineMarkdown(
                            trimmed.removePrefix("# "),
                            colors.onSurface,
                            colors.primary,
                            colors.surfaceVariant
                        ),
                        color = colors.onSurface,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            text = "•",
                            color = colors.primary,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = inlineMarkdown(
                                trimmed.drop(2),
                                colors.onSurface,
                                colors.primary,
                                colors.surfaceVariant
                            ),
                            color = colors.onSurface,
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Regex("""^\d+[.)]\s+""").containsMatchIn(trimmed) -> {
                    Text(
                        text = inlineMarkdown(
                            trimmed,
                            colors.onSurface,
                            colors.primary,
                            colors.surfaceVariant
                        ),
                        color = colors.onSurface,
                        fontSize = 14.sp,
                        lineHeight = 21.sp
                    )
                }
                trimmed.startsWith("> ") -> {
                    Surface(
                        color = colors.surfaceVariant,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = inlineMarkdown(
                                trimmed.removePrefix("> "),
                                colors.onSurfaceVariant,
                                colors.primary,
                                colors.surface
                            ),
                            color = colors.onSurfaceVariant,
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
                else -> {
                    Text(
                        text = inlineMarkdown(
                            line,
                            colors.onSurface,
                            colors.primary,
                            colors.surfaceVariant
                        ),
                        color = colors.onSurface,
                        fontSize = 14.sp,
                        lineHeight = 21.sp
                    )
                }
            }
            index++
        }
    }
}

// ==================================================
// INLINE MARKDOWN FORMATTER
// ==================================================

private fun inlineMarkdown(
    text: String,
    textColor: Color,
    accentColor: Color,
    codeBackground: Color
): AnnotatedString {
    // Match **bold** or `inline code`, without interpreting ordinary text.
    val pattern = Regex("""(\*\*.+?\*\*|`[^`]+`)""")

    return buildAnnotatedString {
        var currentIndex = 0
        pattern.findAll(text).forEach { match ->
            append(text.substring(currentIndex, match.range.first))
            val token = match.value

            when {
                token.startsWith("**") && token.endsWith("**") -> {
                    withStyle(
                        SpanStyle(
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                    ) {
                        append(token.removePrefix("**").removeSuffix("**"))
                    }
                }
                token.startsWith("`") && token.endsWith("`") -> {
                    withStyle(
                        SpanStyle(
                            color = accentColor,
                            background = codeBackground,
                            fontFamily = FontFamily.Monospace
                        )
                    ) {
                        append(token.removePrefix("`").removeSuffix("`"))
                    }
                }
            }
            currentIndex = match.range.last + 1
        }
        append(text.substring(currentIndex))
    }
}

// ==================================================
// PROGRAMMING CODE BLOCK
// ==================================================

@Composable
private fun CodeMessageBlock(code: String, language: String) {
    val clipboardManager = LocalClipboardManager.current
    val colors = MaterialTheme.colorScheme

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = colors.surfaceVariant,
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(11.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.ifBlank { "CODE" }.uppercase(),
                    color = colors.onSurfaceVariant,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(code))
                    }
                ) {
                    Text(
                        text = "Copy code",
                        color = colors.onSurface,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(Modifier.height(5.dp))

            SelectionContainer {
                Text(
                    text = code,
                    color = colors.onSurface,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 19.sp,
                    softWrap = false,
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 4.dp)
                )
            }
        }
    }
}