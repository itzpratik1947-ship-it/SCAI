package com.studentcompanionai.app

import android.app.Application
import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.DailyTaskScheduler

class TaskAutomationApplication : Application() {

    private lateinit var auth: FirebaseAuth

    private var scheduledUid: String? = null

    private val authListener =
        FirebaseAuth.AuthStateListener { firebaseAuth ->

            val currentUid = firebaseAuth.currentUser?.uid

            if (currentUid == scheduledUid) {
                return@AuthStateListener
            }

            val previousUid = scheduledUid
            scheduledUid = currentUid

            previousUid?.let { uid ->
                DailyTaskScheduler.cancel(
                    applicationContext,
                    uid
                )
            }

            currentUid?.let { uid ->
                DailyTaskScheduler.schedule(
                    applicationContext,
                    uid
                )
            }
        }

    override fun onCreate() {
        super.onCreate()

        instance = this

        auth = FirebaseAuth.getInstance()
        auth.addAuthStateListener(authListener)
    }

    companion object {

        @Volatile
        private var instance: TaskAutomationApplication? = null

        fun getAppContext(): Context {
            return checkNotNull(instance) {
                "TaskAutomationApplication has not been initialized."
            }.applicationContext
        }
    }
}