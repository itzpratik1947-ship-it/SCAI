
package com.studentcompanionai.app.data

class InitialKnowledgeAnalyzer {

    /**
     * Converts individual question evaluations into
     * topic-wise knowledge measurements.
     */
    fun analyzeTopics(
        questions: List<InitialAssessmentQuestion>,
        evaluations: List<AssessmentAnswerEvaluation>
    ): List<TopicKnowledgeResult> {

        require(questions.isNotEmpty()) {
            "No assessment questions are available for analysis."
        }

        val questionsById = questions.associateBy { it.id }

        require(questionsById.size == questions.size) {
            "Duplicate question IDs were found."
        }

        val evaluationsById = evaluations.associateBy {
            it.questionId
        }

        require(evaluationsById.size == evaluations.size) {
            "Duplicate evaluation IDs were found."
        }

        require(evaluationsById.keys.all {
            questionsById.containsKey(it)
        }) {
            "An evaluation references an unknown question."
        }

        val topicGroups = questions.groupBy {
            it.topic.trim()
        }

        return topicGroups.map { (topic, topicQuestions) ->

            val topicEvaluations = topicQuestions.map { question ->

                evaluationsById[question.id]
                    ?: throw IllegalStateException(
                        "Missing evaluation for question ${question.id}."
                    )
            }

            val totalQuestions = topicQuestions.size

            val totalMarks = topicEvaluations.sumOf {
                it.maximumMarks.toDouble()
            }

            val awardedMarks = topicEvaluations.sumOf {
                it.awardedMarks
            }

            val correctAnswers = topicEvaluations.count {
                it.isCorrect
            }

            val scorePercent = if (totalMarks <= 0.0) {
                0
            } else {
                ((awardedMarks / totalMarks) * 100)
                    .toInt()
                    .coerceIn(0, 100)
            }

            val knowledgeLevel = determineKnowledgeLevel(
                scorePercent
            )

            val strengths = mutableListOf<String>()
            val weaknesses = mutableListOf<String>()

            topicQuestions.zip(topicEvaluations).forEach {
                    (question, evaluation) ->

                val feedback = evaluation.feedback.trim()

                when {
                    evaluation.awardedMarks >=
                        evaluation.maximumMarks &&
                        evaluation.isCorrect -> {

                        strengths.add(
                            feedback.ifBlank {
                                "Demonstrated understanding of: ${question.question}"
                            }
                        )
                    }

                    evaluation.awardedMarks > 0.0 -> {

                        strengths.add(
                            "Partial understanding of: ${question.question}"
                        )

                        weaknesses.add(
                            feedback.ifBlank {
                                "Some concepts need further improvement."
                            }
                        )
                    }

                    else -> {

                        weaknesses.add(
                            feedback.ifBlank {
                                "Needs improvement in: ${question.question}"
                            }
                        )
                    }
                }
            }

            TopicKnowledgeResult(
                topic = topic,
                totalQuestions = totalQuestions,
                correctAnswers = correctAnswers,
                scorePercent = scorePercent,
                knowledgeLevel = knowledgeLevel,
                identifiedStrengths = strengths.distinct(),
                identifiedWeaknesses = weaknesses.distinct()
            )
        }.sortedBy {
            it.scorePercent
        }
    }

    /**
     * Overall knowledge score based on awarded marks,
     * not simply the number of correct questions.
     */
    fun calculateOverallScore(
        evaluations: List<AssessmentAnswerEvaluation>
    ): Int {

        if (evaluations.isEmpty()) {
            return 0
        }

        val totalMarks = evaluations.sumOf {
            it.maximumMarks.toDouble()
        }

        val awardedMarks = evaluations.sumOf {
            it.awardedMarks
        }

        if (totalMarks <= 0.0) {
            return 0
        }

        return ((awardedMarks / totalMarks) * 100)
            .toInt()
            .coerceIn(0, 100)
    }

    /**
     * Determines a provisional knowledge category.
     *
     * These thresholds are product heuristics, not
     * scientifically validated mastery standards.
     */
    private fun determineKnowledgeLevel(
        scorePercent: Int
    ): String {

        return when {
            scorePercent >= 85 ->
                "Strong"

            scorePercent >= 65 ->
                "Good"

            scorePercent >= 40 ->
                "Developing"

            else ->
                "Needs Improvement"
        }
    }
}
