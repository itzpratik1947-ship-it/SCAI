
package com.studentcompanionai.app.ui

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.data.Subject
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import com.studentcompanionai.app.ui.components.ScaiSecondaryButton
import com.studentcompanionai.app.ui.components.ScaiTopBar

@Composable
fun SubjectsScreen(
    context: Context,
    onBackClick: () -> Unit,
    onSubjectsChanged: (Int) -> Unit = {},
    refreshKey: Int = 0,
    uid: String? = FirebaseAuth.getInstance().currentUser?.uid
) {

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    val subjects = remember(uid) {
        mutableStateListOf<Subject>()
    }

    var subjectName by remember(uid) {
        mutableStateOf("")
    }

    var showAddSubject by remember(uid) {
        mutableStateOf(false)
    }

    var nextSubjectId by remember(uid) {
        mutableStateOf(1)
    }

    var deleteSubject by remember(uid) {
        mutableStateOf<Subject?>(null)
    }

    // -----------------------------------------
    // LOAD SUBJECTS
    // -----------------------------------------

    LaunchedEffect(refreshKey, uid) {

        if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
            return@LaunchedEffect
        }

        val saved = storage.loadSubjects()

        if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
            return@LaunchedEffect
        }

        subjects.clear()
        subjects.addAll(saved)

        val highestId = saved.maxOfOrNull { it.id } ?: 0

        nextSubjectId = if (highestId < Int.MAX_VALUE) {
            highestId + 1
        } else {
            Int.MAX_VALUE
        }

        onSubjectsChanged(subjects.size)
    }

    // -----------------------------------------
    // SUBJECT STATISTICS
    // -----------------------------------------

    val allTasks = remember(refreshKey, uid) {
        storage.loadTasks()
    }

    val focusSessions = remember(refreshKey, uid) {
        storage.loadFocusSessions()
    }

    val totalTaskCount = allTasks.size

    val completedTaskCount = allTasks.count {
        it.isCompleted
    }

    val totalFocusMinutes = focusSessions.sumOf {
        it.minutes
    }

    val subjectsWithActivity = subjects.count { subject ->

        allTasks.any { it.subjectId == subject.id } ||
            focusSessions.any { it.subjectId == subject.id }
    }

    // -----------------------------------------
    // SCREEN
    // One continuous scrollable container.
    // -----------------------------------------

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = 20.dp,
            vertical = 14.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        // -------------------------------------
        // HEADER
        // -------------------------------------

        item(key = "subjects_header") {

            Column {

                ScaiTopBar(
                    title = "Subjects",
                    subtitle = "Manage your learning areas",
                )

                Spacer(Modifier.height(18.dp))

                Text(
                    text = "Your subjects",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(Modifier.height(6.dp))

                Text(
                    text = "Organise your studies and track your effort across different subjects.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // -------------------------------------
        // OVERVIEW
        // -------------------------------------

        item(key = "subjects_overview") {

            ScaiCard(
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    text = "LEARNING OVERVIEW",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )

                Spacer(Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    SubjectOverviewMetric(
                        value = subjects.size.toString(),
                        label = "Subjects",
                        modifier = Modifier.weight(1f)
                    )

                    SubjectOverviewMetric(
                        value = totalTaskCount.toString(),
                        label = "Tasks",
                        modifier = Modifier.weight(1f)
                    )

                    SubjectOverviewMetric(
                        value = "$totalFocusMinutes",
                        label = "Focus min",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(18.dp))

                ScaiDivider()

                Spacer(Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {

                        Text(
                            text = "Task completion",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(Modifier.height(4.dp))

                        Text(
                            text = "$completedTaskCount of $totalTaskCount tasks completed",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = if (totalTaskCount > 0) {
                            "${(completedTaskCount * 100) / totalTaskCount}%"
                        } else {
                            "0%"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(Modifier.height(10.dp))

                LinearProgressIndicator(
                    progress = {
                        if (totalTaskCount > 0) {
                            completedTaskCount.toFloat() /
                                totalTaskCount.toFloat()
                        } else {
                            0f
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp),
                    color = MaterialTheme.colorScheme.onSurface,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }

        // -------------------------------------
        // SUBJECT LIST HEADER
        // -------------------------------------

        item(key = "subjects_list_header") {

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Column(
                    modifier = Modifier.weight(1f)
                ) {

                    Text(
                        text = "All subjects",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = "${subjects.size} subjects in your learning space",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {

                    Text(
                        text = subjects.size.toString(),
                        modifier = Modifier.padding(
                            horizontal = 12.dp,
                            vertical = 8.dp
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // -------------------------------------
        // EMPTY STATE
        // -------------------------------------

        if (subjects.isEmpty()) {

            item(key = "subjects_empty_state") {

                ScaiCard(
                    modifier = Modifier.fillMaxWidth()
                ) {

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {

                        Surface(
                            modifier = Modifier.size(58.dp),
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {

                            Box(
                                contentAlignment = Alignment.Center
                            ) {

                                Text(
                                    text = "01",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(Modifier.height(18.dp))

                        Text(
                            text = "Start with a subject",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(Modifier.height(8.dp))

                        Text(
                            text = "Create your first subject to organise study tasks and focus sessions.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // -------------------------------------
        // SUBJECT CARDS
        // -------------------------------------

        items(
            items = subjects,
            key = { subject -> subject.id }
        ) { subject ->

            val subjectTasks = allTasks.filter {
                it.subjectId == subject.id
            }

            val subjectFocusMinutes = focusSessions
                .filter {
                    it.subjectId == subject.id
                }
                .sumOf {
                    it.minutes
                }

            val activeSubjectId =
                if (storage.hasActiveFocusSession()) {
                    storage.loadFocusSubjectId()
                } else {
                    null
                }

            SubjectCard(
                subject = subject,
                totalTasks = subjectTasks.size,
                completedTasks = subjectTasks.count {
                    it.isCompleted
                },
                focusMinutes = subjectFocusMinutes,
                isFocusing = activeSubjectId == subject.id,
                onDelete = {
                    deleteSubject = subject
                }
            )
        }

        // -------------------------------------
        // ADD SUBJECT SECTION
        // -------------------------------------

        item(key = "add_subject_section") {

            Column {

                ScaiDivider()

                Spacer(Modifier.height(8.dp))

                ScaiSectionHeading(
                    title = "Add a subject",
                    description = "Create another learning area."
                )

                Spacer(Modifier.height(12.dp))

                ScaiSecondaryButton(
                    text = if (showAddSubject) {
                        "Close form"
                    } else {
                        "Add subject"
                    },
                    onClick = {
                        showAddSubject = !showAddSubject

                        if (!showAddSubject) {
                            subjectName = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // -------------------------------------
        // ADD SUBJECT FORM
        // -------------------------------------

        if (showAddSubject) {

            item(key = "add_subject_form") {

                ScaiCard(
                    modifier = Modifier.fillMaxWidth()
                ) {

                    Text(
                        text = "New subject",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(Modifier.height(6.dp))

                    Text(
                        text = "Enter the name of the subject you want to manage.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(16.dp))

                    OutlinedTextField(
                        value = subjectName,
                        onValueChange = {
                            subjectName = it
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = {
                            Text("Subject name")
                        },
                        placeholder = {
                            Text("e.g. Engineering Mathematics")
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                            focusedBorderColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            focusedLabelColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            cursorColor = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(Modifier.height(18.dp))

                    ScaiPrimaryButton(
                        text = "Save subject",
                        onClick = {

                            val name = subjectName.trim()

                            if (
                                name.isNotEmpty() &&
                                nextSubjectId < Int.MAX_VALUE &&
                                FirebaseAuth.getInstance().currentUser?.uid == uid
                            ) {

                                val newSubject = Subject(
                                    id = nextSubjectId,
                                    name = name
                                )

                                subjects.add(newSubject)
                                nextSubjectId++

                                storage.saveSubjects(subjects)

                                onSubjectsChanged(subjects.size)

                                subjectName = ""
                                showAddSubject = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = subjectName.isNotBlank() &&
                            nextSubjectId < Int.MAX_VALUE
                    )
                }
            }
        }

        // -------------------------------------
        // BOTTOM SPACING
        // -------------------------------------

        item(key = "subjects_bottom_spacing") {
            Spacer(Modifier.height(20.dp))
        }
    }

    // -----------------------------------------
    // DELETE SUBJECT CONFIRMATION
    // -----------------------------------------

    deleteSubject?.let { subject ->

        AlertDialog(
            onDismissRequest = {
                deleteSubject = null
            },
            title = {
                Text("Delete subject?")
            },
            text = {
                Text(
                    "Remove \"${subject.name}\" from your subject list?"
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {

                        if (
                            FirebaseAuth.getInstance().currentUser?.uid == uid
                        ) {

                            subjects.remove(subject)

                            storage.saveSubjects(subjects)

                            onSubjectsChanged(subjects.size)
                        }

                        deleteSubject = null
                    }
                ) {

                    Text(
                        text = "Delete",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        deleteSubject = null
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

// --------------------------------------------------
// OVERVIEW METRIC
// --------------------------------------------------

@Composable
private fun SubjectOverviewMetric(
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {

        Column(
            modifier = Modifier.padding(12.dp)
        ) {

            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(Modifier.height(4.dp))

            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// --------------------------------------------------
// SECTION HEADING
// --------------------------------------------------

@Composable
private fun ScaiSectionHeading(
    title: String,
    description: String
) {

    Column {

        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(Modifier.height(4.dp))

        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// --------------------------------------------------
// SUBJECT CARD
// --------------------------------------------------

@Composable
private fun SubjectCard(
    subject: Subject,
    totalTasks: Int,
    completedTasks: Int,
    focusMinutes: Int,
    isFocusing: Boolean,
    onDelete: () -> Unit
) {

    val progress = if (totalTasks > 0) {
        (completedTasks.toFloat() / totalTasks.toFloat())
            .coerceIn(0f, 1f)
    } else {
        0f
    }

    val status = when {

        isFocusing ->
            "FOCUSING"

        totalTasks > 0 && completedTasks == totalTasks ->
            "COMPLETED"

        completedTasks > 0 ->
            "IN PROGRESS"

        focusMinutes > 0 ->
            "STUDIED"

        else ->
            "NOT STARTED"
    }

    CardContent(
        subject = subject,
        totalTasks = totalTasks,
        completedTasks = completedTasks,
        focusMinutes = focusMinutes,
        progress = progress,
        status = status,
        onDelete = onDelete
    )
}

// --------------------------------------------------
// SUBJECT CARD CONTENT
// --------------------------------------------------

@Composable
private fun CardContent(
    subject: Subject,
    totalTasks: Int,
    completedTasks: Int,
    focusMinutes: Int,
    progress: Float,
    status: String,
    onDelete: () -> Unit
) {

    ScaiCard(
        modifier = Modifier.fillMaxWidth()
    ) {

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {

            Surface(
                modifier = Modifier.size(46.dp),
                shape = RoundedCornerShape(13.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {

                Box(
                    contentAlignment = Alignment.Center
                ) {

                    Text(
                        text = subject.name
                            .trim()
                            .take(1)
                            .uppercase(),
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(Modifier.size(13.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {

                Text(
                    text = subject.name,
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(Modifier.height(5.dp))

                Text(
                    text = status,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.8.sp
                )
            }

            TextButton(
                onClick = onDelete
            ) {

                Text(
                    text = "Delete",
                    color = MaterialTheme.colorScheme.error
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        ScaiDivider()

        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Column(
                modifier = Modifier.weight(1f)
            ) {

                Text(
                    text = "Task completion",
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )

                Spacer(Modifier.height(4.dp))

                Text(
                    text = "$completedTasks of $totalTasks tasks completed",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Text(
                text = "${(progress * 100).toInt()}%",
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(10.dp))

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color = MaterialTheme.colorScheme.onSurface,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )

        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            SubjectOverviewMetric(
                value = focusMinutes.toString(),
                label = "Focus minutes",
                modifier = Modifier.weight(1f)
            )

            SubjectOverviewMetric(
                value = totalTasks.toString(),
                label = "Total tasks",
                modifier = Modifier.weight(1f)
            )
        }
    }
}
