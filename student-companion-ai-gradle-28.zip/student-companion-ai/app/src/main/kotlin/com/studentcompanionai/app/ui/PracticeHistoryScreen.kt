
package com.studentcompanionai.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studentcompanionai.app.data.AdaptiveDifficulty
import com.studentcompanionai.app.data.PerformanceTrend
import com.studentcompanionai.app.data.PracticePerformanceAnalysis
import com.studentcompanionai.app.data.PracticePerformanceAnalyzer
import com.studentcompanionai.app.data.PracticeQuestionType
import com.studentcompanionai.app.data.StoredPracticeResult
import com.studentcompanionai.app.data.TopicPerformanceInsight
import com.studentcompanionai.app.data.TopicPerformanceLevel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class PerformanceMetric(
    val label: String,
    val correct: Int,
    val total: Int
) {
    val accuracy: Int
        get() = if (total == 0) {
            0
        } else {
            (correct * 100) / total
        }
}

@Composable
fun PracticeHistoryScreen(
    results: List<StoredPracticeResult>,
    onBackClick: () -> Unit,
    onClearHistory: () -> Unit = {}
) {
    var showClearDialog by rememberSaveable {
        mutableStateOf(false)
    }

    val dateFormatter = remember {
        SimpleDateFormat(
            "dd MMM yyyy, hh:mm a",
            Locale.getDefault()
        )
    }

    val textColor = MaterialTheme.colorScheme.onBackground
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val surface = MaterialTheme.colorScheme.surface

    val evaluatedAnswers = remember(results) {
        results.flatMap { result ->
            result.answers.filter { it.isEvaluated }
        }
    }

    val totalCorrect = evaluatedAnswers.count {
        it.isCorrect
    }

    val totalEvaluated = evaluatedAnswers.size

    val overallAccuracy = if (totalEvaluated == 0) {
        0
    } else {
        (totalCorrect * 100) / totalEvaluated
    }

    val averageScore = results
        .filter { it.evaluatedAnswers > 0 }
        .map { it.scorePercent }
        .average()
        .takeIf { !it.isNaN() }
        ?.toInt() ?: 0

    /*
     * Keep subject and topic separate.
     *
     * Example:
     * Mathematics -> Algebra
     * Physics -> Algebra
     *
     * These must remain independent metrics.
     */
    val topicMetrics = remember(results) {
        results.flatMap { result ->
            result.answers
                .filter {
                    it.isEvaluated && it.topic.isNotBlank()
                }
                .map { answer ->
                    Triple(
                        result.subject.trim(),
                        answer.topic.trim(),
                        answer
                    )
                }
        }
            .groupBy {
                "${it.first.lowercase()}::${it.second.lowercase()}"
            }
            .map { (_, records) ->

                val subject = records.first().first
                val topic = records.first().second

                PerformanceMetric(
                    label = if (subject.isBlank()) {
                        topic
                    } else {
                        "$subject • $topic"
                    },
                    correct = records.count {
                        it.third.isCorrect
                    },
                    total = records.size
                )
            }
            .sortedWith(
                compareBy<PerformanceMetric> { it.accuracy }
                    .thenByDescending { it.total }
            )
    }

    val difficultyMetrics = remember(evaluatedAnswers) {
        evaluatedAnswers
            .groupBy {
                it.difficulty
                    .trim()
                    .uppercase()
                    .ifBlank { "UNKNOWN" }
            }
            .map { (difficulty, answers) ->
                PerformanceMetric(
                    label = difficulty.lowercase()
                        .replaceFirstChar { it.uppercase() },
                    correct = answers.count { it.isCorrect },
                    total = answers.size
                )
            }
            .sortedBy {
                when (it.label.uppercase()) {
                    "EASY" -> 0
                    "MEDIUM" -> 1
                    "HARD" -> 2
                    else -> 3
                }
            }
    }

    val questionTypeMetrics = remember(evaluatedAnswers) {
        evaluatedAnswers
            .groupBy { it.questionType }
            .map { (type, answers) ->
                PerformanceMetric(
                    label = when (type) {
                        PracticeQuestionType.MCQ -> "Multiple choice"
                        PracticeQuestionType.SHORT_ANSWER -> "Short answer"
                        PracticeQuestionType.PROBLEM_SOLVING -> "Problem solving"
                    },
                    correct = answers.count { it.isCorrect },
                    total = answers.size
                )
            }
            .sortedBy {
                when (it.label) {
                    "Multiple choice" -> 0
                    "Short answer" -> 1
                    else -> 2
                }
            }
    }

    /*
     * Analyze the complete history.
     *
     * The analyzer keeps different subject-topic combinations separate.
     */
    val performanceAnalysis = remember(results) {
        PracticePerformanceAnalyzer.analyze(results)
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = {
                showClearDialog = false
            },
            title = {
                Text("Clear practice history?")
            },
            text = {
                Text(
                    "This will permanently delete all saved quiz attempts from this account."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearHistory()
                        showClearDialog = false
                    }
                ) {
                    Text(
                        text = "Clear history",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showClearDialog = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 20.dp,
                    vertical = 18.dp
                )
        ) {

            // HEADER

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Spacer(Modifier.width(14.dp))

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "Practice History",
                        color = textColor,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Review your previous attempts",
                        color = muted,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(Modifier.height(22.dp))

            if (results.isEmpty()) {

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No quiz history yet",
                            color = textColor,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(Modifier.height(8.dp))

                        Text(
                            text = "Complete a practice quiz to see your results here.",
                            color = muted,
                            fontSize = 14.sp
                        )

                        Spacer(Modifier.height(22.dp))

                    }
                }

            } else {

                // SUMMARY

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SummaryCard(
                        title = "Attempts",
                        value = results.size.toString(),
                        modifier = Modifier.weight(1f)
                    )

                    SummaryCard(
                        title = "Average",
                        value = "$averageScore%",
                        modifier = Modifier.weight(1f)
                    )

                    SummaryCard(
                        title = "Correct",
                        value = totalCorrect.toString(),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(12.dp))

                Text(
                    text = "$totalEvaluated answers evaluated across all attempts",
                    color = muted,
                    fontSize = 12.sp
                )

                Spacer(Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Performance analysis",
                        color = textColor,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedButton(
                        onClick = {
                            showClearDialog = true
                        }
                    ) {
                        Text("Clear")
                    }
                }

                Spacer(Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    // OVERALL PERFORMANCE

                    item {
                        OverallPerformanceCard(
                            totalEvaluated = totalEvaluated,
                            totalCorrect = totalCorrect,
                            overallAccuracy = overallAccuracy
                        )
                    }

                    // ADAPTIVE LEARNING SUMMARY

                    item {
                        AdaptiveLearningSummary(
                            analysis = performanceAnalysis
                        )
                    }

                    // WEAK AREAS AND RECOMMENDATIONS

                    if (
                        performanceAnalysis.weakTopics.isNotEmpty() ||
                        performanceAnalysis.topicsNeedingImprovement.isNotEmpty() ||
                        performanceAnalysis.goodTopics.isNotEmpty() ||
                        performanceAnalysis.insufficientDataTopics.isNotEmpty()
                    ) {

                        item {
                            Spacer(Modifier.height(6.dp))

                            SectionHeading(
                                title = "Weak areas & recommendations",
                                description = "Topic-level insights based on evaluated answers."
                            )
                        }

                        if (performanceAnalysis.weakTopics.isNotEmpty()) {

                            item {
                                InsightGroupHeading(
                                    title = "Weak topics",
                                    description = "These topics need focused revision."
                                )
                            }

                            items(
                                items = performanceAnalysis.weakTopics,
                                key = { "weak_${it.id}" }
                            ) { insight ->

                                TopicInsightCard(
                                    insight = insight,
                                    statusLabel = "Weak"
                                )
                            }
                        }

                        if (performanceAnalysis.topicsNeedingImprovement.isNotEmpty()) {

                            item {
                                InsightGroupHeading(
                                    title = "Needs improvement",
                                    description = "Strengthen these topics through focused practice."
                                )
                            }

                            items(
                                items = performanceAnalysis.topicsNeedingImprovement,
                                key = { "improve_${it.id}" }
                            ) { insight ->

                                TopicInsightCard(
                                    insight = insight,
                                    statusLabel = "Needs improvement"
                                )
                            }
                        }

                        if (performanceAnalysis.goodTopics.isNotEmpty()) {

                            item {
                                InsightGroupHeading(
                                    title = "Good performance",
                                    description = "Maintain your understanding with regular practice."
                                )
                            }

                            items(
                                items = performanceAnalysis.goodTopics,
                                key = { "good_${it.id}" }
                            ) { insight ->

                                TopicInsightCard(
                                    insight = insight,
                                    statusLabel = "Good"
                                )
                            }
                        }

                        if (performanceAnalysis.insufficientDataTopics.isNotEmpty()) {

                            item {
                                InsightGroupHeading(
                                    title = "Insufficient data",
                                    description = "More evaluated answers are needed before classifying these topics."
                                )
                            }

                            items(
                                items = performanceAnalysis.insufficientDataTopics,
                                key = { "insufficient_${it.id}" }
                            ) { insight ->

                                TopicInsightCard(
                                    insight = insight,
                                    statusLabel = "More practice needed"
                                )
                            }
                        }
                    }

                    // LEARNING PROGRESS

                    if (
                        performanceAnalysis.improvingTopics.isNotEmpty() ||
                        performanceAnalysis.decliningTopics.isNotEmpty()
                    ) {

                        item {
                            SectionHeading(
                                title = "Learning progress",
                                description = "Comparison of recent and earlier quiz performance."
                            )
                        }

                        if (performanceAnalysis.improvingTopics.isNotEmpty()) {

                            item {
                                InsightGroupHeading(
                                    title = "Improving topics",
                                    description = "Your recent performance has improved."
                                )
                            }

                            items(
                                items = performanceAnalysis.improvingTopics,
                                key = { "trend_improving_${it.id}" }
                            ) { insight ->

                                TopicInsightCard(
                                    insight = insight,
                                    statusLabel = "Improving"
                                )
                            }
                        }

                        if (performanceAnalysis.decliningTopics.isNotEmpty()) {

                            item {
                                InsightGroupHeading(
                                    title = "Declining topics",
                                    description = "Recent performance is lower than earlier performance."
                                )
                            }

                            items(
                                items = performanceAnalysis.decliningTopics,
                                key = { "trend_declining_${it.id}" }
                            ) { insight ->

                                TopicInsightCard(
                                    insight = insight,
                                    statusLabel = "Declining"
                                )
                            }
                        }
                    }

                    // PERSONALIZED NEXT PRACTICE

                    if (performanceAnalysis.recommendedTopics.isNotEmpty()) {

                        item {
                            SectionHeading(
                                title = "Recommended next practice",
                                description = "Suggested priorities for your next learning session."
                            )
                        }

                        items(
                            items = performanceAnalysis.recommendedTopics,
                            key = { "recommended_${it.id}" }
                        ) { insight ->

                            RecommendedPracticeCard(
                                insight = insight
                            )
                        }
                    }

                    // TOPIC PERFORMANCE

                    if (topicMetrics.isNotEmpty()) {

                        item {
                            SectionHeading(
                                title = "Topic performance",
                                description = "Topics are ordered from lowest to highest accuracy. Subjects are kept separate."
                            )
                        }

                        items(
                            items = topicMetrics,
                            key = { "topic_${it.label}" }
                        ) { metric ->

                            PerformanceMetricCard(
                                metric = metric
                            )
                        }
                    }

                    // DIFFICULTY PERFORMANCE

                    if (difficultyMetrics.isNotEmpty()) {

                        item {
                            SectionHeading(
                                title = "Difficulty analysis",
                                description = "Compare your performance across difficulty levels."
                            )
                        }

                        items(
                            items = difficultyMetrics,
                            key = { "difficulty_${it.label}" }
                        ) { metric ->

                            PerformanceMetricCard(
                                metric = metric
                            )
                        }
                    }

                    // QUESTION TYPE PERFORMANCE

                    if (questionTypeMetrics.isNotEmpty()) {

                        item {
                            SectionHeading(
                                title = "Question-type performance",
                                description = "Find out which question formats challenge you most."
                            )
                        }

                        items(
                            items = questionTypeMetrics,
                            key = { "type_${it.label}" }
                        ) { metric ->

                            PerformanceMetricCard(
                                metric = metric
                            )
                        }
                    }

                    // PREVIOUS ATTEMPTS

                    item {
                        Spacer(Modifier.height(8.dp))

                        Text(
                            text = "Previous attempts",
                            color = textColor,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    items(
                        items = results,
                        key = { "result_${it.id}" }
                    ) { result ->

                        PracticeResultCard(
                            result = result,
                            formattedDate = dateFormatter.format(
                                Date(result.completedAt)
                            )
                        )
                    }

                    item {
                        Spacer(Modifier.height(12.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun OverallPerformanceCard(
    totalEvaluated: Int,
    totalCorrect: Int,
    overallAccuracy: Int
) {
    val surface = MaterialTheme.colorScheme.surface
    val textColor = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {

        if (totalEvaluated > 0) {

            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {

                Text(
                    text = "Overall accuracy",
                    color = textColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = "$overallAccuracy%",
                    color = textColor,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold
                )

                LinearProgressIndicator(
                    progress = {
                        overallAccuracy / 100f
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                Text(
                    text = "$totalCorrect correct out of $totalEvaluated evaluated answers",
                    color = muted,
                    fontSize = 12.sp
                )
            }

        } else {

            Text(
                text = "Performance analysis will appear after your first evaluated quiz.",
                modifier = Modifier.padding(16.dp),
                color = muted,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun AdaptiveLearningSummary(
    analysis: PracticePerformanceAnalysis
) {
    val textColor = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            Text(
                text = "Adaptive learning overview",
                color = textColor,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (!analysis.hasEnoughData) {

                Text(
                    text = "SCAI is still collecting enough evaluated answers to make reliable adaptive recommendations.",
                    color = muted,
                    fontSize = 12.sp
                )

            } else {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {

                    AdaptiveStat(
                        label = "Topics",
                        value = analysis.totalTopics.toString()
                    )

                    AdaptiveStat(
                        label = "Weak",
                        value = analysis.weakTopics.size.toString()
                    )

                    AdaptiveStat(
                        label = "Improving",
                        value = analysis.improvingTopics.size.toString()
                    )

                    AdaptiveStat(
                        label = "Declining",
                        value = analysis.decliningTopics.size.toString()
                    )
                }

                Text(
                    text = "Overall accuracy: ${analysis.overallAccuracy}%",
                    color = textColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                Text(
                    text = "Suggested overall difficulty: ${
                        analysis.overallRecommendedDifficulty.name.lowercase()
                            .replaceFirstChar { it.uppercase() }
                    }",
                    color = muted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun AdaptiveStat(
    label: String,
    value: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {

        Text(
            text = value,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 10.sp
        )
    }
}

@Composable
private fun SectionHeading(
    title: String,
    description: String
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {

        Text(
            text = title,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold
        )

        Text(
            text = description,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun InsightGroupHeading(
    title: String,
    description: String
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {

        Text(
            text = title,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )

        Text(
            text = description,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun TopicInsightCard(
    insight: TopicPerformanceInsight,
    statusLabel: String
) {
    val textColor = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(14.dp)
    ) {

        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {

                    Text(
                        text = insight.topic,
                        color = textColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    if (insight.subject.isNotBlank()) {

                        Text(
                            text = insight.subject,
                            color = muted,
                            fontSize = 10.sp
                        )
                    }
                }

                Text(
                    text = statusLabel,
                    color = muted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (
                insight.level == TopicPerformanceLevel.INSUFFICIENT_DATA
            ) {

                Text(
                    text = "${insight.evaluatedAnswers} evaluated answer(s). At least 3 are needed for a reliable classification.",
                    color = muted,
                    fontSize = 12.sp
                )

            } else {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {

                    Text(
                        text = "${insight.accuracy}% accuracy",
                        color = textColor,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = "${insight.correctAnswers}/${insight.evaluatedAnswers} correct",
                        color = muted,
                        fontSize = 11.sp
                    )
                }

                LinearProgressIndicator(
                    progress = {
                        insight.accuracy / 100f
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            if (
                insight.recentAccuracy != null &&
                insight.previousAccuracy != null
            ) {

                Text(
                    text = "Recent: ${insight.recentAccuracy}%  •  Previous: ${insight.previousAccuracy}%",
                    color = muted,
                    fontSize = 11.sp
                )
            }

            Text(
                text = "Trend: ${
                    insight.trend.name.lowercase()
                        .replace('_', ' ')
                        .replaceFirstChar { it.uppercase() }
                }",
                color = muted,
                fontSize = 11.sp
            )

            Text(
                text = insight.recommendation,
                color = muted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun RecommendedPracticeCard(
    insight: TopicPerformanceInsight
) {
    val textColor = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(14.dp)
    ) {

        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Column(
                    modifier = Modifier.weight(1f)
                ) {

                    Text(
                        text = insight.topic,
                        color = textColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    if (insight.subject.isNotBlank()) {

                        Text(
                            text = insight.subject,
                            color = muted,
                            fontSize = 10.sp
                        )
                    }
                }

                Text(
                    text = "Priority ${insight.priorityScore}",
                    color = textColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                RecommendationValue(
                    label = "Difficulty",
                    value = insight.recommendedDifficulty.name
                        .lowercase()
                        .replaceFirstChar { it.uppercase() },
                    modifier = Modifier.weight(1f)
                )

                RecommendationValue(
                    label = "Questions",
                    value = insight.recommendedQuestionCount.toString(),
                    modifier = Modifier.weight(1f)
                )

                RecommendationValue(
                    label = "Accuracy",
                    value = if (
                        insight.level == TopicPerformanceLevel.INSUFFICIENT_DATA
                    ) {
                        "N/A"
                    } else {
                        "${insight.accuracy}%"
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = insight.recommendation,
                color = muted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun RecommendationValue(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {

        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 10.sp
        )

        Text(
            text = value,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun PerformanceMetricCard(
    metric: PerformanceMetric
) {
    val textColor = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(14.dp)
    ) {

        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Text(
                    text = metric.label,
                    color = textColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = "${metric.accuracy}%",
                    color = textColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            LinearProgressIndicator(
                progress = {
                    metric.accuracy / 100f
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Text(
                text = "${metric.correct} correct out of ${metric.total} evaluated",
                color = muted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(14.dp)
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    vertical = 15.dp,
                    horizontal = 6.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = value,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(5.dp))

            Text(
                text = title,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun PracticeResultCard(
    result: StoredPracticeResult,
    formattedDate: String
) {
    val textColor = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val surface = MaterialTheme.colorScheme.surface

    val questionTypes = result.answers
        .map { it.questionType }
        .toSet()

    val formatLabel = when {
        questionTypes.isEmpty() ||
            questionTypes == setOf(PracticeQuestionType.MCQ) ->
            "MCQs"

        questionTypes == setOf(PracticeQuestionType.SHORT_ANSWER) ->
            "Short answers"

        questionTypes == setOf(PracticeQuestionType.PROBLEM_SOLVING) ->
            "Problem solving"

        questionTypes.contains(PracticeQuestionType.PROBLEM_SOLVING) ->
            "Mixed assessment"

        questionTypes.contains(PracticeQuestionType.SHORT_ANSWER) ->
            "MCQs + Short answers"

        else -> "Practice quiz"
    }

    val score = result.scorePercent
    val evaluated = result.evaluatedAnswers
    val pending = result.pendingEvaluationAnswers

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {

                Column(
                    modifier = Modifier.weight(1f)
                ) {

                    Text(
                        text = result.quizTitle,
                        color = textColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = result.subject,
                        color = muted,
                        fontSize = 12.sp
                    )
                }

                Spacer(Modifier.width(8.dp))

                Text(
                    text = if (evaluated > 0) "$score%" else "Pending",
                    color = textColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(20.dp)
            ) {

                Text(
                    text = formatLabel,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(
                        horizontal = 11.dp,
                        vertical = 6.dp
                    )
                )
            }

            LinearProgressIndicator(
                progress = {
                    if (evaluated == 0) {
                        0f
                    } else {
                        score / 100f
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = "${result.correctAnswers} correct",
                    color = muted,
                    fontSize = 12.sp
                )

                Text(
                    text = "${result.incorrectAnswers} incorrect",
                    color = muted,
                    fontSize = 12.sp
                )

                Text(
                    text = "${result.totalQuestions} total",
                    color = muted,
                    fontSize = 12.sp
                )
            }

            if (pending > 0) {

                Text(
                    text = "$pending answer(s) pending evaluation",
                    color = muted,
                    fontSize = 12.sp
                )
            }

            Text(
                text = formattedDate,
                color = muted,
                fontSize = 11.sp
            )
        }
    }
}
