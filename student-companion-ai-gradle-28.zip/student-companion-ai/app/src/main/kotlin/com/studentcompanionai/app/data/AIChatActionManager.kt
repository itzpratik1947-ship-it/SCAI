package com.studentcompanionai.app.data

import com.google.firebase.auth.FirebaseAuth
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class TaskActionStatus {
    NOT_A_TASK_COMMAND,
    CREATED,
    ALREADY_EXISTS,
    NEEDS_TASK_DETAILS,
    ACCOUNT_CHANGED,
    FAILED
}

data class TaskActionResult(
    val status: TaskActionStatus,
    val task: StudyTask? = null,
    val message: String
)

class AIChatActionManager(
    private val storage: StudentStorage,
    private val accountUid: String,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {

    fun handleTaskCommand(message: String): TaskActionResult {

        if (!isCorrectAccount()) {
            return accountChanged("Your account changed. Please try again.")
        }

        if (!isCreateTaskCommand(message)) {
            return TaskActionResult(
                TaskActionStatus.NOT_A_TASK_COMMAND,
                message = "This is not a task creation command."
            )
        }

        return try {
            val subjects = storage.loadSubjects()
            val parsed = parseTaskDetails(message, subjects)

            if (parsed.title.isBlank()) {
                return TaskActionResult(
                    TaskActionStatus.NEEDS_TASK_DETAILS,
                    message = "What task would you like me to create? Include a subject, date or time if needed."
                )
            }

            if (!isCorrectAccount()) {
                return accountChanged("Your account changed. Please try again.")
            }

            val existingTasks = storage.loadTasks()

            val duplicate = existingTasks.firstOrNull {
                !it.isCompleted &&
                    !it.isSkipped &&
                    normalize(it.title) == normalize(parsed.title)
            }

            if (duplicate != null) {
                return TaskActionResult(
                    TaskActionStatus.ALREADY_EXISTS,
                    task = duplicate,
                    message = "This task already exists in your Tasks list."
                )
            }

            val highestUsedId = maxOf(
                existingTasks.maxOfOrNull { it.id } ?: 0,
                storage.loadDeletedTaskIds().maxOrNull() ?: 0
            )

            if (highestUsedId == Int.MAX_VALUE) {
                return TaskActionResult(
                    TaskActionStatus.FAILED,
                    message = "A new task ID could not be generated."
                )
            }

            val newTask = StudyTask(
                id = highestUsedId + 1,
                title = parsed.title,
                subjectId = parsed.subject?.id,
                isCompleted = false,
                description = parsed.description,
                scheduledDate = parsed.scheduledDate,
                scheduledDateTime = parsed.scheduledDateTime,
                estimatedMinutes = parsed.estimatedMinutes
            )

            if (!isCorrectAccount()) {
                return accountChanged("Your account changed. The task was not saved.")
            }

            storage.saveTasks(existingTasks + newTask)

            if (!isCorrectAccount()) {
                return accountChanged("Your account changed. Please verify your task list.")
            }

            val savedTask = storage.loadTasks().firstOrNull {
                it.id == newTask.id
            } ?: return TaskActionResult(
                TaskActionStatus.FAILED,
                message = "The task could not be verified after saving."
            )

            TaskActionResult(
                TaskActionStatus.CREATED,
                task = savedTask,
                message = buildCreationMessage(
                    savedTask,
                    parsed.subject?.name
                )
            )

        } catch (exception: Exception) {
            TaskActionResult(
                TaskActionStatus.FAILED,
                message = "Unable to create the task: ${
                    exception.localizedMessage ?: "Unknown error"
                }"
            )
        }
    }

    private data class ParsedTask(
        val title: String,
        val description: String,
        val subject: Subject?,
        val scheduledDate: Long,
        val scheduledDateTime: Long,
        val estimatedMinutes: Int
    )

    private data class SubjectMatch(
        val subject: Subject,
        val matchedPhrase: String,
        val score: Int
    )

    private data class DateMatch(
        val timestamp: Long,
        val matchedText: String
    )

    private data class TimeMatch(
        val hour: Int,
        val minute: Int,
        val matchedText: String
    )

    // ==================================================
    // COMMAND DETECTION
    // ==================================================

    private fun isCreateTaskCommand(message: String): Boolean {
        val normalized = message.lowercase(Locale.ROOT)

        val actionFound = Regex(
            "\\b(create|add|make|save|assign|schedule|set)\\b"
        ).containsMatchIn(normalized)

        val taskFound = Regex(
            "\\b(task|tasks|to-do|todo)\\b"
        ).containsMatchIn(normalized)

        return actionFound && taskFound
    }

    // ==================================================
    // MAIN PARSER
    // ==================================================

    private fun parseTaskDetails(
        message: String,
        subjects: List<Subject>
    ): ParsedTask {

        var working = message.trim()
        var description = ""

        val descriptionMatch = Regex(
            "(?i)\\b(?:description|details)\\s*[:\\-]\\s*(.+)$"
        ).find(working)

        if (descriptionMatch != null) {
            description = cleanText(
                descriptionMatch.groupValues[1]
            ).take(500)

            working = working.removeRange(descriptionMatch.range)
        }

        // Match the subject against the original command.
        val subjectMatch = findSubjectMatch(working, subjects)

        // Remove the actual matched subject phrase from the title.
        if (subjectMatch != null) {
            working = removeSubjectWording(
                working,
                subjectMatch.matchedPhrase
            )
        }

        val durationMatch = Regex(
            "(?i)\\b(?:for\\s+)?(\\d+(?:\\.\\d+)?)\\s*(minutes?|mins?|hours?|hrs?)\\b"
        ).find(working)

        val estimatedMinutes = durationMatch?.let {
            val amount = it.groupValues[1].toDoubleOrNull() ?: 0.0
            val unit = it.groupValues[2].lowercase(Locale.ROOT)
            val minutes = if (unit.startsWith("h")) amount * 60 else amount

            minutes.toInt().coerceIn(0, MAX_ESTIMATED_MINUTES)
        } ?: 0

        if (durationMatch != null) {
            working = working.removeRange(durationMatch.range)
        }

        val dateMatch = findDate(working)
        var scheduledDate = dateMatch?.timestamp ?: 0L

        if (dateMatch != null) {
            working = removeMatchedText(
                working,
                dateMatch.matchedText
            )
        }

        val timeMatch = findTime(working)
        var scheduledDateTime = 0L

        if (timeMatch != null) {
            working = removeMatchedText(
                working,
                timeMatch.matchedText
            )

            val calendar = Calendar.getInstance()

            if (scheduledDate > 0L) {
                calendar.timeInMillis = scheduledDate
            }

            calendar.set(Calendar.HOUR_OF_DAY, timeMatch.hour)
            calendar.set(Calendar.MINUTE, timeMatch.minute)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)

            scheduledDate = startOfDay(calendar)
            scheduledDateTime = calendar.timeInMillis
        }

        working = working
            .replace(
                Regex("(?i)\\b(?:on|by|at|for|to|in|into|subject|please)\\b"),
                " "
            )
            .replace(
                Regex("(?i)\\b(?:today|tomorrow|day after tomorrow)\\b"),
                " "
            )

        working = removeCommandWording(working)

        val title = cleanText(working)
            .trim('.', ',', ';', ':', '-', ' ')
            .take(MAX_TITLE_LENGTH)
            .trim()
            .replaceFirstChar {
                if (it.isLowerCase()) it.titlecase(Locale.ROOT)
                else it.toString()
            }

        return ParsedTask(
            title = title,
            description = description,
            subject = subjectMatch?.subject,
            scheduledDate = scheduledDate,
            scheduledDateTime = scheduledDateTime,
            estimatedMinutes = estimatedMinutes
        )
    }

    // ==================================================
    // SUBJECT MATCHING
    // ==================================================

    private fun findSubjectMatch(
        message: String,
        subjects: List<Subject>
    ): SubjectMatch? {

        val normalizedMessage = normalize(message)
        val matches = mutableListOf<SubjectMatch>()

        for (subject in subjects) {
            val candidates = mutableListOf<Pair<String, Int>>()

            // Exact full saved subject name.
            candidates.add(subject.name to 100)

            // Exact abbreviation stored in parentheses, e.g. (FPL).
            val abbreviation = Regex(
                "\\(([^)]+)\\)"
            ).find(subject.name)?.groupValues?.get(1)

            if (!abbreviation.isNullOrBlank()) {
                candidates.add(abbreviation to 125)
            }

            // Generate an initialism from the saved subject name as well.
            // Example: "Fundamentals of Programming Language" -> "FPL".
            val generatedAbbreviation = generateSubjectAbbreviation(subject.name)
            if (generatedAbbreviation.isNotBlank()) {
                candidates.add(generatedAbbreviation to 120)
            }

            // Subject-specific aliases, not generic programming languages.
            subjectAliases(subject.name).forEach {
                candidates.add(it to 70)
            }

            for ((phrase, score) in candidates) {
                val normalizedPhrase = normalize(phrase)

                if (normalizedPhrase.isBlank()) continue

                if (containsPhrase(normalizedMessage, normalizedPhrase)) {
                    matches.add(
                        SubjectMatch(
                            subject = subject,
                            matchedPhrase = phrase,
                            score = score
                        )
                    )
                }
            }
        }

        if (matches.isEmpty()) return null

        // Prefer the strongest match. If two different subjects tie,
        // do not guess.
        val highestScore = matches.maxOf { it.score }
        val winners = matches.filter { it.score == highestScore }
            .distinctBy { it.subject.id }

        return winners.singleOrNull()
    }

    private fun generateSubjectAbbreviation(subjectName: String): String {
        // Ignore common connector words when building an initialism.
        // Fundamentals of Programming Language -> FPL, not FOPL.
        val ignoredWords = setOf("of", "the", "and", "in", "for", "to", "a", "an")

        val words = normalize(
            subjectName.substringBefore("(")
        ).split(" ")
            .filter { it.isNotBlank() && it !in ignoredWords }

        if (words.size < 2) return ""

        val abbreviation = words.joinToString("") { word ->
            word.first().uppercaseChar().toString()
        }

        return abbreviation.takeIf {
            it.length in 2..6 && it.all(Char::isLetter)
        }.orEmpty()
    }

    private fun subjectAliases(subjectName: String): List<String> {
        val name = normalize(subjectName)

        return when {
            name.contains("physics") -> listOf(
                "physics"
            )

            name.contains("chemistry") -> listOf(
                "chemistry",
                "organic chemistry",
                "inorganic chemistry"
            )

            name.contains("biology") -> listOf(
                "biology",
                "botany",
                "zoology"
            )

            name.contains("mathematics") ||
                name == "math" ||
                name == "maths" -> listOf(
                "math",
                "maths",
                "mathematics"
            )

            name.contains("programming") ||
                name.contains("computer") ||
                name.contains("software") -> listOf(
                "programming",
                "computer science",
                "software"
            )

            name.contains("english") -> listOf(
                "english"
            )

            name.contains("history") -> listOf(
                "history"
            )

            name.contains("geography") -> listOf(
                "geography"
            )

            else -> emptyList()
        }
    }

    private fun removeSubjectWording(
        message: String,
        matchedPhrase: String
    ): String {

        val escaped = Regex.escape(matchedPhrase.trim())

        var result = message

        // Remove clauses such as:
        // "to FPL subject"
        // "for physics"
        // "in Engineering Physics"
        val clausePattern = Regex(
            "(?i)\\b(?:for|to|in|under)\\s+$escaped" +
                "(?:\\s+(?:subject|class))?\\b"
        )

        result = result.replace(clausePattern, " ")

        // Also remove standalone "FPL subject" or "physics subject".
        val standalonePattern = Regex(
            "(?i)\\b$escaped\\s+(?:subject|class)\\b"
        )

        result = result.replace(standalonePattern, " ")

        // Remove a standalone abbreviation if it remains.
        if (matchedPhrase.length <= 8 &&
            matchedPhrase.all { it.isLetterOrDigit() }
        ) {
            val abbreviationPattern = Regex(
                "(?i)\\b${Regex.escape(matchedPhrase)}\\b"
            )

            result = result.replace(abbreviationPattern, " ")
        }

        return result
    }

    private fun containsPhrase(
        text: String,
        phrase: String
    ): Boolean {
        if (text.isBlank() || phrase.isBlank()) return false

        return Regex(
            "(?:^| )${Regex.escape(phrase)}(?:$| )"
        ).containsMatchIn(text)
    }

    // ==================================================
    // COMMAND WORDING CLEANUP
    // ==================================================

    private fun removeCommandWording(message: String): String {
        var text = message.trim()

        val prefixes = listOf(
            Regex("(?i)^(?:please\\s+)?i want to\\s+"),
            Regex("(?i)^(?:please\\s+)?i need to\\s+"),
            Regex("(?i)^(?:please\\s+)?i have to\\s+"),
            Regex("(?i)^(?:please\\s+)?i'd like to\\s+"),
            Regex("(?i)^(?:please\\s+)?can you\\s+"),
            Regex("(?i)^(?:please\\s+)?could you\\s+"),
            Regex("(?i)^(?:please\\s+)?would you\\s+"),
            Regex("(?i)^(?:please\\s+)?will you\\s+"),
            Regex("(?i)^please\\s+")
        )

        prefixes.forEach {
            text = text.replaceFirst(it, "")
        }

        text = text.replaceFirst(
            Regex(
                "(?i)^(?:create|add|make|save|assign|schedule|set)\\s+" +
                    "(?:(?:me|it)\\s+)?" +
                    "(?:(?:a|an|the)\\s+)?" +
                    "(?:new\\s+)?" +
                    "(?:task|to[- ]?do|todo)\\b"
            ),
            ""
        )

        text = text.replaceFirst(
            Regex("(?i)^\\s*(?:for|about|named|called|to|of)\\s+"),
            ""
        )

        text = text.replace(
            Regex(
                "(?i)\\s+(?:to|in|into)\\s+my\\s+" +
                    "(?:task|tasks|to-do|todo)\\s*(?:list)?$"
            ),
            ""
        )

        return text.trim()
    }

    private fun removeMatchedText(
        source: String,
        matchedText: String
    ): String {
        val index = source.indexOf(matchedText, ignoreCase = true)

        return if (index >= 0) {
            source.removeRange(index, index + matchedText.length)
        } else {
            source
        }
    }

    // ==================================================
    // DATE PARSING
    // ==================================================

    private fun findDate(text: String): DateMatch? {
        val today = startOfDay(Calendar.getInstance())

        val relativePhrases = listOf(
            "day after tomorrow" to 2,
            "tomorrow" to 1,
            "today" to 0
        )

        for ((phrase, days) in relativePhrases) {
            if (Regex(
                    "\\b${Regex.escape(phrase)}\\b",
                    RegexOption.IGNORE_CASE
                ).containsMatchIn(text)
            ) {
                val calendar = Calendar.getInstance().apply {
                    timeInMillis = today
                    add(Calendar.DAY_OF_YEAR, days)
                }

                return DateMatch(calendar.timeInMillis, phrase)
            }
        }

        val inDays = Regex(
            "(?i)\\bin\\s+(\\d{1,3})\\s+days?\\b"
        ).find(text)

        if (inDays != null) {
            val days = inDays.groupValues[1]
                .toIntOrNull()?.coerceAtMost(365) ?: 0

            val calendar = Calendar.getInstance().apply {
                timeInMillis = today
                add(Calendar.DAY_OF_YEAR, days)
            }

            return DateMatch(calendar.timeInMillis, inDays.value)
        }

        val numericDate = Regex(
            "\\b(\\d{1,2})[/-](\\d{1,2})(?:[/-](\\d{4}))?\\b"
        ).find(text)

        if (numericDate != null) {
            val day = numericDate.groupValues[1].toIntOrNull() ?: return null
            val month = numericDate.groupValues[2].toIntOrNull() ?: return null
            val year = numericDate.groupValues[3].toIntOrNull()

            val calendar = buildDate(day, month, year) ?: return null
            return DateMatch(calendar.timeInMillis, numericDate.value)
        }

        val textualDate = Regex(
            "(?i)\\b(\\d{1,2})\\s+" +
                "(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|" +
                "apr(?:il)?|may|jun(?:e)?|jul(?:y)?|" +
                "aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|" +
                "nov(?:ember)?|dec(?:ember)?)" +
                "(?:\\s+(\\d{4}))?\\b"
        ).find(text)

        if (textualDate != null) {
            val day = textualDate.groupValues[1].toIntOrNull() ?: return null
            val month = monthNumber(textualDate.groupValues[2]) ?: return null
            val year = textualDate.groupValues[3].toIntOrNull()

            val calendar = buildDate(day, month, year) ?: return null
            return DateMatch(calendar.timeInMillis, textualDate.value)
        }

        val weekdayMatch = Regex(
            "(?i)\\b(next\\s+)?(monday|tuesday|wednesday|" +
                "thursday|friday|saturday|sunday)\\b"
        ).find(text)

        if (weekdayMatch != null) {
            val targetDay = when (
                weekdayMatch.groupValues[2].lowercase(Locale.ROOT)
            ) {
                "sunday" -> Calendar.SUNDAY
                "monday" -> Calendar.MONDAY
                "tuesday" -> Calendar.TUESDAY
                "wednesday" -> Calendar.WEDNESDAY
                "thursday" -> Calendar.THURSDAY
                "friday" -> Calendar.FRIDAY
                else -> Calendar.SATURDAY
            }

            val calendar = Calendar.getInstance().apply {
                timeInMillis = today

                val currentDay = get(Calendar.DAY_OF_WEEK)
                var daysAhead = (targetDay - currentDay + 7) % 7

                if (daysAhead == 0 ||
                    weekdayMatch.groupValues[1].isNotBlank()
                ) {
                    daysAhead += 7
                }

                add(Calendar.DAY_OF_YEAR, daysAhead)
            }

            return DateMatch(calendar.timeInMillis, weekdayMatch.value)
        }

        return null
    }

    // ==================================================
    // TIME PARSING
    // ==================================================

    private fun findTime(text: String): TimeMatch? {
        val twelveHour = Regex(
            "(?i)\\b(1[0-2]|0?[1-9])" +
                "(?::([0-5]\\d))?\\s*(a\\.?m\\.?|p\\.?m\\.?)\\b"
        ).find(text)

        if (twelveHour != null) {
            var hour = twelveHour.groupValues[1].toInt()
            val minute = twelveHour.groupValues[2].toIntOrNull() ?: 0

            val meridiem = twelveHour.groupValues[3]
                .lowercase(Locale.ROOT).replace(".", "")

            if (meridiem == "pm" && hour != 12) hour += 12
            if (meridiem == "am" && hour == 12) hour = 0

            return TimeMatch(hour, minute, twelveHour.value)
        }

        val twentyFourHour = Regex(
            "(?i)\\b(?:at\\s+)?([01]?\\d|2[0-3]):([0-5]\\d)\\b"
        ).find(text)

        if (twentyFourHour != null) {
            return TimeMatch(
                twentyFourHour.groupValues[1].toInt(),
                twentyFourHour.groupValues[2].toInt(),
                twentyFourHour.value
            )
        }

        val hourOnly = Regex(
            "(?i)\\bat\\s+(1[0-2]|0?[1-9])\\b"
        ).find(text)

        if (hourOnly != null) {
            return TimeMatch(
                hourOnly.groupValues[1].toInt(),
                0,
                hourOnly.value
            )
        }

        return null
    }

    // ==================================================
    // DATE HELPERS
    // ==================================================

    private fun monthNumber(monthName: String): Int? {
        return when (monthName.lowercase(Locale.ROOT).take(3)) {
            "jan" -> 1
            "feb" -> 2
            "mar" -> 3
            "apr" -> 4
            "may" -> 5
            "jun" -> 6
            "jul" -> 7
            "aug" -> 8
            "sep" -> 9
            "oct" -> 10
            "nov" -> 11
            "dec" -> 12
            else -> null
        }
    }

    private fun buildDate(
        day: Int,
        month: Int,
        requestedYear: Int?
    ): Calendar? {
        if (month !in 1..12 || day !in 1..31) return null

        val currentYear = Calendar.getInstance().get(Calendar.YEAR)

        val calendar = Calendar.getInstance().apply {
            isLenient = false
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.MONTH, month - 1)
            set(Calendar.YEAR, requestedYear ?: currentYear)
            set(Calendar.DAY_OF_MONTH, day)
        }

        return try {
            calendar.timeInMillis

            if (requestedYear == null &&
                calendar.timeInMillis < startOfDay(Calendar.getInstance())
            ) {
                calendar.add(Calendar.YEAR, 1)
            }

            calendar
        } catch (_: IllegalArgumentException) {
            null
        }
    }

    private fun startOfDay(source: Calendar): Long {
        return (source.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    // ==================================================
    // RESULT HELPERS
    // ==================================================

    private fun isCorrectAccount(): Boolean {
        return auth.currentUser?.uid == accountUid
    }

    private fun accountChanged(message: String) =
        TaskActionResult(
            TaskActionStatus.ACCOUNT_CHANGED,
            message = message
        )

    private fun buildCreationMessage(
        task: StudyTask,
        subjectName: String?
    ): String {
        val details = mutableListOf<String>()

        if (subjectName != null) {
            details += "Subject: $subjectName"
        }

        if (task.scheduledDate > 0L) {
            details += "Date: ${
                SimpleDateFormat(
                    "dd MMM yyyy",
                    Locale.getDefault()
                ).format(Date(task.scheduledDate))
            }"
        }

        if (task.scheduledDateTime > 0L) {
            details += "Time: ${
                SimpleDateFormat(
                    "hh:mm a",
                    Locale.getDefault()
                ).format(Date(task.scheduledDateTime))
            }"
        }

        if (task.estimatedMinutes > 0) {
            details += "Duration: ${formatDuration(task.estimatedMinutes)}"
        }

        return if (details.isEmpty()) {
            "Task created successfully."
        } else {
            "Task created successfully. ${details.joinToString(" • ")}"
        }
    }

    private fun formatDuration(minutes: Int): String {
        val hours = minutes / 60
        val remainingMinutes = minutes % 60

        return when {
            hours > 0 && remainingMinutes > 0 ->
                "${hours}h ${remainingMinutes}m"
            hours > 0 -> "${hours}h"
            else -> "${remainingMinutes}m"
        }
    }

    private fun normalize(value: String): String {
        return value.lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }

    private fun cleanText(value: String): String {
        return value.replace(Regex("\\s+"), " ").trim()
    }

    companion object {
        private const val MAX_TITLE_LENGTH = 120
        private const val MAX_ESTIMATED_MINUTES = 24 * 60
    }
}