
package com.studentcompanionai.app.data

import android.content.Context
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class StudentSyncManager(context: Context) {

    private val appContext = context.applicationContext

    private val auth = FirebaseAuth.getInstance()

    // Capture the authenticated account when this manager is created.
    // MainActivity recreates this manager when accountUid changes.
    private val accountUid = auth.currentUser?.uid

    // All synchronization now uses account-specific storage.
    private val storage = StudentStorage(
        appContext,
        accountUid
    )

    private val repository = StudentSyncRepository()

    // Gamification has its own legacy migration mechanism.
    private val gamificationManager = accountUid?.let { uid ->
        GamificationManager(appContext, uid)
    }

    private val syncMutex = Mutex()

    // =============================================
    // SYNCHRONIZATION
    // =============================================

    suspend fun sync(): String = syncMutex.withLock {

        val uid = auth.currentUser?.uid
            ?: return@withLock "Please sign in before syncing."

        if (accountUid != uid) {
            return@withLock (
                "Account changed. Please retry synchronization."
            )
        }

        try {

            // -------------------------------------
            // LEGACY DATA MIGRATION
            // -------------------------------------

            val migrationIssue = checkLegacyMigrationStatus(
                storage.migrateLegacyDataIfSafe(),
                gamificationManager?.migrateLegacyDataIfSafe()
                    ?: LegacyMigrationStatus.NO_LEGACY_DATA
            )

            if (migrationIssue != null) {
                return@withLock migrationIssue
            }

            // -------------------------------------
            // ACCOUNT OWNERSHIP VALIDATION
            // -------------------------------------

            val ownerUid = storage.getSyncOwnerUid()

            if (ownerUid != null && ownerUid != uid) {

                return@withLock (
                    "Sync paused: local data belongs to another account. " +
                        "Your local data has not been changed."
                )
            }

            // Account-specific preferences already belong to this UID.
            if (ownerUid == null) {
                storage.setSyncOwnerUid(uid)
            }

            ensureSameUser(uid)

            // -------------------------------------
            // PROCESS PENDING DELETIONS
            // -------------------------------------

            val deletedSubjectIds =
                storage.loadDeletedSubjectIds()

            val deletedTaskIds =
                storage.loadDeletedTaskIds()

            repository.deleteSubjects(
                deletedSubjectIds,
                uid
            )

            ensureSameUser(uid)

            // Clear only after the cloud deletion succeeds.
            storage.clearDeletedSubjectIds(
                deletedSubjectIds
            )

            repository.deleteTasks(
                deletedTaskIds,
                uid
            )

            ensureSameUser(uid)

            storage.clearDeletedTaskIds(
                deletedTaskIds
            )

            // -------------------------------------
            // DOWNLOAD CLOUD DATA
            // -------------------------------------

            val cloudSubjects =
                repository.downloadSubjects()

            ensureSameUser(uid)

            val cloudTasks =
                repository.downloadTasks()

            ensureSameUser(uid)

            val cloudSessions =
                repository.downloadFocusSessions()

            ensureSameUser(uid)

            // -------------------------------------
            // LOAD ACCOUNT-SCOPED LOCAL DATA
            // -------------------------------------

            val localSubjects =
                storage.loadSubjects()

            val localTasks =
                storage.loadTasks()

            val localSessions =
                storage.loadFocusSessions()

            // -------------------------------------
            // MERGE RECORDS
            // -------------------------------------

            // Existing conflict policy is preserved:
            // local records win when IDs match.

            val mergedSubjects = mergeById(
                cloudSubjects,
                localSubjects,
                { it.id }
            )

            val mergedTasks = mergeById(
                cloudTasks,
                localTasks,
                { it.id }
            )

            val mergedSessions = mergeById(
                cloudSessions,
                localSessions,
                { it.id }
            )

            ensureSameUser(uid)

            // -------------------------------------
            // SAVE MERGED DATA LOCALLY
            // -------------------------------------

            storage.replaceSubjectsFromSync(
                mergedSubjects
            )

            storage.replaceTasksFromSync(
                mergedTasks
            )

            storage.replaceFocusSessions(
                mergedSessions
            )

            ensureSameUser(uid)

            // -------------------------------------
            // UPLOAD MERGED DATA
            // -------------------------------------

            repository.uploadSubjects(
                mergedSubjects
            )

            ensureSameUser(uid)

            repository.uploadTasks(
                mergedTasks
            )

            ensureSameUser(uid)

            repository.uploadFocusSessions(
                mergedSessions
            )

            ensureSameUser(uid)

            // -------------------------------------
            // UPDATE FOCUS SUMMARY
            // -------------------------------------

            storage.saveFocusSessions(
                sessionCount = mergedSessions.size,
                totalMinutes = mergedSessions.sumOf {
                    it.minutes
                }
            )

            ensureSameUser(uid)

            // -------------------------------------
            // LOG SUCCESS
            // -------------------------------------

            Log.d(
                TAG,
                "Account-scoped sync successful: " +
                    "uid=$uid, " +
                    "subjects=${mergedSubjects.size}, " +
                    "tasks=${mergedTasks.size}, " +
                    "sessions=${mergedSessions.size}"
            )

            "Sync completed successfully.\n" +
                "Subjects: ${mergedSubjects.size}\n" +
                "Tasks: ${mergedTasks.size}\n" +
                "Focus sessions: ${mergedSessions.size}"

        } catch (e: CancellationException) {

            throw e

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Synchronization failed",
                e
            )

            "Sync failed: ${e.localizedMessage ?: "Unknown error"}. " +
                "Please try again."
        }
    }

    // =============================================
    // CONFIRM LOCAL DATA OWNERSHIP
    // =============================================

    suspend fun claimLocalDataForCurrentUser(): String =
        syncMutex.withLock {

            val uid = auth.currentUser?.uid
                ?: return@withLock "Please sign in first."

            if (accountUid != uid) {
                return@withLock (
                    "Account changed. Please retry ownership confirmation."
                )
            }

            return@withLock try {

                // First perform safe migration checks.
                // This prevents claiming data belonging to another UID
                // or overwriting an existing account destination.

                val studentPreflight =
                    storage.migrateLegacyDataIfSafe()

                val gamificationPreflight =
                    gamificationManager?.migrateLegacyDataIfSafe()
                        ?: LegacyMigrationStatus.NO_LEGACY_DATA

                val preflightIssue = getBlockingMigrationIssue(
                    studentPreflight,
                    gamificationPreflight
                )

                if (preflightIssue != null) {
                    return@withLock preflightIssue
                }

                ensureSameUser(uid)

                // ---------------------------------
                // MIGRATE STUDENT DATA
                // ---------------------------------

                val studentMigration =
                    storage.claimLegacyDataForCurrentUser(
                        confirmedOwnership = true
                    )

                // ---------------------------------
                // MIGRATE GAMIFICATION DATA
                // ---------------------------------

                val gamificationMigration =
                    gamificationManager
                        ?.claimLegacyDataForCurrentUser(
                            confirmedOwnership = true
                        )
                        ?: LegacyMigrationStatus.NO_LEGACY_DATA

                // ---------------------------------
                // VALIDATE MIGRATION RESULTS
                // ---------------------------------

                val migrationIssue = checkLegacyMigrationStatus(
                    studentMigration,
                    gamificationMigration
                )

                if (migrationIssue != null) {
                    return@withLock migrationIssue
                }

                ensureSameUser(uid)

                // Account-scoped destination now belongs to this UID.
                storage.setSyncOwnerUid(uid)

                Log.d(
                    TAG,
                    "Legacy data ownership confirmed for UID=$uid"
                )

                "Local data successfully associated with your account. " +
                    "You can now sync."

            } catch (e: CancellationException) {

                throw e

            } catch (e: Exception) {

                Log.e(
                    TAG,
                    "Local data ownership confirmation failed",
                    e
                )

                "Could not confirm local data ownership: " +
                    (e.localizedMessage ?: "Unknown error")
            }
        }

    // =============================================
    // LEGACY MIGRATION VALIDATION
    // =============================================

    private fun getBlockingMigrationIssue(
        studentStatus: LegacyMigrationStatus,
        gamificationStatus: LegacyMigrationStatus
    ): String? {

        val statuses = listOf(
            studentStatus,
            gamificationStatus
        )

        if (LegacyMigrationStatus.OWNER_MISMATCH in statuses) {
            return (
                "Sync paused: legacy data belongs to another account. " +
                    "No ownership transfer was performed."
            )
        }

        if (LegacyMigrationStatus.DESTINATION_NOT_EMPTY in statuses) {
            return (
                "Sync paused: account storage already contains data " +
                    "while legacy data remains. A safe data merge is required."
            )
        }

        if (LegacyMigrationStatus.FAILED in statuses) {
            return (
                "Sync paused: legacy data migration failed. " +
                    "Your original legacy data has been preserved."
            )
        }

        if (
            LegacyMigrationStatus.NOT_ACCOUNT_SCOPED in statuses
        ) {
            return "Please sign in before migrating local data."
        }

        // OWNERSHIP_CONFIRMATION_REQUIRED is allowed here.
        // The user has explicitly confirmed ownership in this flow.

        return null
    }

    private fun checkLegacyMigrationStatus(
        studentStatus: LegacyMigrationStatus,
        gamificationStatus: LegacyMigrationStatus
    ): String? {

        val blockingIssue = getBlockingMigrationIssue(
            studentStatus,
            gamificationStatus
        )

        if (blockingIssue != null) {
            return blockingIssue
        }

        if (
            LegacyMigrationStatus.OWNERSHIP_CONFIRMATION_REQUIRED
                in listOf(studentStatus, gamificationStatus)
        ) {

            return (
                "Sync requires confirmation: existing legacy data " +
                    "has no verified account owner. Please confirm " +
                    "ownership before synchronizing."
            )
        }

        return null
    }

    // =============================================
    // ACCOUNT VALIDATION
    // =============================================

    private fun ensureSameUser(expectedUid: String) {

        check(
            accountUid == expectedUid &&
                auth.currentUser?.uid == expectedUid
        ) {
            "The signed-in account changed during sync."
        }
    }

    // =============================================
    // MERGE HELPER
    // =============================================

    private fun <T, ID> mergeById(
        cloud: List<T>,
        local: List<T>,
        id: (T) -> ID
    ): List<T> {

        val merged = LinkedHashMap<ID, T>()

        cloud.forEach {
            merged[id(it)] = it
        }

        local.forEach {
            merged[id(it)] = it
        }

        return merged.values.sortedBy {
            id(it).toString()
        }
    }

    private companion object {
        const val TAG = "StudentSyncManager"
    }
}
