
package com.studentcompanionai.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// =====================================================
// MONOCHROME DARK PALETTE
// =====================================================

private val DarkAppColors = darkColorScheme(

    primary = Color(0xFFFFFFFF),
    onPrimary = Color(0xFF090909),

    primaryContainer = Color(0xFF292929),
    onPrimaryContainer = Color(0xFFFFFFFF),

    secondary = Color(0xFFBDBDBD),
    onSecondary = Color(0xFF111111),

    secondaryContainer = Color(0xFF242424),
    onSecondaryContainer = Color(0xFFEAEAEA),

    tertiary = Color(0xFFE0E0E0),
    onTertiary = Color(0xFF111111),

    tertiaryContainer = Color(0xFF303030),
    onTertiaryContainer = Color(0xFFF5F5F5),

    background = Color(0xFF090909),
    onBackground = Color(0xFFFFFFFF),

    surface = Color(0xFF141414),
    onSurface = Color(0xFFFFFFFF),

    surfaceVariant = Color(0xFF202020),
    onSurfaceVariant = Color(0xFFB8B8B8),

    outline = Color(0xFF424242),
    outlineVariant = Color(0xFF303030),

    scrim = Color(0xCC000000),

    error = Color(0xFFE0E0E0),
    onError = Color(0xFF171717),

    errorContainer = Color(0xFF383838),
    onErrorContainer = Color(0xFFFFFFFF),

    inverseSurface = Color(0xFFEAEAEA),
    inverseOnSurface = Color(0xFF171717),
    inversePrimary = Color(0xFF404040)
)


// =====================================================
// MONOCHROME LIGHT PALETTE
// =====================================================

private val LightAppColors = lightColorScheme(

    primary = Color(0xFF111111),
    onPrimary = Color(0xFFFFFFFF),

    primaryContainer = Color(0xFFE5E5E5),
    onPrimaryContainer = Color(0xFF111111),

    secondary = Color(0xFF555555),
    onSecondary = Color(0xFFFFFFFF),

    secondaryContainer = Color(0xFFEAEAEA),
    onSecondaryContainer = Color(0xFF222222),

    tertiary = Color(0xFF333333),
    onTertiary = Color(0xFFFFFFFF),

    tertiaryContainer = Color(0xFFE0E0E0),
    onTertiaryContainer = Color(0xFF222222),

    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF111111),

    surface = Color(0xFFF7F7F7),
    onSurface = Color(0xFF111111),

    surfaceVariant = Color(0xFFEAEAEA),
    onSurfaceVariant = Color(0xFF555555),

    outline = Color(0xFFBDBDBD),
    outlineVariant = Color(0xFFD6D6D6),

    scrim = Color(0x66000000),

    error = Color(0xFF555555),
    onError = Color(0xFFFFFFFF),

    errorContainer = Color(0xFFE5E5E5),
    onErrorContainer = Color(0xFF222222),

    inverseSurface = Color(0xFF222222),
    inverseOnSurface = Color(0xFFFFFFFF),
    inversePrimary = Color(0xFFE0E0E0)
)


// =====================================================
// APPLICATION SHAPES
// =====================================================

private val AppShapes = Shapes(

    extraSmall = RoundedCornerShape(4.dp),

    small = RoundedCornerShape(8.dp),

    medium = RoundedCornerShape(12.dp),

    large = RoundedCornerShape(16.dp),

    extraLarge = RoundedCornerShape(20.dp)
)


// =====================================================
// MAIN APPLICATION THEME
// =====================================================

@Composable
fun StudentCompanionTheme(

    darkTheme: Boolean = true,

    content: @Composable () -> Unit

) {

    val colorScheme = if (darkTheme) {
        DarkAppColors
    } else {
        LightAppColors
    }

    MaterialTheme(

        colorScheme = colorScheme,

        shapes = AppShapes,

        content = content
    )
}
