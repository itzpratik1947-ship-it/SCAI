
package com.studentcompanionai.app.ui.onboarding

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

import com.studentcompanionai.app.data.EducationCategory
import com.studentcompanionai.app.data.LearningCoachProfile
import com.studentcompanionai.app.data.LearningLevel
import com.studentcompanionai.app.data.LearningStyle
import com.studentcompanionai.app.data.NotificationPreferences
import com.studentcompanionai.app.data.PreferredFocusTime
import com.studentcompanionai.app.data.ScheduleSlot
import com.studentcompanionai.app.data.UserType

@Composable
fun LearnerOnboardingScreen(
    onSignOut: () -> Unit,
    onComplete: (LearningCoachProfile) -> Unit
) {

    // ---------------------------------------------------------
    // ONBOARDING NAVIGATION
    // ---------------------------------------------------------

    var currentStep by remember {
        mutableStateOf(0)
    }

    /*
     * 0 = Welcome
     * 1 = Personal information
     * 2 = Education
     * 3 = Schedule
     * 4 = Focus preferences
     * 5 = Profile review
     */

    // ---------------------------------------------------------
    // PERSONAL INFORMATION
    // ---------------------------------------------------------

    var preferredName by remember {
        mutableStateOf("")
    }

    var dateOfBirth by remember {
        mutableStateOf("")
    }

    // SCAI is exclusively for students.
    val defaultAvatar = "🎓"

    // ---------------------------------------------------------
    // EDUCATION
    // ---------------------------------------------------------

    var educationCategory by remember {
        mutableStateOf("School")
    }

    var qualification by remember {
        mutableStateOf("")
    }

    var stream by remember {
        mutableStateOf("")
    }

    var specialization by remember {
        mutableStateOf("")
    }

    var academicYear by remember {
        mutableStateOf("")
    }

    var semester by remember {
        mutableStateOf("")
    }

    var institution by remember {
        mutableStateOf("")
    }

    var boardOrUniversity by remember {
        mutableStateOf("")
    }

    val subjects = remember {
        mutableStateListOf<String>()
    }

    // ---------------------------------------------------------
    // SCHEDULE
    // ---------------------------------------------------------

    var wakeTime by remember {
        mutableStateOf("06:00 AM")
    }

    var sleepTime by remember {
        mutableStateOf("10:00 PM")
    }

    var dailyStudyMinutes by remember {
        mutableStateOf(120)
    }

    val availableDays = remember {
        mutableStateListOf<String>()
    }

    val availableSlots = remember {
        mutableStateListOf<String>()
    }

    // ---------------------------------------------------------
    // FOCUS PREFERENCES
    // ---------------------------------------------------------

    var focusDuration by remember {
        mutableStateOf(25)
    }

    var breakDuration by remember {
        mutableStateOf(5)
    }

    var dailyFocusTarget by remember {
        mutableStateOf(4)
    }

    var preferredFocusTime by remember {
        mutableStateOf("FLEXIBLE")
    }

    // ---------------------------------------------------------
    // NAVIGATION HELPERS
    // ---------------------------------------------------------

    fun goToStep(step: Int) {
        currentStep = step.coerceIn(0, 5)
    }

    // ---------------------------------------------------------
    // PROFILE CREATION
    // ---------------------------------------------------------

    fun createLearnerProfile(): LearningCoachProfile {

        val resolvedSubject = subjects.firstOrNull()
            ?: specialization.takeIf { it.isNotBlank() }
            ?: qualification.takeIf { it.isNotBlank() }
            ?: educationCategory

        val resolvedEducationCategory = when (educationCategory) {
            "School" -> EducationCategory.SCHOOL
            "Junior College" -> EducationCategory.HIGHER_SECONDARY
            "Undergraduate" -> EducationCategory.GRADUATION
            "Postgraduate" -> EducationCategory.POST_GRADUATION

            "Programming",
            "Language Learning",
            "Independent Learning" ->
                EducationCategory.INDEPENDENT_LEARNING

            else -> EducationCategory.OTHER
        }

        val resolvedFocusTime = runCatching {
            PreferredFocusTime.valueOf(preferredFocusTime)
        }.getOrDefault(PreferredFocusTime.FLEXIBLE)

        val resolvedAvailableSlots = availableSlots.mapNotNull { slot ->

            val times = when (slot) {
                "Early Morning" -> "05:00" to "08:00"
                "Morning" -> "08:00" to "12:00"
                "Afternoon" -> "12:00" to "17:00"
                "Evening" -> "17:00" to "21:00"
                "Night" -> "21:00" to "23:59"
                else -> null
            } ?: return@mapNotNull null

            ScheduleSlot(
                day = "ALL",
                startTime = times.first,
                endTime = times.second,
                label = slot
            )
        }

        /*
         * Learning preferences are configured later.
         * These defaults preserve compatibility with
         * the existing LearningCoachProfile model.
         */

        val defaultNotifications = NotificationPreferences(
            studyReminders = false,
            learningPlanReminders = false,
            focusReminders = false,
            dailyProgressSummary = false,
            achievementNotifications = false
        )

        return LearningCoachProfile(

            // Existing Learning Coach fields
            learningGoal = "",
            subject = resolvedSubject,
            currentLevel = LearningLevel.BEGINNER,
            targetDays = 30,
            dailyStudyMinutes = dailyStudyMinutes,
            preferredLearningStyle = LearningStyle.MIXED,

            // Personal information
            preferredName = preferredName.trim(),
            dateOfBirth = dateOfBirth,
            avatar = defaultAvatar,
            userType = UserType.STUDENT,

            // Education
            educationCategory = resolvedEducationCategory,
            qualification = qualification,
            stream = stream,
            specialization = specialization,
            academicYear = academicYear,
            semester = semester,
            institution = institution,
            boardOrUniversity = boardOrUniversity,
            subjects = subjects.toList(),

            // Schedule
            wakeTime = wakeTime,
            sleepTime = sleepTime,
            availableDays = availableDays.map {
                it.uppercase()
            },
            availableSlots = resolvedAvailableSlots,

            // Focus preferences
            focusDuration = focusDuration,
            breakDuration = breakDuration,
            dailyFocusTarget = dailyFocusTarget,
            preferredFocusTime = resolvedFocusTime,

            // Default learning preferences
            preferredLanguage = "English",
            preferredDifficulty =
                com.studentcompanionai.app.data.LearningDifficulty.ADAPTIVE,
            areasOfDifficulty = emptyList(),
            notificationPreferences = defaultNotifications,

            profileCompleted = false
        )
    }

    // ---------------------------------------------------------
    // SCREEN SEQUENCE
    // ---------------------------------------------------------

    when (currentStep) {

        // 0. WELCOME
        0 -> WelcomeScreen(
            onGetStarted = {
                goToStep(1)
            },
            onSignOut = onSignOut
        )

        // 1. PERSONAL INFORMATION
        1 -> PersonalInfoScreen(

            initialName = preferredName,
            initialDateOfBirth = dateOfBirth,

            onBack = {
                goToStep(0)
            },

            onContinue = { name, selectedDateOfBirth ->

                preferredName = name
                dateOfBirth = selectedDateOfBirth

                goToStep(2)
            }
        )

        // 2. EDUCATION
        2 -> EducationScreen(

            initialCategory = educationCategory,
            initialQualification = qualification,
            initialStream = stream,
            initialSpecialization = specialization,
            initialAcademicYear = academicYear,
            initialSemester = semester,
            initialInstitution = institution,
            initialBoardOrUniversity = boardOrUniversity,
            initialSubjects = subjects.toList(),

            onBack = {
                goToStep(1)
            },

            onContinue = {
                category,
                selectedQualification,
                selectedStream,
                selectedSpecialization,
                selectedYear,
                selectedSemester,
                selectedInstitution,
                selectedBoard,
                selectedSubjects ->

                educationCategory = category
                qualification = selectedQualification
                stream = selectedStream
                specialization = selectedSpecialization
                academicYear = selectedYear
                semester = selectedSemester
                institution = selectedInstitution
                boardOrUniversity = selectedBoard

                subjects.clear()
                subjects.addAll(selectedSubjects)

                goToStep(3)
            }
        )

        // 3. SCHEDULE
        3 -> ScheduleScreen(

            initialWakeTime = wakeTime,
            initialSleepTime = sleepTime,
            initialDailyStudyMinutes = dailyStudyMinutes,
            initialAvailableDays = availableDays.toList(),
            initialAvailableSlots = availableSlots.toList(),

            onBack = {
                goToStep(2)
            },

            onContinue = {
                selectedWakeTime,
                selectedSleepTime,
                studyMinutes,
                days,
                slots ->

                wakeTime = selectedWakeTime
                sleepTime = selectedSleepTime
                dailyStudyMinutes = studyMinutes

                availableDays.clear()
                availableDays.addAll(days)

                availableSlots.clear()
                availableSlots.addAll(slots)

                goToStep(4)
            }
        )

        // 4. FOCUS PREFERENCES
        4 -> FocusPreferencesScreen(

            initialFocusDuration = focusDuration,
            initialBreakDuration = breakDuration,
            initialDailyFocusTarget = dailyFocusTarget,
            initialPreferredFocusTime = preferredFocusTime,

            onBack = {
                goToStep(3)
            },

            onContinue = {
                duration,
                restDuration,
                dailyTarget,
                focusTime ->

                focusDuration = duration
                breakDuration = restDuration
                dailyFocusTarget = dailyTarget
                preferredFocusTime = focusTime

                goToStep(5)
            }
        )

        // 5. PROFILE REVIEW
        5 -> ProfileReviewScreen(

            preferredName = preferredName,
            avatar = defaultAvatar,
            userType = UserType.STUDENT.displayName,

            educationCategory = educationCategory,
            qualification = qualification,
            stream = stream,
            specialization = specialization,
            academicYear = academicYear,
            semester = semester,
            institution = institution,
            boardOrUniversity = boardOrUniversity,
            subjects = subjects.toList(),

            // Short-term goals are configured separately.
            learningGoal = "",
            secondaryGoals = emptyList(),
            targetAchievement = "",
            currentLevel = "BEGINNER",
            targetDays = 30,
            preferredLearningStyle = "MIXED",

            wakeTime = wakeTime,
            sleepTime = sleepTime,
            dailyStudyMinutes = dailyStudyMinutes,
            availableDays = availableDays.toList(),
            availableSlots = availableSlots.toList(),

            focusDuration = focusDuration,
            breakDuration = breakDuration,
            dailyFocusTarget = dailyFocusTarget,
            preferredFocusTime = preferredFocusTime,

            // Default learning preferences.
            preferredLanguage = "English",
            preferredDifficulty = "ADAPTIVE",
            areasOfDifficulty = emptyList(),
            notificationsEnabled = false,
            studyReminders = false,
            goalReminders = false,
            progressUpdates = false,

            onEditPersonalInfo = {
                goToStep(1)
            },

            onEditEducation = {
                goToStep(2)
            },

            onEditGoals = {
                // Goals are configured separately.
            },

            onEditSchedule = {
                goToStep(3)
            },

            onEditFocus = {
                goToStep(4)
            },

            onEditPreferences = {
                // Preferences are configured later.
            },

            onBack = {
                goToStep(4)
            },

            onComplete = {
                onComplete(createLearnerProfile())
            }
        )
    }
}
