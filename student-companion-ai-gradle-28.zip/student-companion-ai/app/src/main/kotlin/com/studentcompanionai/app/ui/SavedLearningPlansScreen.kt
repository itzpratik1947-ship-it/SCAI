package com.studentcompanionai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.LearningPlan
import com.studentcompanionai.app.data.StudentStorage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SavedLearningPlansScreen(
    onBackClick: () -> Unit = {},
    onOpenPlan: (LearningPlan) -> Unit = {},
    refreshKey: Int = 0
) {
    val context = LocalContext.current.applicationContext
    val uid = FirebaseAuth.getInstance().currentUser?.uid

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    val coroutineScope = rememberCoroutineScope()

    var plans by remember(uid) {
        mutableStateOf<List<LearningPlan>>(emptyList())
    }

    var isLoading by remember(uid) {
        mutableStateOf(true)
    }

    var isDeleting by remember(uid) {
        mutableStateOf(false)
    }

    var errorMessage by remember(uid) {
        mutableStateOf<String?>(null)
    }

    var planToDelete by remember(uid) {
        mutableStateOf<LearningPlan?>(null)
    }

    var reloadVersion by remember(uid) {
        mutableStateOf(0)
    }

    LaunchedEffect(uid, refreshKey, reloadVersion) {
        plans = emptyList()
        errorMessage = null

        if (uid == null) {
            isLoading = false
            errorMessage = "Sign in to view your saved learning plans."
            return@LaunchedEffect
        }

        isLoading = true

        try {
            val loadedPlans = withContext(Dispatchers.IO) {
                storage.loadLearningPlans()
            }

            if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                return@LaunchedEffect
            }

            plans = loadedPlans.sortedByDescending {
                it.updatedAt
            }

        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                errorMessage = e.localizedMessage
                    ?: "Could not load saved learning plans."
            }
        } finally {
            if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                isLoading = false
            }
        }
    }

    val selectedPlan = planToDelete

    if (selectedPlan != null) {
        AlertDialog(
            onDismissRequest = {
                if (!isDeleting) {
                    planToDelete = null
                }
            },
            title = {
                Text("Delete learning plan?")
            },
            text = {
                Text(
                    "Delete \"${selectedPlan.title}\"? " +
                        "This removes the saved plan from this device."
                )
            },
            confirmButton = {
                TextButton(
                    enabled = !isDeleting && uid != null,
                    onClick = {
                        if (isDeleting || uid == null) {
                            return@TextButton
                        }

                        if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                            planToDelete = null
                            errorMessage = "Your account changed. Please try again."
                            return@TextButton
                        }

                        isDeleting = true

                        coroutineScope.launch {
                            try {
                                withContext(Dispatchers.IO) {
                                    storage.deleteLearningPlan(selectedPlan.id)
                                }

                                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                                    plans = plans.filterNot {
                                        it.id == selectedPlan.id
                                    }

                                    planToDelete = null
                                    errorMessage = null
                                }

                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                                    errorMessage = e.localizedMessage
                                        ?: "Could not delete the plan."
                                    planToDelete = null
                                }
                            } finally {
                                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                                    isDeleting = false
                                }
                            }
                        }
                    }
                ) {
                    Text(
                        text = if (isDeleting) "Deleting..." else "Delete",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isDeleting,
                    onClick = {
                        planToDelete = null
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            

            Text(
                text = "My Learning Plans",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Continue learning where you left off.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider()

            when {
                isLoading -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator()
                        Text("Loading saved plans...")
                    }
                }

                errorMessage != null -> {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = errorMessage.orEmpty(),
                            color = MaterialTheme.colorScheme.error
                        )

                        if (uid != null) {
                            OutlinedButton(
                                onClick = {
                                    reloadVersion++
                                }
                            ) {
                                Text("Try Again")
                            }
                        }
                    }
                }

                plans.isEmpty() -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "No saved plans yet",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )

                        Text(
                            text = "Generate a learning plan to see it here.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                    }
                }

                else -> {
                    Text(
                        text = "${plans.size} saved " +
                            if (plans.size == 1) "plan" else "plans",
                        style = MaterialTheme.typography.titleMedium
                    )

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(
                            items = plans,
                            key = { it.id }
                        ) { plan ->
                            SavedPlanCard(
                                plan = plan,
                                onOpen = {
                                    if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                                        onOpenPlan(plan)
                                    }
                                },
                                onDelete = {
                                    if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                                        planToDelete = plan
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SavedPlanCard(
    plan: LearningPlan,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = plan.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = plan.subject,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary
            )

            Text(
                text = plan.goal,
                style = MaterialTheme.typography.bodyMedium
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${plan.completedDays}/${plan.totalDays} days",
                    style = MaterialTheme.typography.bodySmall
                )

                Text(
                    text = "${plan.progressPercent}%",
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            LinearProgressIndicator(
                progress = {
                    plan.progressPercent / 100f
                },
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "${plan.dailyStudyMinutes} min/day · " +
                    "${plan.targetDays} days",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onOpen,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Open Plan")
                }

                OutlinedButton(
                    onClick = onDelete
                ) {
                    Text("Delete")
                }
            }
        }
    }
}