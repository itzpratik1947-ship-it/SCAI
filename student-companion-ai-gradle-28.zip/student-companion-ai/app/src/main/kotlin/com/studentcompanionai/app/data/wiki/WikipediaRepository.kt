
package com.studentcompanionai.app.data.wiki

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class WikipediaArticle(
    val id: Int,
    val key: String,
    val title: String,
    val description: String,
    val excerpt: String
) {
    val articleUrl: String
        get() = "https://en.wikipedia.org/wiki/" +
            key.replace(" ", "_")
}

class WikipediaRepository {

    suspend fun search(
        query: String,
        limit: Int = 10
    ): List<WikipediaArticle> = withContext(Dispatchers.IO) {

        val cleanedQuery = query.trim()

        require(cleanedQuery.isNotEmpty()) {
            "Enter a topic to search."
        }

        val encodedQuery = URLEncoder.encode(
            cleanedQuery,
            Charsets.UTF_8.name()
        )

        val safeLimit = limit.coerceIn(1, 20)

        val url = URL(
            "https://en.wikipedia.org/w/rest.php/v1/search/page" +
                "?q=$encodedQuery&limit=$safeLimit"
        )

        val connection =
            (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10_000
                readTimeout = 12_000

                setRequestProperty(
                    "Accept",
                    "application/json"
                )

                setRequestProperty(
                    "Api-User-Agent",
                    "StudentCompanionAI/1.0 (Android educational app)"
                )
            }

        try {
            val status = connection.responseCode

            if (status !in 200..299) {
                throw IOException(
                    "Wikipedia returned HTTP $status. Try again shortly."
                )
            }

            val body = connection.inputStream
                .bufferedReader()
                .use { it.readText() }

            val root = JSONObject(body)
            val pages = root.optJSONArray("pages")
                ?: return@withContext emptyList()

            buildList {
                for (index in 0 until pages.length()) {
                    val page = pages.optJSONObject(index)
                        ?: continue

                    val description = page.optString(
                        "description",
                        ""
                    ).takeUnless {
                        it == "null"
                    }.orEmpty()

                    val excerpt = page.optString(
                        "excerpt",
                        ""
                    )
                        .replace(Regex("<[^>]*>"), " ")
                        .replace(Regex("\\s+"), " ")
                        .trim()

                    add(
                        WikipediaArticle(
                            id = page.optInt("id"),
                            key = page.optString("key", ""),
                            title = page.optString(
                                "title",
                                "Untitled article"
                            ),
                            description = description,
                            excerpt = excerpt
                        )
                    )
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}
