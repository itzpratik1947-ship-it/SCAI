
package com.studentcompanionai.app.ui

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.FocusSession
import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiSecondaryButton
import com.studentcompanionai.app.ui.components.ScaiTopBar
import kotlinx.coroutines.delay

@Composable
fun ActiveFocusScreen(
    context: Context,
    onBackClick: () -> Unit,
    onSessionCompleted: (FocusSession) -> Unit,
    uid: String? = FirebaseAuth.getInstance().currentUser?.uid
) {

    val auth = remember {
        FirebaseAuth.getInstance()
    }

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    fun isCurrentAccount(): Boolean {
        return uid != null && auth.currentUser?.uid == uid
    }

    // -----------------------------------------
    // SESSION INFORMATION
    // -----------------------------------------

    val durationMinutes = remember(context, uid) {
        storage.loadFocusDuration()
    }

    val subjectId = remember(context, uid) {
        storage.loadFocusSubjectId()
    }

    val taskId = remember(context, uid) {
        storage.loadFocusTaskId()
    }

    val subjectName = remember(context, uid, subjectId) {
        if (subjectId != null) {
            storage.loadSubjects()
                .firstOrNull { it.id == subjectId }
                ?.name ?: "Study session"
        } else {
            "Independent study"
        }
    }

    val taskTitle = remember(context, uid, taskId) {
        if (taskId != null) {
            storage.loadTasks()
                .firstOrNull { it.id == taskId }
                ?.title ?: "General focus"
        } else {
            "Open study session"
        }
    }

    // -----------------------------------------
    // TIMER STATE
    // -----------------------------------------

    var isPaused by remember(context, uid) {
        mutableStateOf(storage.loadFocusPaused())
    }

    var remainingSeconds by remember(context, uid) {
        mutableIntStateOf(
            if (storage.loadFocusPaused()) {
                storage.loadFocusRemainingSeconds().coerceAtLeast(0)
            } else {
                (
                    (
                        storage.loadFocusEndTime() -
                            System.currentTimeMillis() + 999L
                    ) / 1000L
                ).coerceAtLeast(0L).toInt()
            }
        )
    }

    var completionSent by remember(context, uid) {
        mutableStateOf(false)
    }

    // -----------------------------------------
    // SESSION COMPLETION
    // -----------------------------------------

    fun completeSession() {

        if (completionSent || !isCurrentAccount()) return

        completionSent = true

        val completionTime = System.currentTimeMillis()

        val completedSession = FocusSession(
            id = completionTime,
            minutes = durationMinutes,
            timestamp = completionTime,
            subjectId = subjectId,
            taskId = taskId
        )

        if (taskId != null) {

            val updatedTasks = storage.loadTasks().map { task ->

                if (task.id == taskId) {
                    task.copy(isCompleted = true)
                } else {
                    task
                }
            }

            if (!isCurrentAccount()) return

            storage.saveTasks(updatedTasks)
        }

        if (!isCurrentAccount()) return

        storage.clearActiveFocusSession()

        if (isCurrentAccount()) {
            onSessionCompleted(completedSession)
        }
    }

    // -----------------------------------------
    // AUTOMATIC TIMER UPDATE
    // -----------------------------------------

    LaunchedEffect(uid, isPaused, completionSent) {

        if (uid != null && !isPaused && !completionSent) {

            while (isCurrentAccount()) {

                val remainingMillis =
                    storage.loadFocusEndTime() -
                        System.currentTimeMillis()

                val updatedSeconds = (
                    (remainingMillis + 999L) / 1000L
                ).coerceAtLeast(0L).toInt()

                remainingSeconds = updatedSeconds

                if (updatedSeconds <= 0) {
                    completeSession()
                    break
                }

                delay(250L)
            }
        }
    }

    // -----------------------------------------
    // TIMER DISPLAY
    // -----------------------------------------

    val totalSeconds = (durationMinutes * 60).coerceAtLeast(1)

    val progress = (
        remainingSeconds.toFloat() / totalSeconds.toFloat()
    ).coerceIn(0f, 1f)

    val formattedTime = String.format(
        "%02d:%02d",
        remainingSeconds / 60,
        remainingSeconds % 60
    )

    // -----------------------------------------
    // UI
    // -----------------------------------------

    ScaiScreen(
        scrollable = true
    ) {

        ScaiTopBar(
    title = "Focus session",
    subtitle = "Stay focused on your work"
)

        Spacer(Modifier.height(24.dp))

        // SESSION MESSAGE

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = when {
                    remainingSeconds <= 0 -> "Session completed"
                    isPaused -> "Take a break"
                    else -> "Stay focused"
                },
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = when {
                    remainingSeconds <= 0 ->
                        "Your focus time has ended."

                    isPaused ->
                        "Your session is paused. Resume when ready."

                    else ->
                        "One task. One session. No distractions."
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }

        Spacer(Modifier.height(28.dp))

        // TIMER CARD

        ScaiCard(
            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = "TIME REMAINING",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.2.sp
            )

            Spacer(Modifier.height(22.dp))

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {

                Box(
                    modifier = Modifier.size(250.dp),
                    contentAlignment = Alignment.Center
                ) {

                    // Resolve theme colors before entering Canvas.

                    val trackColor =
                        MaterialTheme.colorScheme.surfaceVariant

                    val progressColor =
                        MaterialTheme.colorScheme.onSurface

                    Canvas(
                        modifier = Modifier.fillMaxSize()
                    ) {

                        val stroke = 11.dp.toPx()

                        drawArc(
                            color = trackColor,
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(
                                width = stroke,
                                cap = StrokeCap.Round
                            )
                        )

                        drawArc(
                            color = progressColor,
                            startAngle = -90f,
                            sweepAngle = 360f * progress,
                            useCenter = false,
                            style = Stroke(
                                width = stroke,
                                cap = StrokeCap.Round
                            )
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {

                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.displayLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(Modifier.height(12.dp))

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {

                            Text(
                                text = when {
                                    remainingSeconds <= 0 -> "COMPLETED"
                                    isPaused -> "PAUSED"
                                    else -> "IN PROGRESS"
                                },
                                modifier = Modifier.padding(
                                    horizontal = 14.dp,
                                    vertical = 7.dp
                                ),
                                color = MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.8.sp
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            ScaiDivider()

            Spacer(Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                ActiveInfoCard(
                    label = "DURATION",
                    value = "$durationMinutes min",
                    modifier = Modifier.weight(1f)
                )

                ActiveInfoCard(
                    label = "REMAINING",
                    value = "${remainingSeconds / 60} min",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(Modifier.height(22.dp))

        // CURRENT SESSION INFORMATION

        Text(
            text = "Current session",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(Modifier.height(12.dp))

        ScaiCard(
            modifier = Modifier.fillMaxWidth()
        ) {

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {

                Surface(
                    modifier = Modifier.size(44.dp),
                    shape = RoundedCornerShape(13.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {

                    Box(
                        contentAlignment = Alignment.Center
                    ) {

                        Text(
                            text = "S",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }

                Spacer(Modifier.size(12.dp))

                Column(
                    modifier = Modifier.weight(1f)
                ) {

                    Text(
                        text = subjectName,
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = taskTitle,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            ScaiDivider()

            Spacer(Modifier.height(14.dp))

            Text(
                text = if (isPaused) {
                    "Resume when you're ready to continue."
                } else {
                    "Keep your attention on this task until the session ends."
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Spacer(Modifier.height(24.dp))

        // PAUSE / RESUME CONTROL

        ScaiPrimaryButton(
            text = if (isPaused) {
                "Resume session"
            } else {
                "Pause session"
            },
            onClick = {

                if (!isCurrentAccount() || completionSent) {
                    return@ScaiPrimaryButton
                }

                if (isPaused) {

                    val newEndTime = System.currentTimeMillis() +
                        remainingSeconds * 1000L

                    storage.saveActiveFocusSession(
                        durationMinutes = durationMinutes,
                        endTime = newEndTime,
                        remainingSeconds = remainingSeconds,
                        isPaused = false,
                        subjectId = subjectId,
                        taskId = taskId
                    )

                    isPaused = false

                } else {

                    val currentRemaining = (
                        (
                            storage.loadFocusEndTime() -
                                System.currentTimeMillis() + 999L
                        ) / 1000L
                    ).coerceAtLeast(0L).toInt()

                    remainingSeconds = currentRemaining

                    storage.saveActiveFocusSession(
                        durationMinutes = durationMinutes,
                        endTime = 0L,
                        remainingSeconds = currentRemaining,
                        isPaused = true,
                        subjectId = subjectId,
                        taskId = taskId
                    )

                    isPaused = true
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = uid != null && !completionSent
        )

        Spacer(Modifier.height(8.dp))

        // FINISH SESSION

        ScaiSecondaryButton(
            text = "Finish session",
            onClick = {
                completeSession()
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = uid != null && !completionSent
        )

        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ActiveInfoCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {

        Column(
            modifier = Modifier.padding(14.dp)
        ) {

            Text(
                text = label,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = value,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
