
package com.studentcompanionai.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studentcompanionai.app.data.InitialAssessmentResult
import com.studentcompanionai.app.data.TopicKnowledgeResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val AssessmentBackground = Color(0xFF0B1020)
private val AssessmentCard = Color(0xFF151D32)
private val AssessmentPrimary = Color(0xFF8B7CFF)
private val AssessmentSecondary = Color(0xFF42D6E8)
private val AssessmentSuccess = Color(0xFF42C98A)
private val AssessmentWarning = Color(0xFFFFC46B)
private val AssessmentDanger = Color(0xFFFF7777)
private val AssessmentText = Color(0xFFF3F4FA)
private val AssessmentMuted = Color(0xFF9BA6BD)

@Composable
fun InitialAssessmentResultScreen(
    result: InitialAssessmentResult,
    onBackClick: () -> Unit,
    onContinueLearning: () -> Unit
) {
    val score = result.overallScorePercent.coerceIn(0, 100)

    val performanceColor = when {
        score >= 85 -> AssessmentSuccess
        score >= 65 -> AssessmentSecondary
        score >= 40 -> AssessmentWarning
        else -> AssessmentDanger
    }

    val performanceMessage = when {
        score >= 85 -> "Excellent foundation"
        score >= 65 -> "Good understanding"
        score >= 40 -> "Room for improvement"
        else -> "More foundational learning needed"
    }

    val completionDate = SimpleDateFormat(
        "dd MMM yyyy, hh:mm a",
        Locale.getDefault()
    ).format(Date(result.completedAt))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AssessmentBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {

        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = onBackClick,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Back")
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "Assessment Results",
                    color = AssessmentText,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = result.profileSubject,
                    color = AssessmentMuted,
                    fontSize = 13.sp
                )
            }
        }

        // Overall score card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = AssessmentCard
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "YOUR OVERALL SCORE",
                    color = AssessmentMuted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.5.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .background(
                            color = performanceColor.copy(alpha = 0.12f),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$score%",
                            color = performanceColor,
                            fontSize = 42.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Text(
                            text = "Score",
                            color = AssessmentMuted,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = performanceMessage,
                    color = performanceColor,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Your assessment has been evaluated. " +
                        "The analysis below identifies areas that need attention.",
                    color = AssessmentMuted,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 19.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                LinearProgressIndicator(
                    progress = score / 100f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    color = performanceColor,
                    trackColor = Color(0xFF303A50)
                )
            }
        }

        // Assessment statistics
        Text(
            text = "Assessment Overview",
            color = AssessmentText,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OverviewCard(
                title = "Questions",
                value = result.totalQuestions.toString(),
                modifier = Modifier.weight(1f)
            )

            OverviewCard(
                title = "Marks Earned",
                value = formatMarks(result.awardedMarks),
                modifier = Modifier.weight(1f)
            )

            OverviewCard(
                title = "Total Marks",
                value = formatMarks(result.totalMarks),
                modifier = Modifier.weight(1f)
            )
        }

        // Topic analysis
        Text(
            text = "Topic-wise Knowledge Analysis",
            color = AssessmentText,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        if (result.topicResults.isEmpty()) {
            EmptyResultMessage(
                message = "No topic analysis is available for this assessment."
            )
        } else {
            result.topicResults.forEach { topic ->
                TopicResultCard(topic = topic)
            }
        }

        // Strengths
        val allStrengths = result.topicResults
            .flatMap { it.identifiedStrengths }
            .distinct()

        Text(
            text = "Your Strengths",
            color = AssessmentText,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        if (allStrengths.isEmpty()) {
            EmptyResultMessage(
                message = "No specific strengths were identified yet."
            )
        } else {
            InsightCard(
                items = allStrengths,
                accentColor = AssessmentSuccess,
                emptyMessage = "No strengths identified."
            )
        }

        // Weaknesses
        val allWeaknesses = result.topicResults
            .flatMap { it.identifiedWeaknesses }
            .distinct()

        Text(
            text = "Areas to Improve",
            color = AssessmentText,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        if (allWeaknesses.isEmpty()) {
            EmptyResultMessage(
                message = "No specific weaknesses were identified."
            )
        } else {
            InsightCard(
                items = allWeaknesses,
                accentColor = AssessmentWarning,
                emptyMessage = "No weaknesses identified."
            )
        }

        // Individual evaluation feedback
        Text(
            text = "Question-wise Feedback",
            color = AssessmentText,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        if (result.evaluations.isEmpty()) {
            EmptyResultMessage(
                message = "No individual evaluation feedback is available."
            )
        } else {
            result.evaluations.forEachIndexed { index, evaluation ->

                val response = result.responses.firstOrNull {
                    it.questionId == evaluation.questionId
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = AssessmentCard
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Question ${index + 1}",
                                color = AssessmentText,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )

                            Text(
                                text = "${formatMarks(evaluation.awardedMarks)} / " +
                                    "${evaluation.maximumMarks}",
                                color = AssessmentSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        if (response != null) {
                            val learnerAnswer = when {
                                response.writtenAnswer.isNotBlank() ->
                                    response.writtenAnswer

                                response.selectedOptionIndex != null ->
                                    "Selected option ${response.selectedOptionIndex + 1}"

                                else -> "Not answered"
                            }

                            Text(
                                text = "Your response",
                                color = AssessmentMuted,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Text(
                                text = learnerAnswer,
                                color = AssessmentText,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }

                        Divider(color = Color(0xFF303A50))

                        Text(
                            text = "Feedback",
                            color = AssessmentMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Text(
                            text = evaluation.feedback.ifBlank {
                                "No feedback provided."
                            },
                            color = AssessmentText,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )

                        Text(
                            text = "Evaluation: ${evaluation.evaluationBasis}",
                            color = AssessmentMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Completion information
        Text(
            text = "Completed on $completionDate",
            color = AssessmentMuted,
            fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        // Continue button
        Button(
            onClick = onContinueLearning,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AssessmentPrimary
            )
        ) {
            Text(
                text = "Continue to Learning",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun OverviewCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = AssessmentCard
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 18.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = AssessmentText,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(5.dp))

            Text(
                text = title,
                color = AssessmentMuted,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun TopicResultCard(
    topic: TopicKnowledgeResult
) {
    val score = topic.scorePercent.coerceIn(0, 100)

    val levelColor = when (topic.knowledgeLevel.lowercase()) {
        "strong" -> AssessmentSuccess
        "good" -> AssessmentSecondary
        "developing" -> AssessmentWarning
        else -> AssessmentDanger
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = AssessmentCard
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = topic.topic,
                        color = AssessmentText,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = topic.knowledgeLevel,
                        color = levelColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = "$score%",
                    color = levelColor,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            LinearProgressIndicator(
                progress = score / 100f,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp),
                color = levelColor,
                trackColor = Color(0xFF303A50)
            )

            Text(
                text = "${topic.correctAnswers} correct out of " +
                    "${topic.totalQuestions} questions",
                color = AssessmentMuted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun InsightCard(
    items: List<String>,
    accentColor: Color,
    emptyMessage: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = AssessmentCard
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (items.isEmpty()) {
                Text(
                    text = emptyMessage,
                    color = AssessmentMuted,
                    fontSize = 13.sp
                )
            } else {
                items.forEach { item ->
                    Row(
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(top = 5.dp)
                                .size(8.dp)
                                .background(
                                    accentColor,
                                    CircleShape
                                )
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        Text(
                            text = item,
                            color = AssessmentText,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyResultMessage(
    message: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = AssessmentCard
    ) {
        Text(
            text = message,
            modifier = Modifier.padding(16.dp),
            color = AssessmentMuted,
            fontSize = 13.sp
        )
    }
}

private fun formatMarks(value: Double): String {
    return if (value % 1.0 == 0.0) {
        value.toInt().toString()
    } else {
        String.format(Locale.getDefault(), "%.1f", value)
    }
}
