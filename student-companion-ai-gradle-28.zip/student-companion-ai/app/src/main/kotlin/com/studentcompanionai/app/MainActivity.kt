package com.studentcompanionai.app

import com.studentcompanionai.app.ui.onboarding.LearnerOnboardingHost

import android.app.UiModeManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.Toast

import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.setValue

import androidx.compose.runtime.saveable.rememberSaveable

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.auth.FirebaseAuth

import com.studentcompanionai.app.data.GamificationManager
import com.studentcompanionai.app.data.LearningCoachProfile
import com.studentcompanionai.app.data.LearningPlan
import com.studentcompanionai.app.data.PracticeQuiz
import com.studentcompanionai.app.data.PracticeResultStorage
import com.studentcompanionai.app.data.StoredPracticeResult
import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.data.StudentSyncManager
import com.studentcompanionai.app.data.XpBreakdown

import com.studentcompanionai.app.ui.AIChatScreen
import com.studentcompanionai.app.ui.AIQuizGeneratorScreen
import com.studentcompanionai.app.ui.ActiveFocusScreen
import com.studentcompanionai.app.ui.ActivitiesDashboardController
import com.studentcompanionai.app.ui.HomeDashboardScreen
import com.studentcompanionai.app.ui.HomeDashboardController
import com.studentcompanionai.app.ui.ActivitiesDashboardScreen
import com.studentcompanionai.app.ui.FocusScreen
import com.studentcompanionai.app.ui.LearningCoachDashboardScreen
import com.studentcompanionai.app.ui.LearningCoachSetupScreen
import com.studentcompanionai.app.ui.LearningPlanDetailScreen
import com.studentcompanionai.app.ui.PracticeHistoryScreen
import com.studentcompanionai.app.ui.PracticeQuizScreen
import com.studentcompanionai.app.ui.PracticeScreen
import com.studentcompanionai.app.ui.ProfileScreen
import com.studentcompanionai.app.ui.SavedLearningPlansScreen
import com.studentcompanionai.app.ui.StatisticsScreen
import com.studentcompanionai.app.ui.SubjectsScreen
import com.studentcompanionai.app.ui.TasksScreen
import com.studentcompanionai.app.ui.WikipediaSearchScreen
import com.studentcompanionai.app.ui.ResourceDiscoveryScreen
import com.studentcompanionai.app.ui.ResourceLibraryScreen
import com.studentcompanionai.app.ui.auth.AuthScreen
import com.studentcompanionai.app.ui.theme.StudentCompanionTheme

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import java.util.UUID

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        FirebaseApp.initializeApp(this)

        if (BuildConfig.DEBUG) {
            FirebaseAppCheck.getInstance()
                .installAppCheckProviderFactory(
                    DebugAppCheckProviderFactory.getInstance()
                )
        }

        val themePreferences = getSharedPreferences(
            "scai_theme_preferences",
            MODE_PRIVATE
        )

        val initialDarkTheme = themePreferences.getBoolean(
            "dark_theme",
            true
        )

        // Apply saved application-wide theme.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {

            val uiModeManager =
                getSystemService(Context.UI_MODE_SERVICE) as UiModeManager

            uiModeManager.setApplicationNightMode(
                if (initialDarkTheme) {
                    UiModeManager.MODE_NIGHT_YES
                } else {
                    UiModeManager.MODE_NIGHT_NO
                }
            )
        }

        setContent {

            var isDarkTheme by remember {
                mutableStateOf(initialDarkTheme)
            }

            StudentCompanionTheme(
                darkTheme = isDarkTheme
            ) {

                StudentCompanionApp(
                    isDarkTheme = isDarkTheme,

                    onThemeChange = { dark ->

                        isDarkTheme = dark

                        themePreferences.edit()
                            .putBoolean("dark_theme", dark)
                            .apply()

                        // Update Android XML resources globally.
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {

                            val uiModeManager =
                                getSystemService(Context.UI_MODE_SERVICE)
                                    as UiModeManager

                            uiModeManager.setApplicationNightMode(
                                if (dark) {
                                    UiModeManager.MODE_NIGHT_YES
                                } else {
                                    UiModeManager.MODE_NIGHT_NO
                                }
                            )
                        }
                    }
                )
            }
        }
    }
}


@Composable
fun StudentCompanionApp(
    isDarkTheme: Boolean,
    onThemeChange: (Boolean) -> Unit
) {

    val context = LocalContext.current

    val auth = remember {
        FirebaseAuth.getInstance()
    }

    // -----------------------------------------
    // CURRENT ACCOUNT
    // -----------------------------------------

    var accountUid by remember {
        mutableStateOf(auth.currentUser?.uid)
    }

    val isAuthenticated = accountUid != null

    DisposableEffect(auth) {

        val authListener =
            FirebaseAuth.AuthStateListener { firebaseAuth ->

                accountUid = firebaseAuth.currentUser?.uid
            }

        auth.addAuthStateListener(authListener)

        onDispose {
            auth.removeAuthStateListener(authListener)
        }
    }


    // -----------------------------------------
    // ACCOUNT-SCOPED DATA MANAGERS
    // -----------------------------------------

    val storage = remember(accountUid) {
        StudentStorage(context, accountUid)
    }

    val resultStorage = remember(accountUid) {
        PracticeResultStorage(context, accountUid)
    }

    val syncManager = remember(accountUid) {
        StudentSyncManager(context)
    }

    val gamificationManager = remember(accountUid) {
        GamificationManager(context, accountUid)
    }

    val scope = rememberCoroutineScope()


    // -----------------------------------------
    // NAVIGATION STATE
    // -----------------------------------------

    var currentScreen by rememberSaveable {
        mutableStateOf("home")
    }

    // Migrate a previously saved Learn route from older app versions.
    LaunchedEffect(currentScreen) {
        if (currentScreen == "learn") {
            currentScreen = "activities"
        }
    }

    // Preserve the navigation origin for learning-plan destinations.
    var learningPlansListBackScreen by rememberSaveable {
        mutableStateOf("activities")
    }

    var learningPlanDetailBackScreen by rememberSaveable {
        mutableStateOf("learning_plans")
    }

    var activeFocusScreen by remember {
        mutableStateOf(false)
    }

    var selectedLearningPlan by remember {
        mutableStateOf<LearningPlan?>(null)
    }

    var selectedPracticeQuiz by remember {
        mutableStateOf<PracticeQuiz?>(null)
    }

    var latestXpBreakdown by remember {
        mutableStateOf<XpBreakdown?>(null)
    }


    // -----------------------------------------
    // PROFILE COMPLETION STATE
    // -----------------------------------------

    var profileCheckCompleted by rememberSaveable(accountUid) {
        mutableStateOf(accountUid == null)
    }


    // -----------------------------------------
    // LEARNING COACH STATE
    // -----------------------------------------

    var learningCoachProfile by remember {
        mutableStateOf<LearningCoachProfile?>(null)
    }

    var learningCoachReturnScreen by remember {
        mutableStateOf("home")
    }

    var learningCoachDashboardBackScreen by remember {
        mutableStateOf("learning_coach_setup")
    }

    var learningPlansRefreshKey by remember {
        mutableIntStateOf(0)
    }

    var practiceResultsRefreshKey by remember {
        mutableIntStateOf(0)
    }


    // -----------------------------------------
    // PRACTICE RESULTS
    // -----------------------------------------

    val practiceResults = remember(
        accountUid,
        practiceResultsRefreshKey
    ) {
        if (accountUid != null) {
            resultStorage.loadResults()
        } else {
            emptyList<StoredPracticeResult>()
        }
    }


    // -----------------------------------------
    // SYNC STATE
    // -----------------------------------------

    var isSyncing by remember(accountUid) {
        mutableStateOf(false)
    }

    var syncMessage by remember(accountUid) {
        mutableStateOf<String?>(null)
    }

    var showOwnershipConfirmation by remember {
        mutableStateOf(false)
    }

    var showDeleteProfileConfirmation by remember(accountUid) {
        mutableStateOf(false)
    }


    // -----------------------------------------
    // HOME AND ACTIVITIES DATA
    // -----------------------------------------

    var focusSessions by remember(accountUid) {
        mutableIntStateOf(0)
    }

    var focusMinutes by remember(accountUid) {
        mutableIntStateOf(0)
    }

    var totalTasks by remember(accountUid) {
        mutableIntStateOf(0)
    }

    var completedTasks by remember(accountUid) {
        mutableIntStateOf(0)
    }

    var subjectCount by remember(accountUid) {
        mutableIntStateOf(0)
    }

    var dataVersion by remember(accountUid) {
        mutableIntStateOf(0)
    }

    var activeFocus by remember(accountUid) {
        mutableStateOf(
            ActivitiesDashboardController.ActiveFocus()
        )
    }


    // -----------------------------------------
    // ACCOUNT INITIALIZATION TRACKER
    // -----------------------------------------

    var lastInitializedAccountKey by rememberSaveable {
        mutableStateOf("")
    }


    // -----------------------------------------
    // REFRESH HOME AND ACTIVITIES DATA
    // -----------------------------------------

    fun refreshHomeData() {

    if (accountUid == null) {

        focusSessions = 0
        focusMinutes = 0
        totalTasks = 0
        completedTasks = 0
        subjectCount = 0

        dataVersion++

        return
    }

    focusSessions =
        storage.getTodayFocusSessions().size

    focusMinutes =
        storage.getTodayFocusMinutes()

    // Load all stored tasks.
    val tasks = storage.loadTasks()

    // Match the filtering rules used by TasksScreen.
    val independentTasks = tasks.filter {
        it.learningPlanId.isNullOrBlank()
    }

    totalTasks = independentTasks.size

    completedTasks =
        independentTasks.count {
            it.isCompleted && !it.isSkipped
        }

    subjectCount =
        storage.loadSubjects().size

    dataVersion++
}


    // -----------------------------------------
    // REFRESH SAVED ACTIVE FOCUS SESSION
    // -----------------------------------------

    fun refreshActiveFocus() {

        if (
            accountUid == null ||
            !storage.hasActiveFocusSession()
        ) {
            activeFocus =
                ActivitiesDashboardController.ActiveFocus()
            return
        }

        val isPaused = storage.loadFocusPaused()

        val remainingSeconds = if (isPaused) {

            storage.loadFocusRemainingSeconds()
                .coerceAtLeast(0)

        } else {

            (
                (
                    storage.loadFocusEndTime() -
                        System.currentTimeMillis() +
                        999L
                    ) / 1000L
                ).toInt().coerceAtLeast(0)
        }

        val subjectId = storage.loadFocusSubjectId()
        val taskId = storage.loadFocusTaskId()

        val subjectName = storage.loadSubjects()
            .firstOrNull { it.id == subjectId }
            ?.name

        val taskTitle = storage.loadTasks()
            .firstOrNull { it.id == taskId }
            ?.title

        activeFocus =
            ActivitiesDashboardController.ActiveFocus(
                isActive = true,
                isPaused = isPaused,
                remainingSeconds = remainingSeconds,
                subjectName = subjectName,
                taskTitle = taskTitle
            )
    }


    // -----------------------------------------
    // ACCOUNT CHANGE AND PROFILE CHECK
    // -----------------------------------------

    LaunchedEffect(accountUid) {

        val requestedUid = accountUid
        val accountKey = requestedUid ?: "signed_out"

        // If initialization already completed for this account,
        // preserve the current screen after Activity recreation.
        if (
            lastInitializedAccountKey == accountKey &&
            profileCheckCompleted
        ) {
            return@LaunchedEffect
        }

        // Reset account-specific state only when the account changes.
        if (lastInitializedAccountKey != accountKey) {

            currentScreen = "home"
            activeFocusScreen = false

            activeFocus =
                ActivitiesDashboardController.ActiveFocus()

            selectedLearningPlan = null
            selectedPracticeQuiz = null
            latestXpBreakdown = null

            learningCoachProfile = null
            learningCoachReturnScreen = "home"

            learningPlansRefreshKey++
            practiceResultsRefreshKey++

            syncMessage = null
            showOwnershipConfirmation = false
            showDeleteProfileConfirmation = false

            isSyncing = false
        }

        if (requestedUid == null) {

            profileCheckCompleted = true

            lastInitializedAccountKey = accountKey

            refreshHomeData()

            return@LaunchedEffect
        }

        // Run the profile check again if it was interrupted.
        profileCheckCompleted = false

        val profileCompleted = try {

            storage.isProfileCompleted()

        } catch (_: Exception) {

            false
        }

        // Ensure the account has not changed during the check.
        if (
            auth.currentUser?.uid != requestedUid ||
            accountUid != requestedUid
        ) {
            return@LaunchedEffect
        }

        currentScreen = if (profileCompleted) {
            "home"
        } else {
            "onboarding"
        }

        profileCheckCompleted = true

        // Record successful initialization only after the
        // profile check has completed.
        lastInitializedAccountKey = accountKey

        refreshHomeData()
    }


    // -----------------------------------------
    // LIVE ACTIVE FOCUS DASHBOARD REFRESH
    // -----------------------------------------

    LaunchedEffect(accountUid, currentScreen) {

        if (
            accountUid == null ||
            (
                currentScreen != "home" &&
                currentScreen != "activities"
            )
        ) {
            return@LaunchedEffect
        }

        while (true) {
            refreshActiveFocus()
            delay(1000L)
        }
    }


    // -----------------------------------------
    // FIREBASE SYNC
    // -----------------------------------------

    fun startSync() {

        val requestedUid = accountUid

        if (requestedUid == null) {

            syncMessage = "Please sign in before syncing."

            return
        }

        if (isSyncing) {
            return
        }

        if (auth.currentUser?.uid != requestedUid) {

            syncMessage =
                "Your account changed. Please sign in again."

            return
        }

        // Update Compose state before launching the operation.
        isSyncing = true

        syncMessage = "Syncing your data..."

        showOwnershipConfirmation = false

        scope.launch {

            try {

                // Give Compose time to display the loading indicator.
                // This also prevents an extremely fast response from
                // making the loading state invisible.
                delay(300L)

                if (
                    auth.currentUser?.uid != requestedUid ||
                    accountUid != requestedUid
                ) {
                    return@launch
                }

                val result = syncManager.sync()

                if (
                    auth.currentUser?.uid != requestedUid ||
                    accountUid != requestedUid
                ) {
                    return@launch
                }

                if (
                    result.startsWith(
                        "Sync requires confirmation",
                        ignoreCase = true
                    )
                ) {

                    showOwnershipConfirmation = true

                    syncMessage =
                        "Local data ownership confirmation is required."

                } else if (
                    result.startsWith(
                        "Sync completed",
                        ignoreCase = true
                    )
                ) {

                    syncMessage =
                        "Sync completed successfully."

                    refreshHomeData()

                    practiceResultsRefreshKey++
                    learningPlansRefreshKey++

                } else {

                    syncMessage = result
                }

            } catch (e: Exception) {

                if (
                    auth.currentUser?.uid == requestedUid &&
                    accountUid == requestedUid
                ) {

                    syncMessage =
                        "Sync failed: ${
                            e.localizedMessage
                                ?: "Check your connection and try again."
                        }"
                }

            } finally {

                if (
                    auth.currentUser?.uid == requestedUid &&
                    accountUid == requestedUid
                ) {

                    isSyncing = false
                }
            }
        }
    }


    // -----------------------------------------
    // CONFIRM LOCAL DATA OWNERSHIP
    // -----------------------------------------

    fun confirmLocalDataOwnership() {

        val requestedUid = accountUid

        if (requestedUid == null) {

            showOwnershipConfirmation = false

            syncMessage = "Please sign in before syncing."

            return
        }

        if (isSyncing) {
            return
        }

        if (auth.currentUser?.uid != requestedUid) {

            syncMessage =
                "Your account changed. Please sign in again."

            return
        }

        showOwnershipConfirmation = false

        isSyncing = true

        syncMessage =
            "Confirming local data ownership..."

        scope.launch {

            try {

                // Allow the loading state to render.
                delay(300L)

                if (
                    auth.currentUser?.uid != requestedUid ||
                    accountUid != requestedUid
                ) {
                    return@launch
                }

                val claimResult =
                    syncManager.claimLocalDataForCurrentUser()

                if (
                    auth.currentUser?.uid != requestedUid ||
                    accountUid != requestedUid
                ) {
                    return@launch
                }

                if (
                    claimResult.startsWith(
                        "Local data successfully associated",
                        ignoreCase = true
                    )
                ) {

                    syncMessage =
                        "Ownership confirmed. Synchronizing your data..."

                    val syncResult =
                        syncManager.sync()

                    if (
                        auth.currentUser?.uid != requestedUid ||
                        accountUid != requestedUid
                    ) {
                        return@launch
                    }

                    if (
                        syncResult.startsWith(
                            "Sync completed",
                            ignoreCase = true
                        )
                    ) {

                        syncMessage =
                            "Sync completed successfully."

                        refreshHomeData()

                        practiceResultsRefreshKey++
                        learningPlansRefreshKey++

                    } else if (
                        syncResult.startsWith(
                            "Sync requires confirmation",
                            ignoreCase = true
                        )
                    ) {

                        showOwnershipConfirmation = true

                        syncMessage =
                            "Additional local data ownership confirmation is required."

                    } else {

                        syncMessage = syncResult
                    }

                } else {

                    syncMessage = claimResult
                }

            } catch (e: Exception) {

                if (
                    auth.currentUser?.uid == requestedUid &&
                    accountUid == requestedUid
                ) {

                    syncMessage =
                        "Sync failed: ${
                            e.localizedMessage
                                ?: "Check your connection and try again."
                        }"
                }

            } finally {

                if (
                    auth.currentUser?.uid == requestedUid &&
                    accountUid == requestedUid
                ) {

                    isSyncing = false
                }
            }
        }
    }


    // -----------------------------------------
    // AUTOMATIC SYNC AFTER AUTHENTICATION
    // -----------------------------------------

    // This effect runs when the authenticated account changes
    // and also when the app initially opens with an active account.
    //
    // Manual synchronization does not use this effect anymore.
    // The Profile button calls startSync() directly.

    LaunchedEffect(accountUid) {

        val requestedUid = accountUid

        if (
            requestedUid != null &&
            auth.currentUser?.uid == requestedUid
        ) {
            startSync()
        }
    }


    // -----------------------------------------
    // AUTH SCREEN
    // -----------------------------------------

    if (!isAuthenticated) {

        AuthScreen(

            onAuthenticated = {

                accountUid = auth.currentUser?.uid

                currentScreen = "home"
                activeFocusScreen = false

                selectedLearningPlan = null
                selectedPracticeQuiz = null
                learningCoachProfile = null
                latestXpBreakdown = null

                syncMessage = null
                showOwnershipConfirmation = false
            }
        )

        return
    }


    // -----------------------------------------
    // PROFILE CHECK LOADING SCREEN
    // -----------------------------------------

    if (!profileCheckCompleted) {

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                CircularProgressIndicator()

                Text(
                    text = "Preparing your learning space...",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }

        return
    }


    // -----------------------------------------
    // COMPOSE NAVIGATION DRAWER
    // -----------------------------------------

    val drawerState = rememberDrawerState(
        initialValue = DrawerValue.Closed
    )

    fun openNavigationDrawer() {
        scope.launch {
            drawerState.open()
        }
    }


    // -----------------------------------------
    // ANDROID DEVICE BACK BUTTON
    // -----------------------------------------

    BackHandler(
        enabled = isAuthenticated &&
            currentScreen != "home" &&
            currentScreen != "onboarding"
    ) {

        when (currentScreen) {

            "learning_coach_dashboard" -> {
                currentScreen = learningCoachDashboardBackScreen
            }

            "learning_coach_setup" -> {
                currentScreen = learningCoachReturnScreen
            }

            "practice_quiz" -> {
                selectedPracticeQuiz = null
                currentScreen = "practice"
            }

            "practice_history",
            "ai_quiz_generator" -> {
                currentScreen = "practice"
            }

            "learning_plan_detail" -> {
                learningPlansRefreshKey++
                currentScreen = if (learningPlanDetailBackScreen == "learn") {
                    "activities"
                } else {
                    learningPlanDetailBackScreen
                }
            }

            "learning_plans" -> {
                currentScreen = if (learningPlansListBackScreen == "learn") {
                    "activities"
                } else {
                    learningPlansListBackScreen
                }
            }

            "subjects",
            "tasks",
            "focus" -> {

                activeFocusScreen = false

                currentScreen = "activities"

                refreshHomeData()
            }

            "resource_discovery",
            "resource_library" -> {
                currentScreen = "activities"
            }

            "wikipedia" -> {
                currentScreen = "ai_chat"
            }

            "practice" -> {
                currentScreen = "activities"
                refreshHomeData()
            }

            "progress",
            "profile",
            "ai_chat",
            "activities" -> {
                currentScreen = "home"
                refreshHomeData()
            }

            else -> {
                currentScreen = "home"
            }
        }
    }


    // -----------------------------------------
    // MAIN APPLICATION SCAFFOLD
    // -----------------------------------------

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 24.dp)
                ) {
                    Text(
                        text = "SCAI",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Student Companion AI",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                val drawerItems = listOf(
                    "Home" to "home",
                    "AI Chat" to "ai_chat",
                    "Activities" to "activities",
                    "Practice" to "practice",
                    "Progress" to "progress",
                    "Profile" to "profile"
                )

                drawerItems.forEach { (label, destination) ->
                    NavigationDrawerItem(
                        label = { Text(label) },
                        selected = currentScreen == destination,
                        onClick = {
                            scope.launch { drawerState.close() }
                            currentScreen = destination
                            if (destination == "home" || destination == "activities" || destination == "progress") {
                                refreshHomeData()
                            }
                        },
                        modifier = Modifier.padding(
                            androidx.compose.foundation.layout.PaddingValues(
                                horizontal = 12.dp,
                                vertical = 2.dp
                            )
                        )
                    )
                }
            }
        }
    ) {
        Scaffold { innerPadding ->

        // -----------------------------------------
        // MAIN CONTENT
        // -----------------------------------------

        Surface(

            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),

            color = MaterialTheme.colorScheme.background

        ) {

            Column(
                modifier = Modifier.fillMaxSize()
            ) {

                // Successful sync status is intentionally not displayed
                // above Profile & Settings. Sync state and error handling
                // remain available internally.

                Box(

                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)

                ) {

                    when (currentScreen) {

                        // =========================
                        // LEARNER ONBOARDING
                        // =========================

                        "onboarding" -> LearnerOnboardingHost(

                            storage = storage,

                            onSignOut = {

                                auth.signOut()

                                accountUid = null
                                currentScreen = "home"

                                activeFocusScreen = false

                                selectedLearningPlan = null
                                selectedPracticeQuiz = null

                                learningCoachProfile = null
                                latestXpBreakdown = null

                                syncMessage = null
                                showOwnershipConfirmation = false
                            },

                            onCompleted = {

                                currentScreen = "home"

                                profileCheckCompleted = true

                                refreshHomeData()

                                // Synchronize after onboarding is completed.
                                startSync()
                            }
                        )


                        // =========================
                        // HOME
                        // =========================

                        "home" -> HomeDashboardScreen(
                            focusSessions = focusSessions,
                            focusMinutes = focusMinutes,
                            totalTasks = totalTasks,
                            completedTasks = completedTasks,
                            subjectCount = subjectCount,
                            email = auth.currentUser?.email,
                            gamification = gamificationManager.getSnapshot(),
                            onTasksClick = { currentScreen = "tasks" },
                            onFocusClick = { currentScreen = "focus" },
                            onLearningCoachClick = {
                                learningCoachReturnScreen = "home"
                                currentScreen = "learning_coach_setup"
                            },
                            onAIChatClick = { currentScreen = "ai_chat" },
                            onProgressClick = {
                                currentScreen = "progress"
                                refreshHomeData()
                            },
                            onProfileClick = { currentScreen = "profile" },
                            activeFocus = HomeDashboardController.ActiveFocus(
                                isActive = activeFocus.isActive,
                                isPaused = activeFocus.isPaused,
                                remainingSeconds = activeFocus.remainingSeconds,
                                subjectName = activeFocus.subjectName,
                                taskTitle = activeFocus.taskTitle
                            ),
                            preferredName = storage.getLearnerProfile()?.preferredName,
                            photoUrl = auth.currentUser?.photoUrl?.toString(),
                            onMenuClick = { openNavigationDrawer() }
                        )


                        // =========================
                        // ACTIVITIES DASHBOARD
                        // =========================

                        "activities" -> ActivitiesDashboardScreen(
                            overview = ActivitiesDashboardController.Overview(
                                taskCount = totalTasks,
                                subjectCount = subjectCount,
                                focusMinutes = focusMinutes
                            ),
                            actions = ActivitiesDashboardController.Actions(
                                onSearchClick = {
                                    Toast.makeText(
                                        context,
                                        "Activity search is coming soon.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                onSettingsClick = { currentScreen = "profile" },
                                onFocusClick = { currentScreen = "focus" },
                                onSubjectsClick = { currentScreen = "subjects" },
                                onTestsClick = { currentScreen = "practice" },
                                onTasksClick = { currentScreen = "tasks" },
                                onScheduleClick = {
                                    Toast.makeText(
                                        context,
                                        "Study Schedule is coming soon.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                onRevisionClick = {
                                    Toast.makeText(
                                        context,
                                        "Revision is coming soon.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                onLearningPlansClick = {
                                    learningPlansListBackScreen = "activities"
                                    currentScreen = "learning_plans"
                                },
                                onResourceDiscoveryClick = {
                                    currentScreen = "resource_discovery"
                                },
                                onResourceLibraryClick = {
                                    currentScreen = "resource_library"
                                }
                            ),
                            activeFocus = activeFocus,
                            onMenuClick = { openNavigationDrawer() }
                        )


                        // =========================
                        // RESOURCE DISCOVERY
                        // =========================

                        "resource_discovery" -> ResourceDiscoveryScreen(
                            onBackClick = {
                                currentScreen = "activities"
                            }
                        )


                        // =========================
                        // RESOURCE LIBRARY
                        // =========================

                        "resource_library" -> ResourceLibraryScreen(
                            onBackClick = {
                                currentScreen = "activities"
                            },
                            refreshKey = dataVersion
                        )

                        // =========================
                        // LEARNING COACH SETUP
                        // =========================

                        "learning_coach_setup" ->

                            LearningCoachSetupScreen(

                                onBackClick = {
                                    currentScreen =
                                        learningCoachReturnScreen
                                },

                                onContinue = { profile ->

                                    learningCoachProfile = profile

                                    learningCoachDashboardBackScreen =
                                        "learning_coach_setup"

                                    currentScreen =
                                        "learning_coach_dashboard"
                                }
                            )


                        // =========================
                        // LEARNING COACH DASHBOARD
                        // =========================

                        "learning_coach_dashboard" -> {

                            val profile = learningCoachProfile

                            if (profile == null) {

                                currentScreen =
                                    "learning_coach_setup"

                            } else {

                                LearningCoachDashboardScreen(

                                    profile = profile,

                                    onBackClick = {
                                        currentScreen =
                                            learningCoachDashboardBackScreen
                                    },

                                    onPlanGenerated = { plan ->

                                        selectedLearningPlan = plan

                                        learningPlansRefreshKey++
                                        learningPlanDetailBackScreen =
                                            "learning_coach_dashboard"

                                        currentScreen =
                                            "learning_plan_detail"
                                    }
                                )
                            }
                        }


                        
// =========================
// PRACTICE
// =========================

"practice" -> PracticeScreen(

    onStartQuiz = { quiz ->

        selectedPracticeQuiz = quiz
        latestXpBreakdown = null

        currentScreen = "practice_quiz"
    },

    onHistoryClick = {

        practiceResultsRefreshKey++

        currentScreen = "practice_history"
    },

    onMenuClick = {
        openNavigationDrawer()
    },

    onAIQuizGeneratorClick = {

        currentScreen = "ai_quiz_generator"
    }
)



                 // ========================
// AI QUIZ GENERATOR
// ========================

"ai_quiz_generator" -> AIQuizGeneratorScreen(

    // Pass the current signed-in account's saved practice history.
    practiceHistory = practiceResults,

    onBackClick = {
        currentScreen = "practice"
    },

    onQuizGenerated = { quiz ->

        selectedPracticeQuiz = quiz
        latestXpBreakdown = null

        currentScreen = "practice_quiz"
    }
)


                        // =========================
                        // PRACTICE QUIZ
                        // =========================

                        "practice_quiz" -> {

                            val quiz = selectedPracticeQuiz

                            if (quiz == null) {

                                currentScreen = "practice"

                            } else {

                                PracticeQuizScreen(

                                    quiz = quiz,

                                    xpBreakdown = latestXpBreakdown,

                                    onBackClick = {

                                        selectedPracticeQuiz = null

                                        currentScreen = "practice"
                                    },

                                   
onQuizCompleted = { result ->

    val activeUid = accountUid

    if (
        activeUid != null &&
        auth.currentUser?.uid == activeUid
    ) {

        val storedResult = StoredPracticeResult(

            // The same ID identifies this attempt everywhere.
            id = result.attemptId,

            quizId = result.quizId,

            quizTitle = result.quizTitle,

            subject = result.subject,

            completedAt = result.completedAt,

            answers = result.answers,

            attemptId = result.attemptId
        )

        // Save the attempt to account-specific history.
        resultStorage.saveResult(storedResult)

        // Use the stable attempt ID for XP deduplication.
        latestXpBreakdown =
            gamificationManager.recordCompletedQuiz(

                eventId = "practice_attempt:${result.attemptId}",

                answers = result.answers
            )

        practiceResultsRefreshKey++
    }
}

                                )
                            }
                        }


                        // =========================
                        // PRACTICE HISTORY
                        // =========================

                        "practice_history" -> PracticeHistoryScreen(

                            results = practiceResults,

                            onBackClick = {
                                currentScreen = "practice"
                            },

                            onClearHistory = {

                                resultStorage.clearResults()

                                practiceResultsRefreshKey++
                            }
                        )


                        // =========================
                        // PROGRESS
                        // =========================

                        "progress" -> StatisticsScreen(

                            context = context,

                            onMenuClick = {
                                openNavigationDrawer()
                            }
                        )


                        // =========================
                        // PROFILE
                        // =========================

                        "profile" -> ProfileScreen(

                            email = auth.currentUser?.email
                                ?: "Signed in",

                            isSyncing = isSyncing,

                            isDarkTheme = isDarkTheme,

                            onThemeChange = onThemeChange,

                            // Directly start synchronization.
                            // No syncRequested state or extra effect relay.
                            onSyncClick = {
                                startSync()
                            },

                            onSignOutClick = {

                                auth.signOut()

                                accountUid = null

                                currentScreen = "home"
                                activeFocusScreen = false

                                selectedLearningPlan = null
                                selectedPracticeQuiz = null
                                learningCoachProfile = null
                                latestXpBreakdown = null

                                syncMessage = null
                                showOwnershipConfirmation = false

                                refreshHomeData()
                            },

                            onDeleteProfileClick = {
    showDeleteProfileConfirmation = true
},

onMenuClick = {
    openNavigationDrawer()
}
)


                        // =========================
                        // SUBJECTS
                        // =========================

                        "subjects" -> SubjectsScreen(

                            context = context,

                            onBackClick = {

                                refreshHomeData()
                                currentScreen = "activities"
                            },

                            onSubjectsChanged = { count ->

                                subjectCount = count
                                dataVersion++
                            },

                            refreshKey = dataVersion
                        )


                        // =========================
                        // TASKS
                        // =========================

                        "tasks" -> TasksScreen(

                            context = context,

                            onBackClick = {

                                refreshHomeData()
                                currentScreen = "activities"
                            },

                            onTasksChanged = { total, completed ->

                                totalTasks = total
                                completedTasks = completed

                                dataVersion++
                            },

                            refreshKey = dataVersion
                        )


                        // =========================
                        // FOCUS
                        // =========================

                        "focus" -> {

                            if (activeFocusScreen) {

                                ActiveFocusScreen(

                                    context = context,

                                    onBackClick = {
                                        activeFocusScreen = false
                                    },

                                    onSessionCompleted = { session ->

                                        val activeUid = accountUid

                                        if (
                                            activeUid != null &&
                                            auth.currentUser?.uid == activeUid
                                        ) {

                                            storage.saveFocusSession(session)

                                            refreshHomeData()

                                            activeFocusScreen = false

                                            currentScreen = "activities"

                                            // Synchronize after saving the session.
                                            startSync()
                                        }
                                    }
                                )

                            } else {

                                FocusScreen(

                                    context = context,

                                    onBackClick = {
                                        currentScreen = "activities"
                                    },

                                    onStartActiveFocus = {
                                        activeFocusScreen = true
                                    },

                                    onSessionCompleted = { session ->

                                        val activeUid = accountUid

                                        if (
                                            activeUid != null &&
                                            auth.currentUser?.uid == activeUid
                                        ) {

                                            storage.saveFocusSession(session)

                                            refreshHomeData()

                                            startSync()
                                        }
                                    }
                                )
                            }
                        }


                        // =========================
                        // AI CHAT
                        // =========================

                        "ai_chat" -> AIChatScreen(

                            onMenuClick = {
                                openNavigationDrawer()
                            },

                            onWikipediaClick = {
                                currentScreen = "wikipedia"
                            },

                            onPlanGenerated = { plan ->

                                selectedLearningPlan = plan

                                learningPlansRefreshKey++
                                learningPlanDetailBackScreen = "ai_chat"

                                currentScreen = "learning_plan_detail"
                            }
                        )


                        // =========================
                        // WIKIPEDIA
                        // =========================

                        "wikipedia" -> WikipediaSearchScreen(

                            onBackClick = {
                                currentScreen = "ai_chat"
                            }
                        )


                        // =========================
                        // SAVED LEARNING PLANS
                        // =========================

                        "learning_plans" -> SavedLearningPlansScreen(

                            onBackClick = {
                                currentScreen = learningPlansListBackScreen
                            },

                            onOpenPlan = { plan ->

                                selectedLearningPlan = plan
                                learningPlanDetailBackScreen = "learning_plans"

                                currentScreen =
                                    "learning_plan_detail"
                            },

                            refreshKey = learningPlansRefreshKey
                        )


                        // =========================
                        // LEARNING PLAN DETAILS
                        // =========================

                        "learning_plan_detail" -> {

                            val plan = selectedLearningPlan

                            if (plan == null) {

                                currentScreen = learningPlansListBackScreen

                            } else {

                                LearningPlanDetailScreen(

                                    plan = plan,

                                    onBackClick = {

                                        learningPlansRefreshKey++

                                        currentScreen =
                                            learningPlanDetailBackScreen
                                    },

                                    onPlanUpdated = { updatedPlan ->

                                        selectedLearningPlan = updatedPlan

                                        learningPlansRefreshKey++
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
        }
    }


    // -----------------------------------------
    // LOCAL DATA OWNERSHIP CONFIRMATION DIALOG
    // -----------------------------------------

    if (showOwnershipConfirmation) {

        AlertDialog(

            onDismissRequest = {
                showOwnershipConfirmation = false
            },

            title = {
                Text("Confirm local data ownership")
            },

            text = {
                Text(
                    "Existing subjects, tasks, or focus records were found " +
                        "on this device, but they are not associated with a " +
                        "recorded account owner.\n\n" +
                        "If this is your data, confirm to associate it with " +
                        "the currently signed-in account and synchronize it " +
                        "with your cloud account.\n\n" +
                        "Only continue if you recognize and own this local data."
                )
            },

            confirmButton = {

                TextButton(
                    onClick = {
                        confirmLocalDataOwnership()
                    }
                ) {
                    Text("Confirm and sync")
                }
            },

            dismissButton = {

                TextButton(
                    onClick = {
                        showOwnershipConfirmation = false

                        syncMessage =
                            "Sync cancelled. Your local data remains unchanged."
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }


    // -----------------------------------------
    // DELETE LEARNER PROFILE CONFIRMATION
    // -----------------------------------------

    if (showDeleteProfileConfirmation) {

        AlertDialog(

            onDismissRequest = {
                showDeleteProfileConfirmation = false
            },

            title = {
                Text("Delete learner profile?")
            },

            text = {
                Text(
                    "This will delete your onboarding profile and " +
                        "return you to the Get Started screen.\n\n" +

                        "You can create a new profile afterward.\n\n" +

                        "Your Firebase account, subjects, tasks, focus " +
                        "history, practice history and learning plans " +
                        "will remain unchanged.\n\n" +

                        "This action cannot be undone."
                )
            },

            confirmButton = {

                TextButton(

                    onClick = {

                        try {

                            storage.clearLearnerProfile()

                            if (storage.isProfileCompleted()) {

                                throw IllegalStateException(
                                    "Profile deletion could not be verified."
                                )
                            }

                            learningCoachProfile = null

                            selectedLearningPlan = null
                            selectedPracticeQuiz = null
                            latestXpBreakdown = null

                            showDeleteProfileConfirmation = false

                            profileCheckCompleted = true
                            currentScreen = "onboarding"

                            Toast.makeText(
                                context,
                                "Learner profile deleted. Create a new profile.",
                                Toast.LENGTH_LONG
                            ).show()

                        } catch (e: Exception) {

                            showDeleteProfileConfirmation = false

                            Toast.makeText(
                                context,
                                "Could not delete profile: ${
                                    e.localizedMessage ?: "Unknown error"
                                }",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }

                ) {

                    Text(
                        text = "Delete profile",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },

            dismissButton = {

                TextButton(
                    onClick = {
                        showDeleteProfileConfirmation = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}