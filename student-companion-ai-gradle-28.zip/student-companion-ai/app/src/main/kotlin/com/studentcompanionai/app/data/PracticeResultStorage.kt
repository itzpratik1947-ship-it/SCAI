
package com.studentcompanionai.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class PracticeResultStorage(
    context: Context,
    uid: String? = null
) {

    private val accountUid = uid?.trim()?.also {
        require(it.isNotBlank()) {
            "Firebase UID cannot be blank."
        }
    }

    private val preferences = context.applicationContext
        .getSharedPreferences(
            if (accountUid == null) {
                LEGACY_PREFERENCES_NAME
            } else {
                ACCOUNT_PREFERENCES_PREFIX + accountUid
            },
            Context.MODE_PRIVATE
        )

    companion object {
        private const val LEGACY_PREFERENCES_NAME =
            "student_companion_data"

        private const val ACCOUNT_PREFERENCES_PREFIX =
            "student_companion_data_"

        private const val KEY_PRACTICE_RESULTS =
            "practice_quiz_results"
    }

    @Synchronized
    fun saveResult(result: StoredPracticeResult) {
        val results = loadResults().toMutableList()

        results.removeAll { it.id == result.id }
        results.add(result)

        val jsonArray = JSONArray()

        results.sortedByDescending { it.completedAt }
            .forEach { jsonArray.put(it.toJson()) }

        preferences.edit()
            .putString(KEY_PRACTICE_RESULTS, jsonArray.toString())
            .apply()
    }

    @Synchronized
    fun loadResults(): List<StoredPracticeResult> {
        val raw = preferences.getString(
            KEY_PRACTICE_RESULTS,
            null
        ) ?: return emptyList()

        return try {
            val jsonArray = JSONArray(raw)
            val results = mutableListOf<StoredPracticeResult>()

            for (index in 0 until jsonArray.length()) {
                val item = jsonArray.optJSONObject(index) ?: continue
                val parsed = item.toStoredResultOrNull()

                if (parsed != null) {
                    results.add(parsed)
                }
            }

            results.sortedByDescending { it.completedAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun deleteResult(resultId: String) {
        val remaining = loadResults().filterNot {
            it.id == resultId
        }

        val jsonArray = JSONArray()

        remaining.forEach {
            jsonArray.put(it.toJson())
        }

        preferences.edit()
            .putString(KEY_PRACTICE_RESULTS, jsonArray.toString())
            .apply()
    }

    @Synchronized
    fun clearResults() {
        preferences.edit()
            .remove(KEY_PRACTICE_RESULTS)
            .apply()
    }

    private fun StoredPracticeResult.toJson(): JSONObject {
        val answersArray = JSONArray()

        answers.forEach { answer ->
            answersArray.put(
                JSONObject().apply {
                    put("questionId", answer.questionId)
                    put(
                        "selectedAnswerIndex",
                        answer.selectedAnswerIndex
                    )
                    put("isCorrect", answer.isCorrect)
                    put("topic", answer.topic)
                    put("difficulty", answer.difficulty)
                    put("questionType", answer.questionType.name)
                    put("writtenAnswer", answer.writtenAnswer)
                    put("expectedAnswer", answer.expectedAnswer)
                    put("evaluationFeedback", answer.evaluationFeedback)
                    put("isEvaluated", answer.isEvaluated)
                }
            )
        }

        return JSONObject().apply {
            put("id", id)
            put("attemptId", attemptId)
            put("quizId", quizId)
            put("quizTitle", quizTitle)
            put("subject", subject)
            put("completedAt", completedAt)
            put("answers", answersArray)
        }
    }

    private fun JSONObject.toStoredResultOrNull():
        StoredPracticeResult? {

        return try {
            val id = optString("id")
            val quizId = optString("quizId")
            val quizTitle = optString("quizTitle")

            if (
                id.isBlank() ||
                quizId.isBlank() ||
                quizTitle.isBlank()
            ) {
                return null
            }

            // Older records do not have attemptId.
            // Their existing result ID becomes the fallback.
            val attemptId = optString(
                "attemptId",
                id
            ).ifBlank {
                id
            }

            val answersArray = optJSONArray("answers") ?: JSONArray()
            val answers = mutableListOf<PracticeAnswer>()

            for (index in 0 until answersArray.length()) {
                val item = answersArray.optJSONObject(index) ?: continue
                val questionId = item.optString("questionId")

                if (questionId.isBlank()) {
                    continue
                }

                val questionType = try {
                    PracticeQuestionType.valueOf(
                        item.optString("questionType", "MCQ")
                            .uppercase()
                    )
                } catch (_: IllegalArgumentException) {
                    PracticeQuestionType.MCQ
                }

                answers.add(
                    PracticeAnswer(
                        questionId = questionId,
                        selectedAnswerIndex = item.optInt(
                            "selectedAnswerIndex",
                            -1
                        ),
                        isCorrect = item.optBoolean(
                            "isCorrect",
                            false
                        ),
                        topic = item.optString("topic", ""),
                        difficulty = item.optString(
                            "difficulty",
                            "UNKNOWN"
                        ),
                        questionType = questionType,
                        writtenAnswer = item.optString(
                            "writtenAnswer",
                            ""
                        ),
                        expectedAnswer = item.optString(
                            "expectedAnswer",
                            ""
                        ),
                        evaluationFeedback = item.optString(
                            "evaluationFeedback",
                            ""
                        ),
                        isEvaluated = item.optBoolean(
                            "isEvaluated",
                            true
                        )
                    )
                )
            }

            StoredPracticeResult(
                id = id,
                quizId = quizId,
                quizTitle = quizTitle,
                subject = optString("subject"),
                completedAt = optLong("completedAt", 0L),
                answers = answers,
                attemptId = attemptId
            )
        } catch (_: Exception) {
            null
        }
    }
}

data class StoredPracticeResult(
    val id: String,
    val quizId: String,
    val quizTitle: String,
    val subject: String,
    val completedAt: Long,
    val answers: List<PracticeAnswer>,
    val attemptId: String = id
) {

    val totalQuestions: Int
        get() = answers.size

    val evaluatedAnswers: Int
        get() = answers.count { it.isEvaluated }

    val correctAnswers: Int
        get() = answers.count {
            it.isEvaluated && it.isCorrect
        }

    val incorrectAnswers: Int
        get() = answers.count {
            it.isEvaluated && !it.isCorrect
        }

    val pendingEvaluationAnswers: Int
        get() = answers.count { !it.isEvaluated }

    val scorePercent: Int
        get() = if (evaluatedAnswers == 0) {
            0
        } else {
            (correctAnswers * 100) / evaluatedAnswers
        }
}
