
package com.studentcompanionai.app.data

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

object DailyTaskScheduler {

    private const val DAILY_INTERVAL_HOURS = 24L

    private const val IMMEDIATE_WORK_SUFFIX = "_immediate"

    /**
     * Schedules daily background maintenance for one account.
     *
     * Also requests an immediate reconciliation so tasks are not
     * dependent on waiting until the next midnight.
     */
    fun schedule(
        context: Context,
        uid: String
    ) {

        if (uid.isBlank()) return

        val workManager = WorkManager.getInstance(
            context.applicationContext
        )

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
            .build()

        val periodicRequest =
            PeriodicWorkRequestBuilder<DailyTaskWorker>(
                DAILY_INTERVAL_HOURS,
                TimeUnit.HOURS
            )
                .setInitialDelay(
                    calculateDelayUntilNextMidnight(),
                    TimeUnit.MILLISECONDS
                )
                .setInputData(
                    DailyTaskWorker.createInputData(uid)
                )
                .setConstraints(constraints)
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    30,
                    TimeUnit.SECONDS
                )
                .build()

        val periodicWorkName = dailyWorkName(uid)

        workManager.enqueueUniquePeriodicWork(
            periodicWorkName,
            ExistingPeriodicWorkPolicy.UPDATE,
            periodicRequest
        )

        enqueueImmediateReconciliation(
            context = context,
            uid = uid
        )
    }

    /**
     * Runs task reconciliation once immediately.
     */
    fun enqueueImmediateReconciliation(
        context: Context,
        uid: String
    ) {

        if (uid.isBlank()) return

        val request =
            OneTimeWorkRequestBuilder<DailyTaskWorker>()
                .setInputData(
                    DailyTaskWorker.createInputData(uid)
                )
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    30,
                    TimeUnit.SECONDS
                )
                .build()

        WorkManager.getInstance(
            context.applicationContext
        ).enqueueUniqueWork(
            dailyWorkName(uid) + IMMEDIATE_WORK_SUFFIX,
            ExistingWorkPolicy.KEEP,
            request
        )
    }

    /**
     * Cancels all scheduled task maintenance for an account.
     */
    fun cancel(
        context: Context,
        uid: String
    ) {

        if (uid.isBlank()) return

        val workManager = WorkManager.getInstance(
            context.applicationContext
        )

        workManager.cancelUniqueWork(
            dailyWorkName(uid)
        )

        workManager.cancelUniqueWork(
            dailyWorkName(uid) + IMMEDIATE_WORK_SUFFIX
        )
    }

    private fun dailyWorkName(uid: String): String {
        return "daily_task_maintenance_$uid"
    }

    /**
     * Calculates the delay until the next local midnight.
     *
     * WorkManager may execute later because Android controls
     * background scheduling and battery optimization.
     */
    private fun calculateDelayUntilNextMidnight(): Long {

        val now = Calendar.getInstance()

        val nextMidnight = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)

            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        return (nextMidnight.timeInMillis - now.timeInMillis)
            .coerceAtLeast(1L)
    }
}
