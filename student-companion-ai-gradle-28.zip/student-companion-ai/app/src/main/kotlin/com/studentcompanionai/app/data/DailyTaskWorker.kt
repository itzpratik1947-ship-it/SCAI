
package com.studentcompanionai.app.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.WorkerParameters

class DailyTaskWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {

        val uid = inputData.getString(KEY_ACCOUNT_UID)
            ?: return Result.failure()

        if (uid.isBlank()) {
            return Result.failure()
        }

        return try {
            // Task notification functionality has been removed.
            // Keep the worker interface and account validation intact.
            Result.success()
        } catch (exception: Exception) {
            Result.retry()
        }
    }

    companion object {

        const val KEY_ACCOUNT_UID = "account_uid"

        fun createInputData(uid: String): Data {
            require(uid.isNotBlank()) {
                "Account UID cannot be blank."
            }

            return Data.Builder()
                .putString(KEY_ACCOUNT_UID, uid)
                .build()
        }
    }
}
