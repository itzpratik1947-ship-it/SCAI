
package com.studentcompanionai.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.ResourceStorage
import com.studentcompanionai.app.data.SavedResource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private enum class ResourceLibraryTab {
    SAVED,
    RECENT
}

@Composable
fun ResourceLibraryScreen(
    onBackClick: () -> Unit = {},
    refreshKey: Int = 0
) {
    val context = LocalContext.current
    val uid = FirebaseAuth.getInstance().currentUser?.uid
    val scope = rememberCoroutineScope()

    val storage = remember(uid) {
        uid?.let { ResourceStorage(it) }
    }

    var selectedTab by remember {
        mutableStateOf(ResourceLibraryTab.SAVED)
    }

    var savedResources by remember(uid) {
        mutableStateOf<List<SavedResource>>(emptyList())
    }

    var recentResources by remember(uid) {
        mutableStateOf<List<SavedResource>>(emptyList())
    }

    var isLoading by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    var showClearHistoryDialog by remember {
        mutableStateOf(false)
    }

    var isClearingHistory by remember {
        mutableStateOf(false)
    }

    fun loadResources() {
        val currentStorage = storage ?: return
        if (isLoading) return

        isLoading = true
        errorMessage = null

        scope.launch {
            try {
                val saved = currentStorage.getSavedResources()
                val recent = currentStorage.getRecentlyOpenedResources()

                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                    savedResources = saved
                    recentResources = recent
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                errorMessage = e.localizedMessage
                    ?: "Unable to load your resource library."
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(uid, refreshKey) {
        savedResources = emptyList()
        recentResources = emptyList()

        if (uid != null) {
            loadResources()
        }
    }

    fun openResource(item: SavedResource) {
        val resource = item.resource

        if (!resource.hasValidUrl) {
            errorMessage = "This resource has an invalid link."
            return
        }

        scope.launch {
            try {
                storage?.recordResourceOpened(resource)
            } catch (_: Exception) {
                // Opening must remain possible if history storage fails.
            }

            try {
                context.startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(resource.url)
                    )
                )
            } catch (_: Exception) {
                errorMessage = "Unable to open this resource."
            }
        }
    }

    fun removeBookmark(resourceId: String) {
        val currentStorage = storage ?: return

        scope.launch {
            try {
                currentStorage.removeResource(resourceId)
                savedResources = savedResources.filter {
                    it.resource.id != resourceId
                }
            } catch (e: Exception) {
                errorMessage = e.localizedMessage
                    ?: "Unable to remove saved resource."
            }
        }
    }

    fun clearHistory() {
        val currentStorage = storage ?: return

        isClearingHistory = true

        scope.launch {
            try {
                currentStorage.clearBrowsingHistory()
                recentResources = emptyList()
                showClearHistoryDialog = false
            } catch (e: Exception) {
                errorMessage = e.localizedMessage
                    ?: "Unable to clear browsing history."
            } finally {
                isClearingHistory = false
            }
        }
    }

    val visibleResources = when (selectedTab) {
        ResourceLibraryTab.SAVED -> savedResources
        ResourceLibraryTab.RECENT -> recentResources
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            Text(
                text = "Resource Library",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(5.dp))

            Text(
                text = "Your saved learning materials and recently opened resources.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        selectedTab = ResourceLibraryTab.SAVED
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Saved (${savedResources.size})")
                }

                OutlinedButton(
                    onClick = {
                        selectedTab = ResourceLibraryTab.RECENT
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Recently Opened")
                }
            }

            if (selectedTab == ResourceLibraryTab.RECENT &&
                recentResources.isNotEmpty()
            ) {
                Spacer(Modifier.height(8.dp))

                OutlinedButton(
                    onClick = { showClearHistoryDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isClearingHistory
                ) {
                    Text(
                        if (isClearingHistory) "Clearing..."
                        else "Clear Browsing History"
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            if (errorMessage != null) {
                Text(
                    text = errorMessage!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )

                TextButton(onClick = { loadResources() }) {
                    Text("Retry")
                }
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (visibleResources.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (selectedTab) {
                            ResourceLibraryTab.SAVED ->
                                "No saved resources yet.\nSave useful resources while exploring."

                            ResourceLibraryTab.RECENT ->
                                "No recently opened resources."
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(
                        items = visibleResources,
                        key = { it.resource.id }
                    ) { item ->

                        ResourceLibraryCard(
                            item = item,
                            isSaved = selectedTab == ResourceLibraryTab.SAVED,
                            onOpen = { openResource(item) },
                            onRemove = {
                                removeBookmark(item.resource.id)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isClearingHistory) {
                    showClearHistoryDialog = false
                }
            },
            title = {
                Text("Clear browsing history?")
            },
            text = {
                Text(
                    "This will remove your recently opened resource history. Saved bookmarks will remain untouched."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { clearHistory() },
                    enabled = !isClearingHistory
                ) {
                    Text(
                        if (isClearingHistory) "Clearing..."
                        else "Clear"
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showClearHistoryDialog = false
                    },
                    enabled = !isClearingHistory
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ResourceLibraryCard(
    item: SavedResource,
    isSaved: Boolean,
    onOpen: () -> Unit,
    onRemove: () -> Unit
) {
    val resource = item.resource

    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Text(
                text = when (resource.type.name) {
                    "VIDEO" -> "VIDEO"
                    "ARTICLE" -> "ARTICLE"
                    "DOCUMENTATION" -> "DOCUMENTATION"
                    else -> "WEBSITE"
                },
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(5.dp))

            Text(
                text = resource.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (resource.description.isNotBlank()) {
                Spacer(Modifier.height(5.dp))

                Text(
                    text = resource.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(6.dp))

            Text(
                text = buildString {
                    append(resource.provider.ifBlank { "Resource" })

                    if (resource.author.isNotBlank()) {
                        append(" • ")
                        append(resource.author)
                    }
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (item.openCount > 0) {
                Text(
                    text = "Opened ${item.openCount} times",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpen,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Open")
                }

                if (isSaved) {
                    OutlinedButton(onClick = onRemove) {
                        Text("Remove")
                    }
                }
            }
        }
    }
}
