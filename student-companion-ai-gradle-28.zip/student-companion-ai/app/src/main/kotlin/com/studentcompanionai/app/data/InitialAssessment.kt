
package com.studentcompanionai.app.data

/**
 * Types of questions supported by the initial knowledge assessment.
 */
enum class AssessmentQuestionType {
    MCQ,
    SHORT_ANSWER,
    PROBLEM_SOLVING
}

/**
 * Difficulty assigned to an assessment question.
 */
enum class AssessmentDifficulty {
    EASY,
    MEDIUM,
    HARD
}

/**
 * A diagnostic question generated for a learner.
 *
 * Correct answers and evaluation criteria are retained separately
 * from the learner-facing question content.
 */
data class InitialAssessmentQuestion(
    val id: String,
    val question: String,
    val type: AssessmentQuestionType,
    val topic: String,
    val difficulty: AssessmentDifficulty,
    val options: List<String> = emptyList(),
    val correctAnswer: String = "",
    val explanation: String = "",
    val evaluationCriteria: List<String> = emptyList(),
    val maximumMarks: Int = 1
) {
    init {
        require(id.isNotBlank()) {
            "Question ID cannot be empty."
        }

        require(question.isNotBlank()) {
            "Question cannot be empty."
        }

        require(topic.isNotBlank()) {
            "Question topic cannot be empty."
        }

        require(maximumMarks > 0) {
            "Maximum marks must be greater than zero."
        }

        if (type == AssessmentQuestionType.MCQ) {
            require(options.size >= 2) {
                "MCQ questions must have at least two options."
            }

            require(correctAnswer.toIntOrNull() in options.indices) {
                "MCQ correct answer must be a valid option index."
            }
        }
    }
}

/**
 * Learner's response to an assessment question.
 */
data class InitialAssessmentResponse(
    val questionId: String,
    val selectedOptionIndex: Int? = null,
    val writtenAnswer: String = "",
    val submittedAt: Long = System.currentTimeMillis()
)

/**
 * Evaluation of an individual learner response.
 *
 * AI-generated evaluations must be treated as estimates,
 * not as unquestionable ground truth.
 */
data class AssessmentAnswerEvaluation(
    val questionId: String,
    val awardedMarks: Double,
    val maximumMarks: Int,
    val isCorrect: Boolean,
    val feedback: String,
    val evaluationBasis: String
) {
    init {
        require(awardedMarks >= 0.0) {
            "Awarded marks cannot be negative."
        }

        require(maximumMarks > 0) {
            "Maximum marks must be greater than zero."
        }

        require(awardedMarks <= maximumMarks) {
            "Awarded marks cannot exceed maximum marks."
        }
    }
}

/**
 * Topic-wise knowledge measurement.
 */
data class TopicKnowledgeResult(
    val topic: String,
    val totalQuestions: Int,
    val correctAnswers: Int,
    val scorePercent: Int,
    val knowledgeLevel: String,
    val identifiedStrengths: List<String> = emptyList(),
    val identifiedWeaknesses: List<String> = emptyList()
)

/**
 * Complete initial assessment result.
 */
data class InitialAssessmentResult(
    val id: String,
    val profileSubject: String,
    val completedAt: Long = System.currentTimeMillis(),
    val totalQuestions: Int,
    val totalMarks: Double,
    val awardedMarks: Double,
    val overallScorePercent: Int,
    val responses: List<InitialAssessmentResponse>,
    val evaluations: List<AssessmentAnswerEvaluation>,
    val topicResults: List<TopicKnowledgeResult>
) {
    init {
        require(id.isNotBlank()) {
            "Assessment ID cannot be empty."
        }

        require(totalQuestions >= 0) {
            "Total questions cannot be negative."
        }

        require(totalMarks >= 0.0) {
            "Total marks cannot be negative."
        }

        require(awardedMarks in 0.0..totalMarks) {
            "Awarded marks must be within the total marks."
        }

        require(overallScorePercent in 0..100) {
            "Overall score must be between 0 and 100."
        }
    }
}
