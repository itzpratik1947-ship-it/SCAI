
package com.studentcompanionai.app.data

import org.json.JSONException
import org.json.JSONObject
import java.util.UUID

class AIQuizGenerator {

    suspend fun generateQuiz(
        subject: String,
        topic: String,
        difficulty: String,
        questionCount: Int,
        questionFormat: String = MCQ_ONLY,
        practiceHistory: List<StoredPracticeResult> = emptyList(),
        adaptiveMode: Boolean = false
    ): PracticeQuiz {

        require(subject.isNotBlank()) {
            "Please select a subject."
        }

        require(topic.isNotBlank()) {
            "Please enter a topic."
        }

        require(questionCount in listOf(5, 10, 15, 20)) {
            "Unsupported number of questions."
        }

        val normalizedSubject = subject.trim()
        val normalizedTopic = topic.trim()

        val requestedDifficulty = difficulty
            .trim()
            .uppercase()
            .also {
                require(it in SUPPORTED_DIFFICULTIES) {
                    "Unsupported difficulty. Please select Easy, Medium, or Hard."
                }
            }

        val normalizedFormat = normalizeQuestionFormat(questionFormat)

        /*
         * Analyze only the selected subject.
         *
         * This prevents performance in Mathematics, for example,
         * from influencing a Programming quiz.
         */
        val performanceAnalysis = if (adaptiveMode) {
            PracticePerformanceAnalyzer.analyze(
                results = practiceHistory,
                subject = normalizedSubject
            )
        } else {
            null
        }

        val topicInsight = if (adaptiveMode) {
            PracticePerformanceAnalyzer.getTopicInsight(
                results = practiceHistory,
                subject = normalizedSubject,
                topic = normalizedTopic
            )
        } else {
            null
        }

        /*
         * Manual difficulty remains the default.
         *
         * Adaptive difficulty is used only when the analyzer
         * has sufficient evidence for the selected topic.
         */
        val normalizedDifficulty = if (
            adaptiveMode &&
            topicInsight != null &&
            topicInsight.isSufficientlyAnalyzed
        ) {
            topicInsight.recommendedDifficulty.name
        } else {
            requestedDifficulty
        }

        val adaptiveContext = if (
            adaptiveMode &&
            performanceAnalysis != null
        ) {
            buildAdaptiveContext(
                analysis = performanceAnalysis,
                selectedTopic = normalizedTopic,
                topicInsight = topicInsight
            )
        } else {
            """
                ADAPTIVE MODE: DISABLED

                Generate the quiz using the learner's manually selected
                subject, topic and difficulty.
            """.trimIndent()
        }

        val formatInstructions = when (normalizedFormat) {

            MCQ_ONLY -> """
                Generate MCQ questions only.

                Every question must have:
                - type: "MCQ"
                - Exactly four distinct options.
                - correctAnswerIndex from 0 to 3.
                - A clear explanation.

                Do not generate written-answer questions.
            """.trimIndent()

            MCQ_AND_SHORT_ANSWER -> """
                Generate a combination of MCQ and short-answer questions.
                Include both question types.
                Distribute the questions as evenly as possible.

                MCQ questions must have:
                - type: "MCQ"
                - Exactly four distinct options.
                - correctAnswerIndex from 0 to 3.

                Short-answer questions must have:
                - type: "SHORT_ANSWER"
                - An empty options array.
                - correctAnswerIndex: -1.
                - A detailed expectedAnswer.
                - Clear, question-aligned evaluationCriteria.

                Do not generate problem-solving questions.
            """.trimIndent()

            SHORT_ANSWER_ONLY -> """
                Generate short-answer questions only.

                Every question must have:
                - type: "SHORT_ANSWER"
                - An empty options array.
                - correctAnswerIndex: -1.
                - A detailed expectedAnswer.
                - Clear, question-aligned evaluationCriteria.

                Do not generate MCQ or problem-solving questions.
            """.trimIndent()

            MIXED_ASSESSMENT -> """
                Generate a mixed assessment containing all three question types:
                1. MCQ
                2. SHORT_ANSWER
                3. PROBLEM_SOLVING

                Include at least one question of each type.
                Distribute the remaining questions as evenly as possible.

                MCQ questions must have:
                - Exactly four distinct options.
                - correctAnswerIndex from 0 to 3.

                SHORT_ANSWER questions must have:
                - An empty options array.
                - correctAnswerIndex: -1.
                - A detailed expectedAnswer.
                - Clear, question-aligned evaluationCriteria.

                PROBLEM_SOLVING questions must have:
                - A meaningful problem.
                - An empty options array.
                - correctAnswerIndex: -1.
                - An accurate expectedAnswer.
                - Clear, question-aligned evaluationCriteria.
            """.trimIndent()

            else -> throw IllegalArgumentException(
                "Unsupported question format."
            )
        }

        val prompt = """
            You are a professional educational assessment designer
            working inside a personalized adaptive learning system.

            Generate exactly $questionCount educational questions.

            SUBJECT: $normalizedSubject
            TOPIC: $normalizedTopic
            DIFFICULTY: $normalizedDifficulty
            QUESTION FORMAT: $normalizedFormat

            $adaptiveContext

            DIFFICULTY GUIDELINES:

            - EASY: Test basic understanding, definitions, and direct applications.
            - MEDIUM: Test conceptual understanding and practical application.
            - HARD: Test advanced reasoning, complex applications, and deeper concepts.
            - Every question must match the requested difficulty.
            - Do not mix different difficulty levels.

            ADAPTIVE LEARNING REQUIREMENTS:

            If adaptive mode is enabled:

            1. Prioritize the selected topic's identified learning weaknesses.

            2. Generate questions that help the learner understand concepts
               they previously answered incorrectly.

            3. If recent performance has declined, reinforce foundational
               concepts before introducing advanced applications.

            4. If performance is improving, gradually challenge the learner
               while maintaining the selected difficulty.

            5. If the topic has insufficient historical data, generate a
               balanced assessment rather than assuming the learner is weak.

            6. Do not repeatedly generate the same question or simply
               rephrase a previous question.

            7. Do not assume that an incorrect answer proves the learner
               does not understand the entire topic.

            8. Every question must remain educationally relevant to
               the selected subject and topic.

            QUESTION FORMAT REQUIREMENTS:

            $formatInstructions

            CRITICAL: QUESTION AND EVALUATION ALIGNMENT

            The question, expectedAnswer, evaluationCriteria and explanation
            must all agree with each other.

            Follow these rules strictly:

            1. Ask exactly what you intend to evaluate.

            2. Never require information that the question does not ask for,
               unless that information is essential to make the answer correct.

            3. If a question asks for a direct answer, accept a correct direct
               answer. Do not require an explanation, derivation or working steps.

            4. If a question asks for the exact output of a program, evaluate
               whether the output is correct. Do not require the learner to
               explain how the program produces that output.

            5. If a question asks the learner to identify errors, evaluate
               whether the identified errors are genuinely present.

            6. If a question asks the learner to correct code, evaluate the
               corrected code for actual syntax and logical correctness.
               Do not demand an explanation unless explicitly requested.

            7. If a question explicitly asks for an explanation, reasoning,
               derivation or working steps, evaluate those requirements.

            8. For mathematical and programming questions, distinguish
               between the correctness of the final result and the
               explanation of the method.

            9. Do not make optional details mandatory evaluation requirements.

            10. Do not penalize concise answers simply because a longer
                explanation could also be provided.

            11. Accept technically correct alternative methods, valid
                equivalent expressions and different wording.

            12. Never introduce additional requirements into evaluationCriteria
                that are absent from the question.

            EXPECTED ANSWER REQUIREMENTS:

            - Directly answer the question.
            - Be technically and factually correct.
            - Include alternative valid answers where appropriate.
            - For code correction questions, provide a complete corrected
              code solution.
            - For output questions, explicitly state the expected output.
            - For problem-solving questions, provide the solution and
              reasoning when the question requires reasoning.

            EVALUATION CRITERIA REQUIREMENTS:

            Write evaluationCriteria as a concise, objective grading rubric.

            It must explicitly identify:

            A. What is essential for the answer to be considered correct.
            B. What alternative answers or equivalent wording are acceptable.
            C. What mistakes would make the answer incorrect.
            D. Whether explanation or working steps are actually required.

            If explanation is not requested, explicitly state:
            "A correct direct answer is sufficient. Explanation is not required."

            Do not create arbitrary mandatory requirements.

            EXAMPLES OF CORRECT EVALUATION DESIGN:

            Example 1:

            Question:
            "Determine the exact output of 10 / 3 in C when both operands
            are integers."

            Expected answer:
            "3"

            Evaluation criteria:
            "The answer must be 3. A direct answer of 3 is fully correct.
            Explanation of integer division is not required."

            Example 2:

            Question:
            "Explain why 10 / 3 produces 3 in C when both operands are integers."

            Expected answer:
            "Integer division discards the fractional part, so the result is 3."

            Evaluation criteria:
            "The answer must identify integer division and explain that
            the fractional part is discarded. Merely writing 3 is
            incomplete because the question explicitly requests an explanation."

            Example 3:

            Question:
            "Identify the syntax errors in the following C program."

            Evaluation criteria:
            "Identify the actual syntax errors present in the supplied code.
            Do not require a complete rewritten program or unrelated
            programming explanations unless explicitly requested."

            IMPORTANT:
            These examples demonstrate evaluation alignment.
            Generate original questions for the requested topic.

            REQUIREMENTS FOR ALL QUESTIONS:

            1. Generate exactly $questionCount questions.
            2. Every question must relate directly to the specified topic.
            3. Avoid duplicate or repetitive questions.
            4. Avoid ambiguous or misleading questions.
            5. Include a clear explanation for every question.
            6. Include a short topic label for every question.
            7. Return the correct type for every question.
            8. Ensure expected answers are accurate.
            9. Ensure evaluation criteria do not contradict the question.
            10. Do not add Markdown, code fences, introductions,
                conclusions or text outside the JSON.

            RETURN ONE VALID JSON OBJECT ONLY:

            {
              "questions": [
                {
                  "type": "MCQ",
                  "question": "Question text",
                  "options": [
                    "Option A",
                    "Option B",
                    "Option C",
                    "Option D"
                  ],
                  "correctAnswerIndex": 0,
                  "expectedAnswer": "",
                  "evaluationCriteria": "",
                  "explanation": "Explanation",
                  "topic": "Topic label"
                },
                {
                  "type": "SHORT_ANSWER",
                  "question": "Written question",
                  "options": [],
                  "correctAnswerIndex": -1,
                  "expectedAnswer": "Expected answer",
                  "evaluationCriteria": "Objective criteria aligned with exactly what the question asks",
                  "explanation": "Explanation",
                  "topic": "Topic label"
                },
                {
                  "type": "PROBLEM_SOLVING",
                  "question": "Problem-solving question",
                  "options": [],
                  "correctAnswerIndex": -1,
                  "expectedAnswer": "Expected solution",
                  "evaluationCriteria": "Objective criteria aligned with exactly what the question asks",
                  "explanation": "Explanation",
                  "topic": "Topic label"
                }
              ]
            }

            IMPORTANT JSON RULES:

            - Use double quotes for JSON strings.
            - Do not use trailing commas.
            - Do not use comments.
            - Use exactly the requested number of questions.
            - Do not use question types that are not permitted.
            - For written-answer questions, never leave expectedAnswer
              or evaluationCriteria empty.
            - For MCQs, never leave options or explanation empty.
        """.trimIndent()

        val response = StudyAIService()
            .generateStructuredReply(prompt)

        if (response.isBlank()) {
            throw IllegalStateException(
                "The AI returned an empty response. Please try again."
            )
        }

        val jsonText = extractJson(response)

        val root = try {
            JSONObject(jsonText)
        } catch (e: JSONException) {
            throw IllegalStateException(
                "The AI returned invalid JSON. Please try generating the quiz again.",
                e
            )
        }

        val questionArray = try {
            root.getJSONArray("questions")
        } catch (e: JSONException) {
            throw IllegalStateException(
                "The AI response does not contain a valid questions list.",
                e
            )
        }

        if (questionArray.length() != questionCount) {
            throw IllegalStateException(
                "The AI generated ${questionArray.length()} questions instead of $questionCount. Please try again."
            )
        }

        val questions = mutableListOf<PracticeQuestion>()

        for (index in 0 until questionArray.length()) {

            val item = try {
                questionArray.getJSONObject(index)
            } catch (e: JSONException) {
                throw IllegalStateException(
                    "Question ${index + 1} has an invalid format."
                )
            }

            val questionText = item.optString(
                "question",
                ""
            ).trim()

            val typeValue = item.optString(
                "type",
                ""
            ).trim().uppercase()

            val questionType = try {
                PracticeQuestionType.valueOf(typeValue)
            } catch (e: IllegalArgumentException) {
                throw IllegalStateException(
                    "Question ${index + 1} has an unsupported question type: $typeValue."
                )
            }

            val optionsJson = item.optJSONArray("options")
            val options = mutableListOf<String>()

            if (optionsJson != null) {
                for (optionIndex in 0 until optionsJson.length()) {
                    options.add(
                        optionsJson.optString(optionIndex, "").trim()
                    )
                }
            }

            val correctAnswerIndex = item.optInt(
                "correctAnswerIndex",
                -1
            )

            val expectedAnswer = item.optString(
                "expectedAnswer",
                ""
            ).trim()

            val evaluationCriteria = item.optString(
                "evaluationCriteria",
                ""
            ).trim()

            val explanation = item.optString(
                "explanation",
                ""
            ).trim()

            val questionTopic = item.optString(
                "topic",
                normalizedTopic
            ).trim().ifBlank {
                normalizedTopic
            }

            if (questionText.isBlank()) {
                throw IllegalStateException(
                    "Question ${index + 1} has no question text."
                )
            }

            if (explanation.isBlank()) {
                throw IllegalStateException(
                    "Question ${index + 1} is missing its explanation."
                )
            }

            when (questionType) {

                PracticeQuestionType.MCQ -> {

                    if (options.size != 4) {
                        throw IllegalStateException(
                            "Question ${index + 1} must have exactly four options."
                        )
                    }

                    if (options.any { it.isBlank() }) {
                        throw IllegalStateException(
                            "Question ${index + 1} contains an empty option."
                        )
                    }

                    if (options.distinct().size != 4) {
                        throw IllegalStateException(
                            "Question ${index + 1} contains duplicate options."
                        )
                    }

                    if (correctAnswerIndex !in 0..3) {
                        throw IllegalStateException(
                            "Question ${index + 1} has an invalid correct answer index."
                        )
                    }
                }

                PracticeQuestionType.SHORT_ANSWER,
                PracticeQuestionType.PROBLEM_SOLVING -> {

                    if (options.isNotEmpty()) {
                        throw IllegalStateException(
                            "Written-answer question ${index + 1} must not contain MCQ options."
                        )
                    }

                    if (correctAnswerIndex != -1) {
                        throw IllegalStateException(
                            "Written-answer question ${index + 1} must have correctAnswerIndex set to -1."
                        )
                    }

                    if (expectedAnswer.isBlank()) {
                        throw IllegalStateException(
                            "Question ${index + 1} is missing its expected answer."
                        )
                    }

                    if (evaluationCriteria.isBlank()) {
                        throw IllegalStateException(
                            "Question ${index + 1} is missing its evaluation criteria."
                        )
                    }
                }
            }

            val permittedType = when (normalizedFormat) {

                MCQ_ONLY ->
                    questionType == PracticeQuestionType.MCQ

                MCQ_AND_SHORT_ANSWER ->
                    questionType == PracticeQuestionType.MCQ ||
                        questionType == PracticeQuestionType.SHORT_ANSWER

                SHORT_ANSWER_ONLY ->
                    questionType == PracticeQuestionType.SHORT_ANSWER

                MIXED_ASSESSMENT -> true

                else -> false
            }

            if (!permittedType) {
                throw IllegalStateException(
                    "Question ${index + 1} does not match the selected question format."
                )
            }

            questions.add(
                PracticeQuestion(
                    id = UUID.randomUUID().toString(),
                    question = questionText,
                    options = options,
                    correctAnswerIndex = correctAnswerIndex,
                    explanation = explanation,
                    topic = questionTopic,
                    difficulty = normalizedDifficulty,
                    type = questionType,
                    expectedAnswer = expectedAnswer,
                    evaluationCriteria = evaluationCriteria
                )
            )
        }

        if (normalizedFormat == MCQ_AND_SHORT_ANSWER) {

            val hasMcq = questions.any {
                it.type == PracticeQuestionType.MCQ
            }

            val hasShortAnswer = questions.any {
                it.type == PracticeQuestionType.SHORT_ANSWER
            }

            if (!hasMcq || !hasShortAnswer) {
                throw IllegalStateException(
                    "The AI did not generate both MCQ and short-answer questions. Please try again."
                )
            }
        }

        if (normalizedFormat == MIXED_ASSESSMENT) {

            val requiredTypes = setOf(
                PracticeQuestionType.MCQ,
                PracticeQuestionType.SHORT_ANSWER,
                PracticeQuestionType.PROBLEM_SOLVING
            )

            val generatedTypes = questions.map {
                it.type
            }.toSet()

            if (!generatedTypes.containsAll(requiredTypes)) {
                throw IllegalStateException(
                    "The AI did not generate all three required question types. Please try again."
                )
            }
        }

        return PracticeQuiz(
            id = UUID.randomUUID().toString(),
            title = if (adaptiveMode) {
                "$normalizedTopic Adaptive Quiz"
            } else {
                "$normalizedTopic Quiz"
            },
            subject = normalizedSubject,
            questions = questions,
            questionFormat = normalizedFormat
        )
    }

    /**
     * Builds a compact, subject-specific performance context
     * for the AI generation prompt.
     */
    private fun buildAdaptiveContext(
        analysis: PracticePerformanceAnalysis,
        selectedTopic: String,
        topicInsight: TopicPerformanceInsight?
    ): String {

        val context = StringBuilder()

        context.appendLine("ADAPTIVE MODE: ENABLED")
        context.appendLine()
        context.appendLine("LEARNER PERFORMANCE CONTEXT:")

        if (!analysis.hasEnoughData) {
            context.appendLine(
                "- Overall historical data is insufficient for reliable adaptation."
            )
            context.appendLine(
                "- Generate a balanced assessment at the selected difficulty."
            )
        } else {
            context.appendLine(
                "- Subject accuracy: ${analysis.overallAccuracy}%"
            )
            context.appendLine(
                "- Evaluated answers: ${analysis.totalEvaluatedAnswers}"
            )
        }

        context.appendLine()
        context.appendLine("SELECTED TOPIC: $selectedTopic")

        if (topicInsight == null) {
            context.appendLine(
                "- No evaluated history exists for this topic."
            )
            context.appendLine(
                "- Treat this as a learning assessment, not a confirmed weakness."
            )
        } else {

            context.appendLine(
                "- Lifetime accuracy: ${topicInsight.accuracy}%"
            )

            context.appendLine(
                "- Evaluated answers: ${topicInsight.evaluatedAnswers}"
            )

            context.appendLine(
                "- Performance classification: ${topicInsight.level.name}"
            )

            context.appendLine(
                "- Recent accuracy: ${
                    topicInsight.recentAccuracy?.let { "$it%" }
                        ?: "Insufficient data"
                }"
            )

            context.appendLine(
                "- Performance trend: ${topicInsight.trend.name}"
            )

            context.appendLine(
                "- Recommended difficulty: ${topicInsight.recommendedDifficulty.name}"
            )

            context.appendLine(
                "- Recommended question count: ${topicInsight.recommendedQuestionCount}"
            )

            context.appendLine(
                "- Learning recommendation: ${topicInsight.recommendation}"
            )
        }

        val priorityTopics = analysis.recommendedTopics
            .filter {
                !it.topic.equals(
                    selectedTopic,
                    ignoreCase = true
                )
            }
            .take(MAX_PRIORITY_TOPICS)

        if (priorityTopics.isNotEmpty()) {
            context.appendLine()
            context.appendLine("OTHER TOPICS NEEDING ATTENTION:")

            priorityTopics.forEach { insight ->
                context.appendLine(
                    "- ${insight.topic}: ${insight.accuracy}% accuracy, " +
                        "classification ${insight.level.name}, " +
                        "trend ${insight.trend.name}."
                )
            }
        }

        context.appendLine()
        context.appendLine(
            "Use this information to adapt the selected topic's questions."
        )
        context.appendLine(
            "Do not generate questions from other topics unless they are " +
                "directly necessary to assess the selected topic."
        )
        context.appendLine(
            "Do not claim the learner has mastered or failed a concept " +
                "based on insufficient evidence."
        )

        return context.toString().trim()
    }

    private fun normalizeQuestionFormat(format: String): String {

        val normalized = format
            .trim()
            .uppercase()
            .replace("-", "_")
            .replace(" ", "_")
            .replace("+", "_AND_")
            .replace(Regex("_+"), "_")

        return when (normalized) {

            MCQ_ONLY,
            "MCQS_ONLY",
            "MCQ" -> MCQ_ONLY

            MCQ_AND_SHORT_ANSWER,
            "MCQS_AND_SHORT_ANSWERS",
            "MCQ_AND_SHORT_ANSWERS" -> MCQ_AND_SHORT_ANSWER

            SHORT_ANSWER_ONLY,
            "SHORT_ANSWERS_ONLY" -> SHORT_ANSWER_ONLY

            MIXED_ASSESSMENT,
            "MIXED" -> MIXED_ASSESSMENT

            else -> throw IllegalArgumentException(
                "Unsupported question format. Please select a supported quiz format."
            )
        }
    }

    private fun extractJson(response: String): String {

        val cleaned = response
            .trim()
            .removePrefix("\uFEFF")
            .trim()

        val start = cleaned.indexOf('{')

        if (start == -1) {
            throw IllegalStateException(
                "The AI did not return a JSON object. Response: ${cleaned.take(200)}"
            )
        }

        var depth = 0
        var insideString = false
        var escaped = false

        for (index in start until cleaned.length) {

            val character = cleaned[index]

            if (insideString) {

                if (escaped) {
                    escaped = false
                } else {
                    when (character) {
                        '\\' -> escaped = true
                        '"' -> insideString = false
                    }
                }

                continue
            }

            when (character) {

                '"' -> insideString = true

                '{' -> depth++

                '}' -> {
                    depth--

                    if (depth == 0) {
                        return cleaned.substring(
                            start,
                            index + 1
                        )
                    }
                }
            }
        }

        throw IllegalStateException(
            "The AI returned incomplete JSON. Please try again."
        )
    }

    companion object {

        const val MCQ_ONLY = "MCQ_ONLY"
        const val MCQ_AND_SHORT_ANSWER = "MCQ_AND_SHORT_ANSWER"
        const val SHORT_ANSWER_ONLY = "SHORT_ANSWER_ONLY"
        const val MIXED_ASSESSMENT = "MIXED_ASSESSMENT"

        private const val MAX_PRIORITY_TOPICS = 5

        private val SUPPORTED_DIFFICULTIES = setOf(
            "EASY",
            "MEDIUM",
            "HARD"
        )
    }
}
