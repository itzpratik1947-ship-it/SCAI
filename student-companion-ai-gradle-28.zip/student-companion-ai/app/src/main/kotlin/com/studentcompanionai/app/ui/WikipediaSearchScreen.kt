
package com.studentcompanionai.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiEmptyState
import com.studentcompanionai.app.ui.components.ScaiLoadingIndicator
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import com.studentcompanionai.app.ui.components.ScaiSecondaryButton
import com.studentcompanionai.app.ui.components.ScaiTextField
import com.studentcompanionai.app.ui.components.ScaiTopBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private data class WikiArticle(
    val title: String,
    val description: String,
    val extract: String,
    val url: String
)

@Composable
fun WikipediaSearchScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var query by remember {
        mutableStateOf("")
    }

    var isLoading by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    var hasSearched by remember {
        mutableStateOf(false)
    }

    val results = remember {
        mutableStateListOf<WikiArticle>()
    }

    // -----------------------------------------
    // WIKIPEDIA SEARCH
    // -----------------------------------------

    fun searchWikipedia(searchTerm: String) {
        if (searchTerm.isBlank() || isLoading) {
            return
        }

        isLoading = true
        hasSearched = true
        errorMessage = null
        results.clear()

        scope.launch {
            try {
                val articles = withContext(Dispatchers.IO) {
                    fetchWikipediaArticles(searchTerm.trim())
                }

                results.addAll(articles)

                if (articles.isEmpty()) {
                    errorMessage =
                        "No matching articles found. Try a different topic."
                }
            } catch (e: Exception) {
                errorMessage =
                    "Unable to load results. Check your internet connection and try again."

                android.util.Log.e(
                    "WikipediaSearch",
                    "Search failed",
                    e
                )
            } finally {
                isLoading = false
            }
        }
    }

    // -----------------------------------------
    // SCREEN
    // -----------------------------------------

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = 20.dp,
            vertical = 14.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // -------------------------------------
        // HEADER
        // -------------------------------------

        item(key = "wiki_header") {
            Column {
                ScaiTopBar(
                    title = "Explore knowledge",
                    subtitle = "Discover topics and concepts"
                )

                Spacer(Modifier.height(18.dp))

                Text(
                    text = "Wikipedia Search",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(Modifier.height(6.dp))

                Text(
                    text = "Explore concepts, people, science, technology and history.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // -------------------------------------
        // SEARCH CARD
        // -------------------------------------

        item(key = "wiki_search") {
            ScaiCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "SEARCH A TOPIC",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.dp.value.let {
                        androidx.compose.ui.unit.TextUnit(
                            it,
                            androidx.compose.ui.unit.TextUnitType.Sp
                        )
                    }
                )

                Spacer(Modifier.height(12.dp))

                ScaiTextField(
                    value = query,
                    onValueChange = {
                        query = it
                    },
                    label = "Topic or keyword",
                    placeholder = "e.g. Quantum physics",
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    enabled = !isLoading
                )

                Spacer(Modifier.height(14.dp))

                ScaiPrimaryButton(
                    text = "Search Wikipedia",
                    onClick = {
                        searchWikipedia(query)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = query.isNotBlank() && !isLoading,
                    loading = isLoading
                )
            }
        }

        // -------------------------------------
        // LOADING STATE
        // -------------------------------------

        if (isLoading) {
            item(key = "wiki_loading") {
                ScaiCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 18.dp)
                    ) {
                        ScaiLoadingIndicator(
                            modifier = Modifier.fillMaxWidth(),
                            message = "Finding useful articles..."
                        )
                    }
                }
            }
        }

        // -------------------------------------
        // ERROR STATE
        // -------------------------------------

        else if (errorMessage != null) {
            item(key = "wiki_error") {
                ScaiCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Search unavailable",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(Modifier.height(8.dp))

                    Text(
                        text = errorMessage.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(14.dp))

                    ScaiSecondaryButton(
                        text = "Try again",
                        onClick = {
                            searchWikipedia(query)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = query.isNotBlank() && !isLoading
                    )
                }
            }
        }

        // -------------------------------------
        // RESULTS HEADER
        // -------------------------------------

        else if (results.isNotEmpty()) {
            item(key = "wiki_results_header") {
                Column {
                    Text(
                        text = "Search results",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = "${results.size} articles found",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // ---------------------------------
            // ARTICLE RESULTS
            // ---------------------------------

            items(
                items = results,
                key = { article -> article.url }
            ) { article ->
                WikiResultCard(
                    article = article,
                    context = context
                )
            }
        }

        // -------------------------------------
        // INITIAL EMPTY STATE
        // -------------------------------------

        else if (!hasSearched) {
            item(key = "wiki_initial_state") {
                ScaiEmptyState(
                    title = "Your next topic starts here",
                    description = "Search for a subject, concept, scientist or historical event to discover useful articles."
                )
            }
        }

        // -------------------------------------
        // BOTTOM INFORMATION
        // -------------------------------------

        item(key = "wiki_footer") {
            Column {
                Spacer(Modifier.height(4.dp))

                ScaiDivider()

                Spacer(Modifier.height(12.dp))

                Text(
                    text = "ARTICLE SUMMARIES FROM WIKIPEDIA",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )

                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

// --------------------------------------------------
// ARTICLE RESULT CARD
// --------------------------------------------------

@Composable
private fun WikiResultCard(
    article: WikiArticle,
    context: Context
) {
    ScaiCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = article.title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold
        )

        if (article.description.isNotBlank()) {
            Spacer(Modifier.height(7.dp))

            Text(
                text = article.description,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(Modifier.height(12.dp))

        Text(
            text = article.extract.ifBlank {
                "Open the full article to explore this topic."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(16.dp))

        ScaiPrimaryButton(
            text = "Read full article",
            onClick = {
                openWikipediaArticle(
                    context = context,
                    articleUrl = article.url
                )
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        Text(
            text = "Source: Wikipedia",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// --------------------------------------------------
// OPEN ARTICLE
// --------------------------------------------------

private fun openWikipediaArticle(
    context: Context,
    articleUrl: String
) {
    try {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse(articleUrl)
        )

        context.startActivity(intent)
    } catch (e: Exception) {
        android.util.Log.e(
            "WikipediaSearch",
            "Could not open article",
            e
        )
    }
}

// --------------------------------------------------
// FETCH WIKIPEDIA ARTICLES
// --------------------------------------------------

private fun fetchWikipediaArticles(
    searchTerm: String
): List<WikiArticle> {
    val encodedQuery = URLEncoder.encode(
        searchTerm,
        Charsets.UTF_8.name()
    )

    val searchUrl =
        "https://en.wikipedia.org/w/api.php" +
            "?action=query&list=search" +
            "&srsearch=$encodedQuery" +
            "&format=json&utf8=1&srlimit=8"

    val searchJson = requestJson(searchUrl)

    val searchItems = searchJson
        .getJSONObject("query")
        .getJSONArray("search")

    val articles = mutableListOf<WikiArticle>()

    for (i in 0 until searchItems.length()) {
        val item = searchItems.getJSONObject(i)
        val title = item.getString("title")

        val encodedTitle = URLEncoder.encode(
            title.replace(' ', '_'),
            Charsets.UTF_8.name()
        )

        val summaryUrl =
            "https://en.wikipedia.org/api/rest_v1/page/summary/" +
                encodedTitle

        try {
            val summary = requestJson(summaryUrl)

            val desktopUrl = summary
                .optJSONObject("content_urls")
                ?.optJSONObject("desktop")
                ?.optString("page")
                .orEmpty()

            articles.add(
                WikiArticle(
                    title = summary.optString("title", title),
                    description = summary.optString("description", ""),
                    extract = summary.optString("extract", ""),
                    url = desktopUrl.ifBlank {
                        "https://en.wikipedia.org/wiki/$encodedTitle"
                    }
                )
            )
        } catch (_: Exception) {
            val snippet = android.text.Html.fromHtml(
                item.optString("snippet", ""),
                android.text.Html.FROM_HTML_MODE_COMPACT
            ).toString()

            articles.add(
                WikiArticle(
                    title = title,
                    description = "",
                    extract = snippet,
                    url = "https://en.wikipedia.org/wiki/$encodedTitle"
                )
            )
        }
    }

    return articles
}

// --------------------------------------------------
// HTTP JSON REQUEST
// --------------------------------------------------

private fun requestJson(
    urlString: String
): JSONObject {
    val connection = URL(urlString)
        .openConnection() as HttpURLConnection

    return try {
        connection.requestMethod = "GET"
        connection.connectTimeout = 10000
        connection.readTimeout = 10000

        connection.setRequestProperty(
            "User-Agent",
            "StudentCompanionAI/1.0 (educational Android application)"
        )

        val responseCode = connection.responseCode

        if (responseCode !in 200..299) {
            throw IllegalStateException(
                "Wikipedia returned HTTP $responseCode"
            )
        }

        connection.inputStream.bufferedReader().use { reader ->
            JSONObject(reader.readText())
        }
    } finally {
        connection.disconnect()
    }
}
