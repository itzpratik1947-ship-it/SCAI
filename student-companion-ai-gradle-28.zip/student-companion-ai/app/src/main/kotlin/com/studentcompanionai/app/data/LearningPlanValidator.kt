
package com.studentcompanionai.app.data

data class LearningPlanValidationResult(
    val isValid: Boolean,
    val errors: List<String>,
    val warnings: List<String>,
    val missingWeakTopics: List<String>
)

class LearningPlanValidator {

    fun validate(
        plan: LearningPlan,
        assessmentResult: InitialAssessmentResult? = null
    ): LearningPlanValidationResult {

        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        val missingWeakTopics = mutableListOf<String>()

        // ------------------------------------------
        // BASIC PLAN VALIDATION
        // ------------------------------------------

        if (plan.id.isBlank()) {
            errors.add("Learning plan ID is missing.")
        }

        if (plan.title.isBlank()) {
            errors.add("Learning plan title is missing.")
        }

        if (plan.goal.isBlank()) {
            errors.add("Learning goal is missing.")
        }

        if (plan.subject.isBlank()) {
            errors.add("Learning plan subject is missing.")
        }

        if (plan.targetDays !in 1..90) {
            errors.add(
                "Learning plan duration must be between 1 and 90 days."
            )
        }

        if (plan.dailyStudyMinutes !in 10..600) {
            errors.add(
                "Daily study time must be between 10 and 600 minutes."
            )
        }

        if (plan.days.size != plan.targetDays) {
            errors.add(
                "Expected ${plan.targetDays} days, but found ${plan.days.size}."
            )
        }

        // ------------------------------------------
        // DRAFT LIFECYCLE VALIDATION
        // ------------------------------------------

        if (plan.status == LearningPlanStatus.DRAFT) {

            if (plan.startDate != 0L) {
                errors.add(
                    "A draft learning plan must not have a start date."
                )
            }

            if (plan.days.any { it.scheduledDate != 0L }) {
                errors.add(
                    "A draft learning plan must not contain scheduled dates."
                )
            }
        }

        // ------------------------------------------
        // DAY SEQUENCE VALIDATION
        // ------------------------------------------

        val sortedDays = plan.days.sortedBy {
            it.dayNumber
        }

        sortedDays.forEachIndexed { index, day ->

            val expectedDayNumber = index + 1

            if (day.dayNumber != expectedDayNumber) {
                errors.add(
                    "Invalid day sequence. Expected Day $expectedDayNumber."
                )
            }

            if (day.title.isBlank()) {
                errors.add(
                    "Day ${day.dayNumber} has an empty title."
                )
            }

            if (day.objectives.isEmpty()) {
                warnings.add(
                    "Day ${day.dayNumber} has no learning objectives."
                )
            }

            if (day.objectives.any { it.isBlank() }) {
                errors.add(
                    "Day ${day.dayNumber} contains an empty objective."
                )
            }

            if (day.activities.isEmpty()) {
                errors.add(
                    "Day ${day.dayNumber} has no learning activities."
                )
            }

            if (day.estimatedMinutes < 0) {
                errors.add(
                    "Day ${day.dayNumber} has an invalid duration."
                )
            }

            if (day.estimatedMinutes > plan.dailyStudyMinutes) {
                errors.add(
                    "Day ${day.dayNumber} exceeds the daily study-time limit."
                )
            }

            // --------------------------------------
            // ACTIVITY TIME VALIDATION
            // --------------------------------------

            val activityMinutes = day.activities.sumOf {
                it.estimatedMinutes
            }

            if (day.activities.any { it.estimatedMinutes < 0 }) {
                errors.add(
                    "Day ${day.dayNumber} contains an activity with a negative duration."
                )
            }

            if (activityMinutes > plan.dailyStudyMinutes) {
                errors.add(
                    "Activities on Day ${day.dayNumber} exceed " +
                        "the daily study-time limit."
                )
            }

            if (
                day.estimatedMinutes > 0 &&
                activityMinutes != day.estimatedMinutes
            ) {
                warnings.add(
                    "Day ${day.dayNumber} has a difference between " +
                        "its estimated duration and the sum of activity durations."
                )
            }

            // --------------------------------------
            // ACTIVITY VALIDATION
            // --------------------------------------

            day.activities.forEach { activity ->

                if (activity.id.isBlank()) {
                    errors.add(
                        "An activity on Day ${day.dayNumber} has no ID."
                    )
                }

                if (activity.title.isBlank()) {
                    errors.add(
                        "An activity on Day ${day.dayNumber} has no title."
                    )
                }

                if (activity.description.isBlank()) {
                    warnings.add(
                        "Activity '${activity.title}' on Day ${day.dayNumber} " +
                            "has no description."
                    )
                }

                if (activity.actualMinutes < 0) {
                    errors.add(
                        "Activity '${activity.title}' has invalid actual study time."
                    )
                }

                if (
                    activity.actualMinutes > 0 &&
                    activity.estimatedMinutes > 0 &&
                    activity.actualMinutes > activity.estimatedMinutes * 5
                ) {
                    warnings.add(
                        "Activity '${activity.title}' has unusually high actual study time."
                    )
                }

                if (
                    activity.allocatedMinutesInvalid()
                ) {
                    errors.add(
                        "Activity '${activity.title}' has invalid resource allocation."
                    )
                }

                activity.resources.forEach { resource ->

                    if (resource.id.isBlank()) {
                        errors.add(
                            "A resource in activity '${activity.title}' has no ID."
                        )
                    }

                    if (resource.title.isBlank()) {
                        errors.add(
                            "A resource in activity '${activity.title}' has no title."
                        )
                    }

                    if (resource.estimatedMinutes < 0) {
                        errors.add(
                            "Resource '${resource.title}' has a negative estimated duration."
                        )
                    }

                    if (resource.allocatedMinutes < 0) {
                        errors.add(
                            "Resource '${resource.title}' has a negative allocated duration."
                        )
                    }

                    if (
                        resource.estimatedMinutes > 0 &&
                        resource.allocatedMinutes > resource.estimatedMinutes
                    ) {
                        warnings.add(
                            "Resource '${resource.title}' has more allocated " +
                                "time than its estimated duration."
                        )
                    }
                }
            }

            // --------------------------------------
            // DAILY TIME ALLOCATION VALIDATION
            // --------------------------------------

            val allocation = day.timeAllocation

            if (
                allocation.mandatoryMinutes < 0 ||
                allocation.taskMinutes < 0 ||
                allocation.resourceMinutes < 0 ||
                allocation.assessmentMinutes < 0 ||
                allocation.revisionMinutes < 0 ||
                allocation.actualMinutes < 0
            ) {
                errors.add(
                    "Day ${day.dayNumber} contains a negative time allocation."
                )
            }

            if (allocation.allocatedMinutes > plan.dailyStudyMinutes) {
                errors.add(
                    "Day ${day.dayNumber} time allocation exceeds " +
                        "the available daily study time."
                )
            }

            if (!allocation.isWithinBudget) {
                warnings.add(
                    "Day ${day.dayNumber} has a time allocation " +
                        "that exceeds its available budget."
                )
            }

            // --------------------------------------
            // PLANNED ASSESSMENT VALIDATION
            // --------------------------------------

            day.assessments.forEach { assessment ->

                if (assessment.id.isBlank()) {
                    errors.add(
                        "An assessment on Day ${day.dayNumber} has no ID."
                    )
                }

                if (assessment.title.isBlank()) {
                    errors.add(
                        "An assessment on Day ${day.dayNumber} has no title."
                    )
                }

                if (assessment.estimatedMinutes < 0) {
                    errors.add(
                        "Assessment '${assessment.title}' has a negative duration."
                    )
                }

                if (
                    assessment.scorePercent != null &&
                    assessment.scorePercent !in 0..100
                ) {
                    errors.add(
                        "Assessment '${assessment.title}' has an invalid score."
                    )
                }
            }
        }

        // ------------------------------------------
        // DUPLICATE ID VALIDATION
        // ------------------------------------------

        val activityIds = plan.days
            .flatMap { it.activities }
            .map { it.id }

        if (activityIds.size != activityIds.distinct().size) {
            errors.add(
                "Duplicate activity IDs were found."
            )
        }

        val resourceIds = plan.days
            .flatMap { day -> day.activities }
            .flatMap { activity -> activity.resources }
            .map { it.id }

        if (resourceIds.size != resourceIds.distinct().size) {
            errors.add(
                "Duplicate resource IDs were found."
            )
        }

        val assessmentIds = plan.days
            .flatMap { it.assessments }
            .map { it.id }

        if (assessmentIds.size != assessmentIds.distinct().size) {
            errors.add(
                "Duplicate assessment IDs were found."
            )
        }

        // ------------------------------------------
        // WEAK TOPIC COVERAGE CHECK
        // ------------------------------------------

        val relevantAssessment = assessmentResult?.takeIf {
            it.profileSubject.trim().equals(
                plan.subject.trim(),
                ignoreCase = true
            )
        }

        if (relevantAssessment != null) {

            val roadmapText = plan.days
                .flatMap { day ->

                    buildList {
                        add(day.title)
                        addAll(day.objectives)

                        day.activities.forEach { activity ->
                            add(activity.title)
                            add(activity.description)
                            add(activity.topic)

                            activity.resources.forEach { resource ->
                                add(resource.title)
                                add(resource.description)
                            }
                        }
                    }
                }
                .joinToString(" ")
                .normalizeForTopicSearch()

            val roadmapTerms = roadmapText
                .split(" ")
                .filter { it.isNotBlank() }
                .toSet()

            val weakTopics = relevantAssessment.topicResults
                .filter {
                    it.knowledgeLevel.equals(
                        "Needs Improvement",
                        ignoreCase = true
                    ) ||
                    it.knowledgeLevel.equals(
                        "Developing",
                        ignoreCase = true
                    )
                }

            weakTopics.forEach { topic ->

                val topicTerms = topic.topic
                    .normalizeForTopicSearch()
                    .split(" ")
                    .filter {
                        it.length >= 3
                    }
                    .distinct()

                // Require every meaningful topic term to appear.
                // A single matching word is not enough to establish coverage.
                val isCovered = topicTerms.isNotEmpty() &&
                    topicTerms.all { term ->
                        term in roadmapTerms
                    }

                if (!isCovered) {

                    missingWeakTopics.add(topic.topic)

                    warnings.add(
                        "Weak topic '${topic.topic}' may not be adequately " +
                            "covered in the generated roadmap."
                    )
                }
            }
        }

        // ------------------------------------------
        // FINAL VALIDATION RESULT
        // ------------------------------------------

        return LearningPlanValidationResult(
            isValid = errors.isEmpty(),
            errors = errors.distinct(),
            warnings = warnings.distinct(),
            missingWeakTopics = missingWeakTopics.distinct()
        )
    }

    private fun String.normalizeForTopicSearch(): String {

        return lowercase()
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }

    private fun LearningActivity.allocatedMinutesInvalid(): Boolean {
        return resources.any {
            it.allocatedMinutes < 0
        }
    }
}
