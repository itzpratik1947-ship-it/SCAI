
package com.studentcompanionai.app.ui.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun ProfileReviewScreen(
    preferredName: String,
    avatar: String,
    userType: String,

    educationCategory: String,
    qualification: String,
    stream: String,
    specialization: String,
    academicYear: String,
    semester: String,
    institution: String,
    boardOrUniversity: String,
    subjects: List<String>,

    // Retained for compatibility with existing onboarding code.
    learningGoal: String,
    secondaryGoals: List<String>,
    targetAchievement: String,
    currentLevel: String,
    targetDays: Int,
    preferredLearningStyle: String,

    wakeTime: String,
    sleepTime: String,
    dailyStudyMinutes: Int,
    availableDays: List<String>,
    availableSlots: List<String>,

    focusDuration: Int,
    breakDuration: Int,
    dailyFocusTarget: Int,
    preferredFocusTime: String,

    // Retained for compatibility with LearnerOnboardingScreen.
    // Learning preferences are not displayed during onboarding.
    preferredLanguage: String,
    preferredDifficulty: String,
    areasOfDifficulty: List<String>,
    notificationsEnabled: Boolean,
    studyReminders: Boolean,
    goalReminders: Boolean,
    progressUpdates: Boolean,

    onEditPersonalInfo: () -> Unit,
    onEditEducation: () -> Unit,
    onEditGoals: () -> Unit,
    onEditSchedule: () -> Unit,
    onEditFocus: () -> Unit,
    onEditPreferences: () -> Unit,
    onBack: () -> Unit,
    onComplete: () -> Unit
) {

    val colors = MaterialTheme.colorScheme

    val isSchool = educationCategory == "School"
    val isCollege = educationCategory == "Junior College"
    val isUndergraduate = educationCategory == "Undergraduate"
    val isPostgraduate = educationCategory == "Postgraduate"
    val isProgramming = educationCategory == "Programming"
    val isLanguageLearning = educationCategory == "Language Learning"

    val qualificationLabel = when {
        isSchool -> "Standard"
        isCollege -> "Qualification"
        isUndergraduate || isPostgraduate -> "Degree"
        else -> "Learning level"
    }

    val streamLabel = when {
        isSchool || isCollege -> "Stream"
        isProgramming -> "Programming area"
        isLanguageLearning -> "Language category"
        else -> "Learning field"
    }

    val specializationLabel = when {
        isProgramming -> "Programming language / skill"
        isLanguageLearning -> "Language"
        else -> "Specialization"
    }

    val boardLabel = when {
        isSchool || isCollege -> "Board"
        isUndergraduate || isPostgraduate -> "University"
        else -> "Platform / Provider"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {

        TextButton(onClick = onBack) {
            Text("← Back")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Your learner profile",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Review your information before completing your setup. You can go back and make changes whenever needed.",
            style = MaterialTheme.typography.bodyLarge,
            color = colors.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        // -----------------------------------------------------
        // PERSONAL PROFILE CARD
        // -----------------------------------------------------

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = colors.primaryContainer
            )
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    text = preferredName.ifBlank { "Learner" },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = colors.onPrimaryContainer
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = userType,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onPrimaryContainer
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = educationCategory,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onPrimaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // -----------------------------------------------------
        // PERSONAL INFORMATION
        // -----------------------------------------------------

        ReviewSection(
            title = "Personal information",
            onEdit = onEditPersonalInfo
        ) {

            ReviewRow("Preferred name", preferredName)
            ReviewRow("User type", userType)
        }

        // -----------------------------------------------------
        // EDUCATION / LEARNING INFORMATION
        // -----------------------------------------------------

        ReviewSection(
            title = "Education & learning",
            onEdit = onEditEducation
        ) {

            ReviewRow(
                "Learning category",
                educationCategory
            )

            ReviewRow(
                qualificationLabel,
                qualification
            )

            ReviewRow(
                streamLabel,
                stream
            )

            ReviewRow(
                specializationLabel,
                specialization
            )

            if (isCollege || isUndergraduate || isPostgraduate) {

                ReviewRow(
                    "Academic year",
                    academicYear
                )

                ReviewRow(
                    "Semester",
                    semester
                )
            }

            ReviewRow(
                "Institution",
                institution
            )

            ReviewRow(
                boardLabel,
                boardOrUniversity
            )

            ReviewRow(
                if (isProgramming || isLanguageLearning) {
                    "Skills / Topics"
                } else {
                    "Subjects / Topics"
                },
                subjects.joinToString(", ")
            )
        }

        // -----------------------------------------------------
        // STUDY SCHEDULE
        // -----------------------------------------------------

        ReviewSection(
            title = "Study schedule",
            onEdit = onEditSchedule
        ) {

            ReviewRow("Wake-up time", wakeTime)
            ReviewRow("Sleep time", sleepTime)

            ReviewRow(
                "Daily study time",
                formatDuration(dailyStudyMinutes)
            )

            ReviewRow(
                "Available days",
                availableDays.joinToString(", ")
            )

            ReviewRow(
                "Preferred study periods",
                availableSlots.joinToString(", ")
            )
        }

        // -----------------------------------------------------
        // FOCUS PREFERENCES
        // -----------------------------------------------------

        ReviewSection(
            title = "Focus preferences",
            onEdit = onEditFocus
        ) {

            ReviewRow(
                "Focus duration",
                "$focusDuration minutes"
            )

            ReviewRow(
                "Break duration",
                "$breakDuration minutes"
            )

            ReviewRow(
                "Daily focus target",
                "$dailyFocusTarget sessions"
            )

            ReviewRow(
                "Preferred focus time",
                preferredFocusTime
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // -----------------------------------------------------
        // COMPLETION INFORMATION
        // -----------------------------------------------------

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = colors.surfaceVariant.copy(alpha = 0.55f)
        ) {

            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                Text(
                    text = "Your learning journey starts here!",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "SCAI will use your profile to personalise learning plans, explanations, practice activities, focus sessions and progress tracking.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onComplete,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(14.dp)
        ) {

            Text(
                text = "Complete Profile",
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(
            onClick = onBack,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text("Go Back")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "You can update your profile later from Settings or Profile.",
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))
    }
}


// =============================================================
// REUSABLE REVIEW SECTION
// =============================================================

@Composable
private fun ReviewSection(
    title: String,
    onEdit: () -> Unit,
    content: @Composable () -> Unit
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {

        Column(
            modifier = Modifier.padding(16.dp)
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                TextButton(onClick = onEdit) {
                    Text("Edit")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            content()
        }
    }
}


// =============================================================
// REVIEW ROW
// =============================================================

@Composable
private fun ReviewRow(
    label: String,
    value: String
) {

    if (value.isBlank()) return

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
    ) {

        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}


// =============================================================
// HELPERS
// =============================================================

private fun formatDuration(minutes: Int): String {

    val hours = minutes / 60
    val remainingMinutes = minutes % 60

    return when {

        hours > 0 && remainingMinutes > 0 ->
            "$hours hr $remainingMinutes min"

        hours > 0 ->
            "$hours hr"

        else ->
            "$remainingMinutes min"
    }
}
