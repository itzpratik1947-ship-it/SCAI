
package com.studentcompanionai.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studentcompanionai.app.data.AssessmentQuestionType
import com.studentcompanionai.app.data.InitialAssessmentQuestion
import com.studentcompanionai.app.data.InitialAssessmentResponse

private val AssessmentBackground = Color(0xFF0B1120)
private val AssessmentCard = Color(0xFF151F32)
private val AssessmentAccent = Color(0xFF7C83FD)
private val AssessmentText = Color(0xFFF1F5F9)
private val AssessmentMuted = Color(0xFF9CAAC0)

@Composable
fun InitialAssessmentScreen(
    questions: List<InitialAssessmentQuestion>,
    onBackClick: () -> Unit = {},
    onAssessmentSubmitted: (
        List<InitialAssessmentResponse>
    ) -> Unit
) {

    var currentQuestionIndex by remember(questions) {
        mutableIntStateOf(0)
    }

    val responses = remember(questions) {
        mutableStateMapOf<String, InitialAssessmentResponse>()
    }

    val questionCount = questions.size

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = AssessmentBackground
    ) {

        if (questionCount == 0) {

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    text = "No assessment questions available",
                    color = AssessmentText,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(12.dp))

                Text(
                    text = "Generate an assessment before starting.",
                    color = AssessmentMuted
                )

                Spacer(Modifier.height(20.dp))

                Button(onClick = onBackClick) {
                    Text("Go back")
                }
            }

        } else {

            val question = questions[currentQuestionIndex]
            val currentResponse = responses[question.id]

            val progress =
                (currentQuestionIndex + 1).toFloat() /
                    questionCount.toFloat()

            val answeredCount = responses.size

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {

                // HEADER

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    OutlinedButton(
                        onClick = onBackClick
                    ) {
                        Text("Exit")
                    }

                    Spacer(Modifier.weight(1f))

                    Text(
                        text = "INITIAL ASSESSMENT",
                        color = AssessmentAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(Modifier.height(20.dp))

                Text(
                    text = "Discover your current knowledge",
                    color = AssessmentText,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(6.dp))

                Text(
                    text = "Answer independently. Your responses help " +
                        "your Learning Coach understand what you already know.",
                    color = AssessmentMuted,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )

                Spacer(Modifier.height(20.dp))

                // PROGRESS

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp),
                    color = AssessmentAccent,
                    trackColor = AssessmentCard
                )

                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {

                    Text(
                        text = "Question ${currentQuestionIndex + 1} of $questionCount",
                        color = AssessmentMuted,
                        fontSize = 12.sp
                    )

                    Text(
                        text = "$answeredCount answered",
                        color = AssessmentAccent,
                        fontSize = 12.sp
                    )
                }

                Spacer(Modifier.height(20.dp))

                // QUESTION CONTENT

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        InfoChip(
                            text = question.type.name
                        )

                        InfoChip(
                            text = question.difficulty.name
                        )
                    }

                    Text(
                        text = question.topic,
                        color = AssessmentAccent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = question.question,
                        color = AssessmentText,
                        fontSize = 20.sp,
                        lineHeight = 29.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    when (question.type) {

                        AssessmentQuestionType.MCQ -> {

                            question.options.forEachIndexed {
                                    index, option ->

                                val selected =
                                    currentResponse?.selectedOptionIndex == index

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    onClick = {
                                        responses[question.id] =
                                            InitialAssessmentResponse(
                                                questionId = question.id,
                                                selectedOptionIndex = index
                                            )
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (selected) {
                                            Color(0xFF252B50)
                                        } else {
                                            AssessmentCard
                                        }
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (selected) {
                                            AssessmentAccent
                                        } else {
                                            Color(0xFF2A3850)
                                        }
                                    )
                                ) {

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment =
                                            Alignment.CenterVertically
                                    ) {

                                        RadioButton(
                                            selected = selected,
                                            onClick = {
                                                responses[question.id] =
                                                    InitialAssessmentResponse(
                                                        questionId = question.id,
                                                        selectedOptionIndex = index
                                                    )
                                            }
                                        )

                                        Spacer(Modifier.width(8.dp))

                                        Text(
                                            text = option,
                                            color = AssessmentText,
                                            fontSize = 15.sp
                                        )
                                    }
                                }
                            }
                        }

                        AssessmentQuestionType.SHORT_ANSWER -> {

                            Text(
                                text = "Write a concise answer.",
                                color = AssessmentMuted,
                                fontSize = 13.sp
                            )

                            OutlinedTextField(
                                value = currentResponse?.writtenAnswer ?: "",
                                onValueChange = { answer ->

                                    responses[question.id] =
                                        InitialAssessmentResponse(
                                            questionId = question.id,
                                            writtenAnswer = answer
                                        )
                                },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = {
                                    Text("Enter your answer...")
                                },
                                minLines = 4,
                                maxLines = 8
                            )
                        }

                        AssessmentQuestionType.PROBLEM_SOLVING -> {

                            Text(
                                text = "Show your working and explain " +
                                    "the steps used to reach your answer.",
                                color = AssessmentMuted,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )

                            OutlinedTextField(
                                value = currentResponse?.writtenAnswer ?: "",
                                onValueChange = { answer ->

                                    responses[question.id] =
                                        InitialAssessmentResponse(
                                            questionId = question.id,
                                            writtenAnswer = answer
                                        )
                                },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = {
                                    Text(
                                        "Write your solution and steps..."
                                    )
                                },
                                minLines = 6,
                                maxLines = 12
                            )
                        }
                    }

                    Text(
                        text = "Maximum marks: ${question.maximumMarks}",
                        color = AssessmentMuted,
                        fontSize = 12.sp
                    )
                }

                Spacer(Modifier.height(16.dp))

                // NAVIGATION

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    OutlinedButton(
                        onClick = {
                            if (currentQuestionIndex > 0) {
                                currentQuestionIndex--
                            }
                        },
                        enabled = currentQuestionIndex > 0,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                    ) {
                        Text("Previous")
                    }

                    Button(
                        onClick = {

                            if (currentQuestionIndex < questionCount - 1) {

                                currentQuestionIndex++

                            } else {

                                val orderedResponses = questions.map {
                                    questionItem ->

                                    responses[questionItem.id]
                                        ?: InitialAssessmentResponse(
                                            questionId = questionItem.id
                                        )
                                }

                                onAssessmentSubmitted(
                                    orderedResponses
                                )
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AssessmentAccent
                        )
                    ) {

                        Text(
                            text = if (
                                currentQuestionIndex == questionCount - 1
                            ) {
                                "Submit assessment"
                            } else {
                                "Next question"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                Text(
                    text = "Unanswered questions can be reviewed " +
                        "before submission.",
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    color = AssessmentMuted,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun InfoChip(
    text: String
) {

    Box(
        modifier = Modifier
            .background(
                color = AssessmentCard,
                shape = RoundedCornerShape(20.dp)
            )
            .padding(
                horizontal = 11.dp,
                vertical = 7.dp
            )
    ) {

        Text(
            text = text.replace("_", " "),
            color = AssessmentAccent,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
