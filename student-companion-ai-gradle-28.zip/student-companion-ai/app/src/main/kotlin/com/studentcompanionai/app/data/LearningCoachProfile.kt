
package com.studentcompanionai.app.data

/**
 * Central learner profile for Student Companion AI.
 *
 * This model extends the original LearningCoachProfile so existing
 * Learning Coach functionality remains compatible.
 *
 * Existing properties are retained:
 * learningGoal, subject, currentLevel, targetDays,
 * dailyStudyMinutes and preferredLearningStyle.
 */
data class LearningCoachProfile(

    // ---------------------------------------------------------
    // EXISTING LEARNING COACH FIELDS
    // ---------------------------------------------------------

    val learningGoal: String,
    val subject: String,
    val currentLevel: LearningLevel,
    val targetDays: Int,
    val dailyStudyMinutes: Int,
    val preferredLearningStyle: LearningStyle,

    // ---------------------------------------------------------
    // SYSTEM INFORMATION
    // ---------------------------------------------------------

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // ---------------------------------------------------------
    // PERSONAL INFORMATION
    // ---------------------------------------------------------
    
    val preferredName: String = "",
        /**
     * Learner's date of birth.
     * Stored in ISO format: yyyy-MM-dd.
     *
     * Nullable/defaulted to preserve compatibility
     * with profiles created before this field existed.
     */
    val dateOfBirth: String? = null,
    val avatar: String? = null,
    val userType: UserType = UserType.STUDENT,

    // ---------------------------------------------------------
    // EDUCATIONAL BACKGROUND
    // ---------------------------------------------------------

    val educationCategory: EducationCategory = EducationCategory.INDEPENDENT_LEARNING,
    val qualification: String = "",
    val stream: String = "",
    val specialization: String = "",
    val academicYear: String = "",
    val semester: String = "",
    val institution: String = "",
    val boardOrUniversity: String = "",
    val subjects: List<String> = emptyList(),

    // ---------------------------------------------------------
    // LEARNING GOALS
    // ---------------------------------------------------------

    val secondaryGoals: List<String> = emptyList(),
    val targetAchievement: String = "",

    /**
     * Additional learning tracks allow learners to pursue
     * multiple goals alongside their main education.
     *
     * Example:
     * BTech + Python Programming + GATE Preparation.
     */
    val learningTracks: List<LearningTrack> = emptyList(),

    // ---------------------------------------------------------
    // DAILY SCHEDULE
    // ---------------------------------------------------------

    val wakeTime: String = "",
    val sleepTime: String = "",

    /**
     * Occupied and available slots are stored separately.
     * Time format: HH:mm (24-hour format).
     */
    val occupiedSlots: List<ScheduleSlot> = emptyList(),
    val availableSlots: List<ScheduleSlot> = emptyList(),

    /**
     * Days on which the learner is available.
     * Values should use DayOfWeek enum names.
     */
    val availableDays: List<String> = emptyList(),

    // dailyStudyMinutes is retained as the single source
    // for the learner's daily study-time target.

    // ---------------------------------------------------------
    // FOCUS PREFERENCES
    // ---------------------------------------------------------

    val focusDuration: Int = 25,
    val breakDuration: Int = 5,
    val dailyFocusTarget: Int = 4,
    val preferredFocusTime: PreferredFocusTime = PreferredFocusTime.FLEXIBLE,

    // ---------------------------------------------------------
    // LEARNING PREFERENCES
    // ---------------------------------------------------------

    val preferredLanguage: String = "",
    val preferredDifficulty: LearningDifficulty = LearningDifficulty.ADAPTIVE,

    val notificationPreferences: NotificationPreferences =
        NotificationPreferences(),

    val areasOfDifficulty: List<String> = emptyList(),

    // ---------------------------------------------------------
    // ONBOARDING STATUS
    // ---------------------------------------------------------

    /**
     * Only becomes true after the learner reviews and
     * completes the onboarding process.
     */
    val profileCompleted: Boolean = false

) {

    /**
     * Validates the existing Learning Coach requirements.
     *
     * These checks are intentionally preserved to avoid
     * breaking existing Learning Coach functionality.
     */
    fun isValid(): Boolean {
        return learningGoal.isNotBlank() &&
            subject.isNotBlank() &&
            targetDays in 1..3650 &&
            dailyStudyMinutes in 5..1440
    }

    /**
     * Validates the preferred name when supplied.
     * A name is required for completing onboarding,
     * but not for existing Learning Coach profiles.
     */
    fun hasValidIdentity(): Boolean {
        return preferredName.isNotBlank()
    }

    /**
     * Validates focus preferences.
     */
    fun hasValidFocusPreferences(): Boolean {
        return focusDuration in 5..180 &&
            breakDuration in 1..60 &&
            dailyFocusTarget in 1..24
    }
}

// =============================================================
// USER TYPE
// =============================================================

enum class UserType(val displayName: String) {
    STUDENT("Student"),
    WORKING_PROFESSIONAL("Working professional"),
    INDEPENDENT_LEARNER("Independent learner"),
    OTHER("Other")
}

// =============================================================
// EDUCATION CATEGORY
// =============================================================

enum class EducationCategory(val displayName: String) {
    SCHOOL("School"),
    HIGHER_SECONDARY("Higher Secondary"),
    GRADUATION("Graduation"),
    POST_GRADUATION("Post Graduation"),
    DIPLOMA("Diploma"),
    PROFESSIONAL_COURSE("Professional Courses"),
    INDEPENDENT_LEARNING("Independent Learning"),
    OTHER("Other")
}

// =============================================================
// LEARNING LEVEL
// =============================================================

enum class LearningLevel(val displayName: String) {
    BEGINNER("Beginner"),
    INTERMEDIATE("Intermediate"),
    ADVANCED("Advanced")
}

// =============================================================
// LEARNING STYLE
// =============================================================

enum class LearningStyle(val displayName: String) {

    // Original styles. Do not remove or rename these.
    EXAMPLES("Learn through examples"),
    THEORY("Understand the theory first"),
    PRACTICE("Learn by practising"),
    MIXED("A mix of explanations and practice"),

    // Additional personalized learning styles.
    VISUAL("Visual explanations and diagrams"),
    DETAILED_NOTES("Detailed notes"),
    VIDEOS("Videos and demonstrations"),
    PROBLEM_SOLVING("Practical problem-solving"),
    INTERACTIVE_QUIZZES("Interactive quizzes"),
    STEP_BY_STEP("Step-by-step explanations"),
    COMBINATION("Combination of everything")
}

// =============================================================
// LEARNING TRACK
// =============================================================

/**
 * Represents an additional subject, skill or learning goal.
 *
 * Examples:
 * - Python Programming
 * - GATE Preparation
 * - Artificial Intelligence
 * - English Communication
 */
data class LearningTrack(
    val title: String,
    val category: String = "",
    val currentLevel: LearningLevel = LearningLevel.BEGINNER,
    val targetAchievement: String = "",
    val targetDays: Int = 30,
    val isPrimary: Boolean = false
)

// =============================================================
// SCHEDULE
// =============================================================

/**
 * Represents an occupied or available time slot.
 *
 * Example:
 * day = "MONDAY"
 * startTime = "09:00"
 * endTime = "16:00"
 * label = "College"
 */
data class ScheduleSlot(
    val day: String,
    val startTime: String,
    val endTime: String,
    val label: String = ""
)

// =============================================================
// DAYS OF THE WEEK
// =============================================================

enum class DayOfWeek(val displayName: String) {
    MONDAY("Monday"),
    TUESDAY("Tuesday"),
    WEDNESDAY("Wednesday"),
    THURSDAY("Thursday"),
    FRIDAY("Friday"),
    SATURDAY("Saturday"),
    SUNDAY("Sunday")
}

// =============================================================
// FOCUS TIME PREFERENCE
// =============================================================

enum class PreferredFocusTime(val displayName: String) {
    MORNING("Morning"),
    AFTERNOON("Afternoon"),
    EVENING("Evening"),
    NIGHT("Night"),
    FLEXIBLE("Flexible / AI decides")
}

// =============================================================
// LEARNING DIFFICULTY
// =============================================================

enum class LearningDifficulty(val displayName: String) {
    EASY("Easy"),
    MODERATE("Moderate"),
    CHALLENGING("Challenging"),
    ADAPTIVE("Adapt according to my performance")
}

// =============================================================
// NOTIFICATION PREFERENCES
// =============================================================

data class NotificationPreferences(
    val studyReminders: Boolean = true,
    val learningPlanReminders: Boolean = true,
    val focusReminders: Boolean = true,
    val dailyProgressSummary: Boolean = false,
    val achievementNotifications: Boolean = true
)
