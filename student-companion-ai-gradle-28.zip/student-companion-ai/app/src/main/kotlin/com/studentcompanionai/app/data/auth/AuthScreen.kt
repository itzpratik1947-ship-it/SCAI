
package com.studentcompanionai.app.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.studentcompanionai.app.data.auth.AuthRepository
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    repository: AuthRepository = AuthRepository(),
    onAuthenticated: () -> Unit
) {
    var isRegistering by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var messageIsSuccess by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val colors = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // BRANDING

        Surface(
            shape = RoundedCornerShape(18.dp),
            color = colors.surfaceVariant,
            modifier = Modifier.size(64.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = "SC",
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.onSurface
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Student Companion AI",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = colors.onBackground,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = if (isRegistering) {
                "Create your account and begin learning."
            } else {
                "Your learning journey, all in one place."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = colors.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        // AUTHENTICATION CARD

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 460.dp),
            shape = RoundedCornerShape(20.dp),
            color = colors.surface,
            tonalElevation = 0.dp,
            shadowElevation = 0.dp
        ) {
            Column(
                modifier = Modifier.padding(22.dp)
            ) {
                Text(
                    text = if (isRegistering) {
                        "Create account"
                    } else {
                        "Welcome back"
                    },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.onSurface
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (isRegistering) {
                        "Enter your details to get started."
                    } else {
                        "Sign in to continue where you left off."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(24.dp))

                // GOOGLE SIGN-IN

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = colors.background,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        colors.outline
                    ),
                    onClick = {
                        if (!isLoading) {
                            message = null
                            isLoading = true

                            scope.launch {
                                try {
                                    repository.signInWithGoogle(context)
                                    onAuthenticated()
                                } catch (e: Exception) {
                                    message = e.localizedMessage
                                        ?: "Google sign-in failed. Please try again."
                                    messageIsSuccess = false
                                } finally {
                                    isLoading = false
                                }
                            }
                        }
                    }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(19.dp),
                                color = colors.onSurface,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Please wait...",
                                color = colors.onSurface,
                                fontWeight = FontWeight.Medium
                            )
                        } else {
                            Text(
                                text = "G",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.onSurface
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Continue with Google",
                                color = colors.onSurface,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                // DIVIDER

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ScaiDivider(modifier = Modifier.weight(1f))

                    Text(
                        text = "  OR CONTINUE WITH EMAIL  ",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.onSurfaceVariant
                    )

                    ScaiDivider(modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(22.dp))

                // REGISTRATION NAME

                if (isRegistering) {
                    AuthInput(
                        value = name,
                        onValueChange = { name = it },
                        label = "Full name",
                        enabled = !isLoading,
                        keyboardType = KeyboardType.Text
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // EMAIL

                AuthInput(
                    value = email,
                    onValueChange = { email = it },
                    label = "Email address",
                    enabled = !isLoading,
                    keyboardType = KeyboardType.Email
                )

                Spacer(modifier = Modifier.height(16.dp))

                // PASSWORD

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading,
                    label = { Text("Password") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password
                    ),
                    visualTransformation = if (passwordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        TextButton(
                            onClick = {
                                passwordVisible = !passwordVisible
                            },
                            enabled = !isLoading
                        ) {
                            Text(
                                text = if (passwordVisible) "Hide" else "Show",
                                color = colors.onSurfaceVariant
                            )
                        }
                    },
                    colors = authFieldColors()
                )

                // FORGOT PASSWORD

                if (!isRegistering) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = {
                                message = null

                                if (email.isBlank()) {
                                    message = "Enter your email address first."
                                    messageIsSuccess = false
                                } else {
                                    isLoading = true

                                    scope.launch {
                                        try {
                                            repository.sendPasswordReset(
                                                email.trim()
                                            )

                                            message = "Password reset email sent."
                                            messageIsSuccess = true
                                        } catch (e: Exception) {
                                            message = e.localizedMessage
                                                ?: "Could not send reset email."
                                            messageIsSuccess = false
                                        } finally {
                                            isLoading = false
                                        }
                                    }
                                }
                            },
                            enabled = !isLoading
                        ) {
                            Text(
                                text = "Forgot password?",
                                color = colors.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                // STATUS MESSAGE

                message?.let {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = if (messageIsSuccess) {
                            colors.surfaceVariant
                        } else {
                            colors.errorContainer
                        }
                    ) {
                        Text(
                            text = it,
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (messageIsSuccess) {
                                colors.onSurface
                            } else {
                                colors.onErrorContainer
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // EMAIL AUTHENTICATION

                ScaiPrimaryButton(
                    text = if (isRegistering) {
                        "Create account"
                    } else {
                        "Sign in"
                    },
                    onClick = {
                        message = null

                        when {
                            email.isBlank() -> {
                                message = "Enter your email address."
                                messageIsSuccess = false
                            }

                            password.isBlank() -> {
                                message = "Enter your password."
                                messageIsSuccess = false
                            }

                            isRegistering && name.isBlank() -> {
                                message = "Enter your name."
                                messageIsSuccess = false
                            }

                            else -> {
                                isLoading = true

                                scope.launch {
                                    try {
                                        if (isRegistering) {
                                            repository.register(
                                                name.trim(),
                                                email.trim(),
                                                password
                                            )
                                        } else {
                                            repository.signIn(
                                                email.trim(),
                                                password
                                            )
                                        }

                                        onAuthenticated()
                                    } catch (e: Exception) {
                                        message = e.localizedMessage
                                            ?: "Authentication failed. Please try again."
                                        messageIsSuccess = false
                                    } finally {
                                        isLoading = false
                                    }
                                }
                            }
                        }
                    },
                    enabled = !isLoading,
                    loading = isLoading
                )

                Spacer(modifier = Modifier.height(20.dp))

                // SIGN-IN / SIGN-UP SWITCH

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isRegistering) {
                            "Already have an account?"
                        } else {
                            "New to Student Companion?"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant
                    )

                    TextButton(
                        onClick = {
                            isRegistering = !isRegistering
                            message = null
                            messageIsSuccess = false
                            password = ""
                        },
                        enabled = !isLoading
                    ) {
                        Text(
                            text = if (isRegistering) {
                                "Sign in"
                            } else {
                                "Register"
                            },
                            color = colors.onSurface,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = "LEARN  •  PRACTISE  •  PROGRESS",
            style = MaterialTheme.typography.labelSmall,
            color = colors.onSurfaceVariant,
            letterSpacing = 1.2.sp
        )

        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun AuthInput(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    enabled: Boolean,
    keyboardType: KeyboardType
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        enabled = enabled,
        label = { Text(label) },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        keyboardOptions = KeyboardOptions(
            keyboardType = keyboardType
        ),
        colors = authFieldColors()
    )
}

@Composable
private fun authFieldColors() =
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = MaterialTheme.colorScheme.onSurface,
        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
        focusedBorderColor = MaterialTheme.colorScheme.onSurface,
        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
        focusedLabelColor = MaterialTheme.colorScheme.onSurface,
        unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
        cursorColor = MaterialTheme.colorScheme.onSurface,
        focusedContainerColor = Color.Transparent,
        unfocusedContainerColor = Color.Transparent,
        disabledTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
        disabledBorderColor = MaterialTheme.colorScheme.outlineVariant
    )
