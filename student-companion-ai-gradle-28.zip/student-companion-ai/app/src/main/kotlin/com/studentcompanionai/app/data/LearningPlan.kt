
package com.studentcompanionai.app.data

data class LearningPlan(
    val id: String,
    val title: String,
    val goal: String,
    val subject: String,
    val currentLevel: String,
    val targetDays: Int,
    val dailyStudyMinutes: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val days: List<LearningDay> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis(),

    // Planner lifecycle
    val startDate: Long = 0L,
    val status: LearningPlanStatus = LearningPlanStatus.ACTIVE
) {
    val completedDays: Int
        get() = days.count { it.isCompleted }

    val totalDays: Int
        get() = days.size

    val progressPercent: Int
        get() = if (days.isEmpty()) {
            0
        } else {
            (completedDays * 100) / days.size
        }
}

enum class LearningPlanStatus {
    DRAFT,
    ACTIVE,
    PAUSED,
    COMPLETED,
    CANCELLED
}

data class LearningDay(
    val dayNumber: Int,
    val title: String,
    val objectives: List<String> = emptyList(),
    val activities: List<LearningActivity> = emptyList(),
    val estimatedMinutes: Int = 0,
    val isCompleted: Boolean = false,

    // Calendar scheduling
    val scheduledDate: Long = 0L,

    // Actual time spent on this day
    val actualMinutes: Int = 0,

    // Daily time budget
    val timeAllocation: DailyTimeAllocation = DailyTimeAllocation(),

    // Scheduled assessments
    val assessments: List<PlannedAssessment> = emptyList()
)

data class LearningActivity(
    val id: String,
    val title: String,
    val description: String,
    val type: ActivityType = ActivityType.LEARN,
    val estimatedMinutes: Int = 0,
    val isCompleted: Boolean = false,
    val topic: String = "",

    // Actual execution tracking
    val actualMinutes: Int = 0,
    val completedAt: Long = 0L,

    // Links to existing app records
    val linkedTaskId: Int? = null,
    val linkedAssessmentId: String? = null,

    // Learning resources
    val resources: List<LearningResource> = emptyList()
)

enum class ActivityType {
    LEARN,
    PRACTICE,
    REVISION,
    TEST,
    PROJECT,
    RESOURCE
}

data class LearningResource(
    val id: String,
    val title: String,
    val url: String,
    val type: LearningResourceType = LearningResourceType.WEBSITE,
    val provider: String = "",
    val description: String = "",
    val estimatedMinutes: Int = 0,
    val allocatedMinutes: Int = 0,
    val topic: String = ""
)

enum class LearningResourceType {
    VIDEO,
    WEBSITE,
    ARTICLE,
    DOCUMENT,
    COURSE,
    BOOK,
    OTHER
}

data class PlannedAssessment(
    val id: String,
    val title: String,
    val description: String = "",
    val topic: String = "",
    val scheduledDate: Long = 0L,
    val availableFrom: Long = 0L,
    val expiresAt: Long = 0L,
    val estimatedMinutes: Int = 0,
    val status: AssessmentStatus = AssessmentStatus.SCHEDULED,
    val linkedQuizId: String? = null,
    val completedAt: Long = 0L,
    val scorePercent: Int? = null
)

enum class AssessmentStatus {
    SCHEDULED,
    AVAILABLE,
    COMPLETED,
    MISSED,
    EXPIRED
}

data class DailyTimeAllocation(
    val mandatoryMinutes: Int = 0,
    val taskMinutes: Int = 0,
    val resourceMinutes: Int = 0,
    val assessmentMinutes: Int = 0,
    val revisionMinutes: Int = 0,
    val actualMinutes: Int = 0
) {
    val allocatedMinutes: Int
        get() = taskMinutes +
            resourceMinutes +
            assessmentMinutes +
            revisionMinutes

    val remainingMinutes: Int
        get() = (mandatoryMinutes - allocatedMinutes)
            .coerceAtLeast(0)

    val isWithinBudget: Boolean
        get() = allocatedMinutes <= mandatoryMinutes
}
