
package com.studentcompanionai.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.InitialAssessmentResult
import com.studentcompanionai.app.data.LearningCoachProfile
import com.studentcompanionai.app.data.LearningPlan
import com.studentcompanionai.app.data.LearningPlanGenerator
import com.studentcompanionai.app.data.LearningPlanValidator
import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiLoadingIndicator
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiSectionTitle
import com.studentcompanionai.app.ui.components.ScaiTextField
import com.studentcompanionai.app.ui.components.ScaiTopBar
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val learningLevels = listOf(
    "Beginner",
    "Intermediate",
    "Advanced"
)

@Composable
fun LearningPlanCreateScreen(
    onBackClick: () -> Unit = {},
    onPlanGenerated: (LearningPlan) -> Unit = {},
    modifier: Modifier = Modifier,
    showBackButton: Boolean = true
) {
    // ACCOUNT AND STORAGE

    val context = androidx.compose.ui.platform.LocalContext.current.applicationContext
    val auth = remember { FirebaseAuth.getInstance() }
    val uid = auth.currentUser?.uid

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    val coroutineScope = rememberCoroutineScope()

    // FORM STATE

    var goal by rememberSaveable(uid) {
        mutableStateOf("")
    }

    var subject by rememberSaveable(uid) {
        mutableStateOf("")
    }

    var currentLevel by rememberSaveable(uid) {
        mutableStateOf("Beginner")
    }

    var levelMenuExpanded by rememberSaveable(uid) {
        mutableStateOf(false)
    }

    var targetDaysText by rememberSaveable(uid) {
        mutableStateOf("7")
    }

    var dailyMinutesText by rememberSaveable(uid) {
        mutableStateOf("60")
    }

    var hasEditedInputs by rememberSaveable(uid) {
        mutableStateOf(false)
    }

    // PROFILE AND ASSESSMENT STATE

    var savedProfile by remember(uid) {
        mutableStateOf<LearningCoachProfile?>(null)
    }

    var latestAssessment by remember(uid) {
        mutableStateOf<InitialAssessmentResult?>(null)
    }

    var isLoadingProfile by remember(uid) {
        mutableStateOf(uid != null)
    }

    var profileLoadMessage by remember(uid) {
        mutableStateOf("")
    }

    // GENERATION STATE

    var isGenerating by remember(uid) {
        mutableStateOf(false)
    }

    var errorMessage by remember(uid) {
        mutableStateOf<String?>(null)
    }

    var warningMessage by remember(uid) {
        mutableStateOf("")
    }

    var generatedPlan by remember(uid) {
        mutableStateOf<LearningPlan?>(null)
    }

    // ACCOUNT VALIDATION

    fun isCurrentAccountValid(): Boolean {
        return uid != null && auth.currentUser?.uid == uid
    }

    // LOAD PROFILE AND LATEST ASSESSMENT

    LaunchedEffect(uid) {
        savedProfile = null
        latestAssessment = null

        if (uid == null) {
            isLoadingProfile = false
            profileLoadMessage =
                "Sign in to load your saved learning profile."
            return@LaunchedEffect
        }

        isLoadingProfile = true
        profileLoadMessage = ""

        try {
            val loadedProfile = withContext(Dispatchers.IO) {
                storage.loadLearningCoachProfile()
            }

            if (!isCurrentAccountValid()) {
                return@LaunchedEffect
            }

            val loadedAssessment = withContext(Dispatchers.IO) {
                storage.getLatestInitialAssessmentResult()
            }

            if (!isCurrentAccountValid()) {
                return@LaunchedEffect
            }

            savedProfile = loadedProfile
            latestAssessment = loadedAssessment

            if (loadedProfile != null && !hasEditedInputs) {
                goal = loadedProfile.learningGoal
                subject = loadedProfile.subject

                val savedLevel =
                    loadedProfile.currentLevel.displayName

                currentLevel = learningLevels.firstOrNull {
                    it.equals(savedLevel, ignoreCase = true)
                } ?: "Beginner"

                targetDaysText =
                    loadedProfile.targetDays.toString()

                dailyMinutesText =
                    loadedProfile.dailyStudyMinutes.toString()
            }

            profileLoadMessage =
                if (loadedProfile == null) {
                    "No saved Learning Coach profile found. " +
                        "You can still create a plan manually."
                } else {
                    "Your saved learning profile has been loaded."
                }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (isCurrentAccountValid()) {
                profileLoadMessage =
                    "Could not load your saved profile. " +
                        "You can still enter your details manually."
            }
        } finally {
            if (isCurrentAccountValid()) {
                isLoadingProfile = false
            }
        }
    }

    // INPUT VALIDATION

    val targetDays = targetDaysText.toIntOrNull()
    val dailyMinutes = dailyMinutesText.toIntOrNull()

    val inputIsValid =
        uid != null &&
            goal.isNotBlank() &&
            subject.isNotBlank() &&
            currentLevel in learningLevels &&
            targetDays != null &&
            targetDays in 1..90 &&
            dailyMinutes != null &&
            dailyMinutes in 10..600

    // GENERATE AND SAVE PLAN

    fun generatePlan() {
        val generationUid = uid

        if (generationUid == null) {
            errorMessage = "Please sign in first."
            return
        }

        if (!isCurrentAccountValid()) {
            errorMessage =
                "Your account changed. Please reopen this screen."
            return
        }

        if (isGenerating || isLoadingProfile) {
            return
        }

        val days = targetDays
        val minutes = dailyMinutes

        if (goal.isBlank()) {
            errorMessage = "Enter your learning goal."
            return
        }

        if (subject.isBlank()) {
            errorMessage = "Enter a subject or skill."
            return
        }

        if (currentLevel !in learningLevels) {
            errorMessage = "Select your current learning level."
            return
        }

        if (days == null || days !in 1..90) {
            errorMessage =
                "Duration must be between 1 and 90 days."
            return
        }

        if (minutes == null || minutes !in 10..600) {
            errorMessage =
                "Daily study time must be between 10 and 600 minutes."
            return
        }

        val requestedGoal = goal.trim()
        val requestedSubject = subject.trim()
        val requestedLevel = currentLevel
        val assessmentForGeneration = latestAssessment

        isGenerating = true
        errorMessage = null
        warningMessage = ""
        generatedPlan = null

        coroutineScope.launch {
            try {
                val plan = withContext(Dispatchers.IO) {
                    LearningPlanGenerator().generatePlan(
                        goal = requestedGoal,
                        subject = requestedSubject,
                        currentLevel = requestedLevel,
                        targetDays = days,
                        dailyStudyMinutes = minutes,
                        assessmentResult = assessmentForGeneration
                    )
                }

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                if (plan.days.size != days) {
                    throw IllegalStateException(
                        "The AI generated ${plan.days.size} days " +
                            "instead of the requested $days. Please try again."
                    )
                }

                val validation = withContext(Dispatchers.Default) {
                    LearningPlanValidator().validate(
                        plan = plan,
                        assessmentResult = assessmentForGeneration
                    )
                }

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                if (!validation.isValid) {
                    throw IllegalStateException(
                        "The generated learning plan failed validation:\n" +
                            validation.errors.joinToString("\n")
                    )
                }

                warningMessage = validation.warnings
                    .takeIf { it.isNotEmpty() }
                    ?.joinToString("\n") { "• $it" }
                    ?: ""

                withContext(Dispatchers.IO) {
                    if (!isCurrentAccountValid()) {
                        throw CancellationException(
                            "Account changed during plan generation."
                        )
                    }

                    storage.saveLearningPlan(plan)
                }

                if (!isCurrentAccountValid()) {
                    return@launch
                }

                generatedPlan = plan
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (isCurrentAccountValid()) {
                    errorMessage = e.message
                        ?.takeIf { it.isNotBlank() }
                        ?: "Could not generate your plan. " +
                            "Check your connection and try again."
                }
            } finally {
                if (isCurrentAccountValid()) {
                    isGenerating = false
                }
            }
        }
    }

    // SCREEN

    ScaiScreen(
        modifier = modifier,
        scrollable = true
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            // HEADER

            ScaiTopBar(
                title = "Create learning plan",
                subtitle = "Build a roadmap around your goal",
                onBackClick = if (showBackButton) onBackClick else null
            )

            // INTRODUCTION

            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Plan your learning",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = "Tell us what you want to learn, where you are " +
                        "starting, and how much time you can commit.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            ScaiDivider()

            // PROFILE STATUS

            if (isLoadingProfile) {
                ScaiLoadingIndicator(
                    message = "Loading your learning profile..."
                )
            } else if (profileLoadMessage.isNotBlank()) {
                ScaiCard {
                    Text(
                        text = profileLoadMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // ASSESSMENT STATUS

            if (latestAssessment != null) {
                ScaiCard {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Diagnostic assessment available",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.titleSmall
                        )

                        Text(
                            text = "Your latest assessment will help " +
                                "personalize this learning plan.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // LEARNING GOAL

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ScaiSectionTitle(
                    title = "Learning objective",
                    description = "Define the outcome you want to achieve."
                )

                ScaiTextField(
                    value = goal,
                    onValueChange = {
                        goal = it
                        hasEditedInputs = true
                        errorMessage = null
                        generatedPlan = null
                    },
                    label = "What do you want to achieve?",
                    placeholder = "e.g. Learn conversational English",
                    singleLine = false,
                    minLines = 2,
                    maxLines = 4,
                    enabled = !isGenerating
                )
            }

            // SUBJECT OR SKILL

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ScaiSectionTitle(
                    title = "Subject or skill",
                    description = "Choose the area you want to focus on."
                )

                ScaiTextField(
                    value = subject,
                    onValueChange = {
                        subject = it
                        hasEditedInputs = true
                        errorMessage = null
                        generatedPlan = null
                    },
                    label = "Subject or skill",
                    placeholder = "e.g. Mathematics, Python, Spanish",
                    enabled = !isGenerating
                )
            }

            // CURRENT LEVEL

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ScaiSectionTitle(
                    title = "Current knowledge level",
                    description = "Choose the level that best describes you."
                )

                Box(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isGenerating) {
                                levelMenuExpanded = !levelMenuExpanded
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.outline
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(
                                horizontal = 16.dp,
                                vertical = 17.dp
                            ),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(
                                    text = "Your current level",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Text(
                                    text = currentLevel,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Text(
                                text = if (levelMenuExpanded) "▲" else "▼",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = levelMenuExpanded,
                        onDismissRequest = {
                            levelMenuExpanded = false
                        },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        learningLevels.forEach { level ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = level,
                                        fontWeight = if (currentLevel == level) {
                                            FontWeight.SemiBold
                                        } else {
                                            FontWeight.Normal
                                        }
                                    )
                                },
                                onClick = {
                                    currentLevel = level
                                    levelMenuExpanded = false
                                    hasEditedInputs = true
                                    errorMessage = null
                                    generatedPlan = null
                                }
                            )
                        }
                    }
                }
            }

            // STUDY SCHEDULE

            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ScaiSectionTitle(
                    title = "Study commitment",
                    description = "Set a realistic duration and daily study time."
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Duration",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = targetDaysText,
                            onValueChange = {
                                targetDaysText = it.filter(Char::isDigit)
                                hasEditedInputs = true
                                errorMessage = null
                                generatedPlan = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = {
                                Text("7")
                            },
                            suffix = {
                                Text("days")
                            },
                            singleLine = true,
                            enabled = !isGenerating,
                            shape = RoundedCornerShape(12.dp),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Next
                            )
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Daily study time",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = dailyMinutesText,
                            onValueChange = {
                                dailyMinutesText = it.filter(Char::isDigit)
                                hasEditedInputs = true
                                errorMessage = null
                                generatedPlan = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = {
                                Text("60")
                            },
                            suffix = {
                                Text("min")
                            },
                            singleLine = true,
                            enabled = !isGenerating,
                            shape = RoundedCornerShape(12.dp),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            )
                        )
                    }
                }

                Text(
                    text = "Duration: 1–90 days  •  Daily study: 10–600 minutes",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // COMMITMENT SUMMARY

            ScaiCard {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Your study commitment",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    if (
                        targetDays != null &&
                        targetDays in 1..90 &&
                        dailyMinutes != null &&
                        dailyMinutes in 10..600
                    ) {
                        val totalMinutes =
                            targetDays.toLong() * dailyMinutes

                        SummaryRow(
                            "Learning duration",
                            "$targetDays days"
                        )

                        SummaryRow(
                            "Daily study time",
                            "$dailyMinutes minutes"
                        )

                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outlineVariant
                        )

                        SummaryRow(
                            "Total planned time",
                            "${totalMinutes / 60}h ${totalMinutes % 60}m"
                        )
                    } else {
                        Text(
                            text = "Enter a valid duration and daily study time " +
                                "to see your total commitment.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // ERROR MESSAGE

            if (!errorMessage.isNullOrBlank()) {
                ScaiCard {
                    Text(
                        text = errorMessage.orEmpty(),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            // VALIDATION WARNINGS

            if (warningMessage.isNotBlank()) {
                ScaiCard {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Plan notes",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.titleSmall
                        )

                        Text(
                            text = warningMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // GENERATE BUTTON

            ScaiPrimaryButton(
                text = if (isGenerating) {
                    "Generating your plan..."
                } else {
                    "Generate learning plan"
                },
                onClick = {
                    generatePlan()
                },
                enabled = !isGenerating &&
                    !isLoadingProfile &&
                    inputIsValid,
                loading = isGenerating
            )

            if (uid == null) {
                Text(
                    text = "Sign in to create and save a learning plan.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            if (isGenerating) {
                Text(
                    text = "Creating your day-wise roadmap. " +
                        "Generation may take a little time.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // GENERATED PLAN PREVIEW

            generatedPlan?.let { plan ->
                ScaiDivider()

                ScaiSectionTitle(
                    title = "Your plan is ready",
                    description = "Review the overview before opening your plan."
                )

                ScaiCard {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = plan.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )

                        Text(
                            text = plan.goal,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outlineVariant
                        )

                        SummaryRow("Subject", plan.subject)

                        SummaryRow(
                            "Current level",
                            plan.currentLevel
                        )

                        SummaryRow(
                            "Duration",
                            "${plan.totalDays} days"
                        )

                        SummaryRow(
                            "Daily study",
                            "${plan.dailyStudyMinutes} minutes"
                        )

                        SummaryRow(
                            "Total activities",
                            plan.days.sumOf {
                                it.activities.size
                            }.toString()
                        )

                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outlineVariant
                        )

                        Text(
                            text = "Day-by-day preview",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.titleSmall
                        )

                        plan.days.take(3).forEach { day ->
                            Column(
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Day ${day.dayNumber}: ${day.title}",
                                    fontWeight = FontWeight.Medium,
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                Text(
                                    text = "${day.estimatedMinutes} minutes · " +
                                        "${day.activities.size} activities",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (plan.totalDays > 3) {
                            Text(
                                text = "And ${plan.totalDays - 3} more days",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        ScaiPrimaryButton(
                            text = "Open full learning plan",
                            onClick = {
                                if (isCurrentAccountValid()) {
                                    onPlanGenerated(plan)
                                }
                            },
                            enabled = isCurrentAccountValid()
                        )
                    }
                }
            }
        }
    }
}

// =====================================================
// PLAN SUMMARY ROW
// =====================================================

@Composable
private fun SummaryRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.width(12.dp))

        Text(
            text = value,
            fontWeight = FontWeight.Medium,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
