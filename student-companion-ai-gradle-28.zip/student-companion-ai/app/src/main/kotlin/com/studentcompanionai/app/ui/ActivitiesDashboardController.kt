
package com.studentcompanionai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiSectionTitle
import com.studentcompanionai.app.ui.components.ScaiTopBar

class ActivitiesDashboardController {

    data class Overview(
        val taskCount: Int,
        val subjectCount: Int,
        val focusMinutes: Int
    )

    data class ActiveFocus(
        val isActive: Boolean = false,
        val isPaused: Boolean = false,
        val remainingSeconds: Int = 0,
        val subjectName: String? = null,
        val taskTitle: String? = null
    )

    data class Actions(
        val onSearchClick: () -> Unit,
        val onSettingsClick: () -> Unit,
        val onFocusClick: () -> Unit,
        val onSubjectsClick: () -> Unit,
        val onTestsClick: () -> Unit,
        val onTasksClick: () -> Unit,
        val onScheduleClick: () -> Unit,
        val onRevisionClick: () -> Unit,
        val onLearningPlansClick: () -> Unit = {},
        val onResourceDiscoveryClick: () -> Unit = {},
        val onResourceLibraryClick: () -> Unit = {}
    )
}

@Composable
fun ActivitiesDashboardScreen(
    overview: ActivitiesDashboardController.Overview,
    activeFocus: ActivitiesDashboardController.ActiveFocus =
        ActivitiesDashboardController.ActiveFocus(),
    actions: ActivitiesDashboardController.Actions,
    onMenuClick: () -> Unit = {}
) {
    ScaiScreen(
        scrollable = true
    ) {
        ScaiTopBar(
            title = "Activities",
            subtitle = "Manage your learning",
            onMenuClick = onMenuClick
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScaiSectionTitle(
            title = "Today's overview",
            description = "Your learning activity at a glance"
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OverviewMetric(
                title = "Tasks",
                value = overview.taskCount.coerceAtLeast(0).toString(),
                modifier = Modifier.weight(1f)
            )

            OverviewMetric(
                title = "Subjects",
                value = overview.subjectCount.coerceAtLeast(0).toString(),
                modifier = Modifier.weight(1f)
            )

            OverviewMetric(
                title = "Focus",
                value = formatFocusTime(overview.focusMinutes),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Focus session",
            description = "Build consistency, one session at a time"
        )

        Spacer(modifier = Modifier.height(12.dp))

        FocusSessionCard(
            activeFocus = activeFocus,
            onClick = actions.onFocusClick
        )

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Learning",
            description = "Your core learning tools"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ActivityActionCard(
            title = "My subjects",
            description = "Organize the subjects you are studying",
            onClick = actions.onSubjectsClick
        )

        ActivityActionCard(
            title = "Learning plans",
            description = "View your personalized learning plans",
            onClick = actions.onLearningPlansClick
        )

        ActivityActionCard(
            title = "My tasks",
            description = "Manage your pending and completed tasks",
            onClick = actions.onTasksClick
        )

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Resources",
            description = "Discover and organize learning material"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ActivityActionCard(
            title = "Discover resources",
            description = "Find useful material for your learning goals",
            onClick = actions.onResourceDiscoveryClick
        )

        ActivityActionCard(
            title = "Resource library",
            description = "Access your saved learning resources",
            onClick = actions.onResourceLibraryClick
        )

        Spacer(modifier = Modifier.height(28.dp))
    }
}

@Composable
private fun OverviewMetric(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    ScaiCard(
        modifier = modifier
    ) {
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = value,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 21.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun FocusSessionCard(
    activeFocus: ActivitiesDashboardController.ActiveFocus,
    onClick: () -> Unit
) {
    val subject = activeFocus.subjectName
        ?.takeIf { it.isNotBlank() }
        ?: "Independent study"

    val task = activeFocus.taskTitle
        ?.takeIf { it.isNotBlank() }

    val remaining = formatRemainingTime(
        activeFocus.remainingSeconds
    )

    val title = when {
        !activeFocus.isActive ->
            "Ready for a focus session?"

        activeFocus.remainingSeconds <= 0 ->
            "Your focus session has ended"

        activeFocus.isPaused ->
            "Focus session paused"

        else ->
            "Focus session in progress"
    }

    val description = when {
        !activeFocus.isActive ->
            "Build consistency, one session at a time."

        else -> buildString {
            append(subject)

            if (task != null) {
                append(" • ")
                append(task)
            }

            append(" • ")

            when {
                activeFocus.remainingSeconds <= 0 ->
                    append("Time is up")

                activeFocus.isPaused ->
                    append("Paused at $remaining remaining")

                else ->
                    append("$remaining remaining")
            }
        }
    }

    val buttonText = when {
        !activeFocus.isActive ->
            "Start focus session"

        activeFocus.remainingSeconds <= 0 ->
            "View focus session"

        activeFocus.isPaused ->
            "Resume focus session"

        else ->
            "Continue focus session"
    }

    ScaiCard(
        onClick = onClick
    ) {
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = description,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
            lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(16.dp))
        ScaiDivider()
        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = buttonText,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            Text(
                text = "›",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 25.sp
            )
        }
    }
}

@Composable
private fun ActivityActionCard(
    title: String,
    description: String,
    onClick: () -> Unit
) {
    ScaiCard(
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = description,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Text(
                text = "›",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 25.sp
            )
        }
    }

    Spacer(modifier = Modifier.height(9.dp))
}

private fun formatRemainingTime(seconds: Int): String {
    val safeSeconds = seconds.coerceAtLeast(0)
    val minutes = safeSeconds / 60
    val remainingSeconds = safeSeconds % 60

    return String.format(
        "%02d:%02d",
        minutes,
        remainingSeconds
    )
}

private fun formatFocusTime(minutes: Int): String {
    val safeMinutes = minutes.coerceAtLeast(0)

    return if (safeMinutes >= 60) {
        val hours = safeMinutes / 60
        val remainingMinutes = safeMinutes % 60

        if (remainingMinutes == 0) {
            "${hours}h"
        } else {
            "${hours}h ${remainingMinutes}m"
        }
    } else {
        "${safeMinutes}m"
    }
}
