
package com.studentcompanionai.app.ui.onboarding

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private const val OTHER_OPTION = "Other"
private const val SPECIALIZATION_SEPARATOR = " | "

private val educationCategories = listOf(
    "School",
    "Junior College",
    "Undergraduate",
    "Postgraduate",
    "Programming",
    "Language Learning",
    "Independent Learning"
)

private val schoolLevels = listOf(
    "1st Standard",
    "2nd Standard",
    "3rd Standard",
    "4th Standard",
    "5th Standard",
    "6th Standard",
    "7th Standard",
    "8th Standard",
    "9th Standard",
    "10th Standard",
    OTHER_OPTION
)

private val juniorCollegeLevels = listOf(
    "11th Standard",
    "12th Standard",
    OTHER_OPTION
)

private val undergraduateQualifications = listOf(
    "B.Tech",
    "B.E.",
    "B.Sc.",
    "BCA",
    "B.Com",
    "B.A.",
    "BBA",
    "B.Pharm",
    OTHER_OPTION
)

private val postgraduateQualifications = listOf(
    "M.Tech",
    "M.E.",
    "M.Sc.",
    "MCA",
    "M.Com",
    "M.A.",
    "MBA",
    "M.Pharm",
    OTHER_OPTION
)

private val schoolBoards = listOf(
    "CBSE",
    "ICSE",
    "State Board",
    "IB",
    "Cambridge",
    OTHER_OPTION
)

private val universityOptions = listOf(
    "State University",
    "Central University",
    "Deemed University",
    "Private University",
    "Autonomous Institution",
    OTHER_OPTION
)

private val juniorCollegeStreams = listOf(
    "Science",
    "Commerce",
    "Arts / Humanities",
    "Vocational",
    OTHER_OPTION
)

private val engineeringSpecializations = listOf(
    "Computer Science Engineering",
    "Artificial Intelligence and Machine Learning",
    "Artificial Intelligence and Data Science",
    "Information Technology",
    "Electronics and Communication",
    "Electrical Engineering",
    "Mechanical Engineering",
    "Civil Engineering",
    OTHER_OPTION
)

private val scienceSpecializations = listOf(
    "Physics",
    "Chemistry",
    "Mathematics",
    "Biology",
    "Computer Science",
    "Statistics",
    OTHER_OPTION
)

private val commerceSpecializations = listOf(
    "Accounting",
    "Finance",
    "Banking",
    "Economics",
    "Business Studies",
    OTHER_OPTION
)

private val artsSpecializations = listOf(
    "History",
    "Geography",
    "Political Science",
    "Psychology",
    "Sociology",
    "English",
    OTHER_OPTION
)

private val managementSpecializations = listOf(
    "Marketing",
    "Human Resources",
    "Finance",
    "Operations",
    "Business Analytics",
    OTHER_OPTION
)

private val pharmacySpecializations = listOf(
    "Pharmaceutics",
    "Pharmacology",
    "Pharmaceutical Chemistry",
    "Pharmacognosy",
    "Clinical Pharmacy",
    OTHER_OPTION
)

private val computerSpecializations = listOf(
    "Software Development",
    "Web Development",
    "Android Development",
    "Artificial Intelligence",
    "Machine Learning",
    "Data Science",
    "Cybersecurity",
    "Cloud Computing",
    OTHER_OPTION
)

private val vocationalSpecializations = listOf(
    "Computer Applications",
    "Electronics",
    "Agriculture",
    "Business Studies",
    OTHER_OPTION
)

private val programmingAreas = listOf(
    "Web Development",
    "Android Development",
    "iOS Development",
    "Artificial Intelligence",
    "Machine Learning",
    "Data Science",
    "Cybersecurity",
    "Cloud Computing",
    "Game Development",
    "Software Development",
    OTHER_OPTION
)

private val programmingSkills = listOf(
    "Python",
    "Java",
    "Kotlin",
    "C",
    "C++",
    "C#",
    "JavaScript",
    "TypeScript",
    "HTML and CSS",
    "SQL",
    OTHER_OPTION
)

private val languageOptions = listOf(
    "English",
    "Hindi",
    "Marathi",
    "Sanskrit",
    "French",
    "German",
    "Spanish",
    "Japanese",
    "Korean",
    "Chinese",
    OTHER_OPTION
)

private val independentLearningAreas = listOf(
    "Technology",
    "Business",
    "Finance",
    "Design",
    "Communication",
    "Science",
    "Personal Development",
    "Creative Skills",
    OTHER_OPTION
)

private val learningLevels = listOf(
    "Beginner",
    "Intermediate",
    "Advanced",
    "Expert",
    OTHER_OPTION
)

private fun getUndergraduateDuration(
    qualification: String
): Int {
    return when (qualification) {
        "B.Tech",
        "B.E.",
        "B.Pharm" -> 4

        "B.Sc.",
        "BCA",
        "B.Com",
        "B.A.",
        "BBA",
        OTHER_OPTION -> 3

        else -> 3
    }
}

private fun getPostgraduateDuration(
    qualification: String
): Int {
    return 2
}

private fun getSpecializationOptions(
    category: String,
    qualification: String,
    stream: String
): List<String> {

    return when (category) {

        "School" -> emptyList()

        "Junior College" -> when (stream) {
            "Science" -> scienceSpecializations
            "Commerce" -> commerceSpecializations
            "Arts / Humanities" -> artsSpecializations
            "Vocational" -> vocationalSpecializations
            else -> emptyList()
        }

        "Undergraduate",
        "Postgraduate" -> when (qualification) {

            "B.Tech",
            "B.E.",
            "M.Tech",
            "M.E." -> engineeringSpecializations

            "B.Sc.",
            "M.Sc." -> scienceSpecializations

            "BCA",
            "MCA" -> computerSpecializations

            "B.Com",
            "M.Com" -> commerceSpecializations

            "B.A.",
            "M.A." -> artsSpecializations

            "BBA",
            "MBA" -> managementSpecializations

            "B.Pharm",
            "M.Pharm" -> pharmacySpecializations

            else -> listOf(OTHER_OPTION)
        }

        "Programming" -> programmingSkills

        "Language Learning" -> languageOptions

        "Independent Learning" -> listOf(
            "Communication",
            "Leadership",
            "Problem Solving",
            "Critical Thinking",
            OTHER_OPTION
        )

        else -> emptyList()
    }
}

@Composable
fun EducationScreen(
    initialCategory: String = "School",
    initialQualification: String = "",
    initialStream: String = "",
    initialSpecialization: String = "",
    initialAcademicYear: String = "",
    initialSemester: String = "",
    initialInstitution: String = "",
    initialBoardOrUniversity: String = "",
    initialSubjects: List<String> = emptyList(),
    onBack: () -> Unit,
    onContinue: (
        category: String,
        qualification: String,
        stream: String,
        specialization: String,
        academicYear: String,
        semester: String,
        institution: String,
        boardOrUniversity: String,
        subjects: List<String>
    ) -> Unit
) {

    // Migrate previously saved 11th / 12th School profiles.
    val migratedCategory = remember(
        initialCategory,
        initialQualification
    ) {
        if (
            initialCategory == "School" &&
            initialQualification in listOf(
                "11th Standard",
                "12th Standard"
            )
        ) {
            "Junior College"
        } else {
            initialCategory
        }
    }

    var category by rememberSaveable {
        mutableStateOf(migratedCategory)
    }

    var qualification by rememberSaveable {
        mutableStateOf(initialQualification)
    }

    var stream by rememberSaveable {
        mutableStateOf(
            if (
                migratedCategory == "Undergraduate" ||
                migratedCategory == "Postgraduate"
            ) {
                ""
            } else {
                initialStream
            }
        )
    }

    var specialization by rememberSaveable {
        mutableStateOf(initialSpecialization)
    }

    var academicYear by rememberSaveable {
        mutableStateOf(
            if (migratedCategory == "Junior College") {
                ""
            } else {
                initialAcademicYear
            }
        )
    }

    var semester by rememberSaveable {
        mutableStateOf(
            if (migratedCategory == "Junior College") {
                ""
            } else {
                initialSemester
            }
        )
    }

    var institution by rememberSaveable {
        mutableStateOf(initialInstitution)
    }

    var boardOrUniversity by rememberSaveable {
        mutableStateOf(initialBoardOrUniversity)
    }

    var subjectInput by rememberSaveable {
        mutableStateOf("")
    }

    var selectedSubjects by rememberSaveable {
        mutableStateOf(initialSubjects.toList())
    }

    var selectedJuniorCollegeSpecializations by rememberSaveable {
        mutableStateOf(
            initialSpecialization
                .split(SPECIALIZATION_SEPARATOR, ", ")
                .map { it.trim() }
                .filter { it.isNotBlank() }
        )
    }

    var otherSpecialization by rememberSaveable {
        mutableStateOf("")
    }

    val isSchool = category == "School"
    val isCollege = category == "Junior College"
    val isUndergraduate = category == "Undergraduate"
    val isPostgraduate = category == "Postgraduate"
    val isHigherEducation = isUndergraduate || isPostgraduate
    val isProgramming = category == "Programming"
    val isLanguageLearning = category == "Language Learning"

    // ---------------------------------------------------------
    // QUALIFICATION OPTIONS
    // ---------------------------------------------------------

    val qualificationOptions = when (category) {
        "School" -> schoolLevels
        "Junior College" -> juniorCollegeLevels
        "Undergraduate" -> undergraduateQualifications
        "Postgraduate" -> postgraduateQualifications
        "Programming",
        "Language Learning",
        "Independent Learning" -> learningLevels
        else -> listOf(OTHER_OPTION)
    }

    // ---------------------------------------------------------
    // STREAM OPTIONS
    // No stream for undergraduate or postgraduate degrees.
    // ---------------------------------------------------------

    val streamOptions = when (category) {
        "Junior College" -> juniorCollegeStreams
        "Programming" -> programmingAreas
        "Language Learning" -> listOf(
            "European Languages",
            "Indian Languages",
            "Asian Languages",
            OTHER_OPTION
        )
        "Independent Learning" -> independentLearningAreas
        else -> emptyList()
    }

    // ---------------------------------------------------------
    // SPECIALIZATION
    // UG / PG specialization is derived from qualification.
    // ---------------------------------------------------------

    val specializationOptions = getSpecializationOptions(
        category = category,
        qualification = qualification,
        stream = stream
    )

    // ---------------------------------------------------------
    // PROGRAMME DURATION
    // ---------------------------------------------------------

    val programmeDuration = when {
        isUndergraduate ->
            getUndergraduateDuration(qualification)

        isPostgraduate ->
            getPostgraduateDuration(qualification)

        else -> 0
    }

    val academicYearOptions = when {
        isUndergraduate || isPostgraduate ->
            (1..programmeDuration).map { year ->
                when (year) {
                    1 -> "1st Year"
                    2 -> "2nd Year"
                    3 -> "3rd Year"
                    4 -> "4th Year"
                    else -> "${year}th Year"
                }
            } + OTHER_OPTION

        else -> emptyList()
    }

    val semesterCount = programmeDuration * 2

    val semesterOptions = when {
        isUndergraduate || isPostgraduate ->
            (1..semesterCount).map { "Semester $it" } + OTHER_OPTION

        else -> emptyList()
    }

    val boardOptions = when {
        isSchool || isCollege -> schoolBoards
        isHigherEducation -> universityOptions
        else -> emptyList()
    }

    val juniorCollegeSpecializationValue = buildList {

        selectedJuniorCollegeSpecializations
            .filterNot { it == OTHER_OPTION }
            .forEach { add(it) }

        if (OTHER_OPTION in selectedJuniorCollegeSpecializations) {
            if (otherSpecialization.isNotBlank()) {
                add(otherSpecialization.trim())
            } else {
                add(OTHER_OPTION)
            }
        }

    }.distinct().joinToString(SPECIALIZATION_SEPARATOR)

    // ---------------------------------------------------------
    // SCREEN
    // ---------------------------------------------------------

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {

        TextButton(onClick = onBack) {
            Text("← Back")
        }

        Spacer(Modifier.height(12.dp))

        Text(
            text = "Your education",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(8.dp))

        Text(
            text = "Tell us what you're currently studying or learning. We'll use this to make your learning experience relevant.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(26.dp))

        // -----------------------------------------------------
        // CATEGORY
        // -----------------------------------------------------

        SectionTitle("What are you learning?")

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            educationCategories.chunked(2).forEach { categoryRow ->

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {

                    categoryRow.forEach { option ->

                        FilterChip(
                            selected = category == option,
                            onClick = {

                                if (category != option) {

                                    category = option
                                    qualification = ""
                                    stream = ""
                                    specialization = ""
                                    selectedJuniorCollegeSpecializations = emptyList()
                                    otherSpecialization = ""
                                    academicYear = ""
                                    semester = ""
                                    boardOrUniversity = ""
                                }
                            },
                            label = {
                                Text(option)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // -----------------------------------------------------
        // QUALIFICATION
        // -----------------------------------------------------

        SectionTitle(
            when {
                isSchool -> "Your standard"
                isCollege -> "Your standard"
                isUndergraduate -> "Your undergraduate degree"
                isPostgraduate -> "Your postgraduate degree"
                else -> "Your current level"
            }
        )

        DropdownOrOtherField(
            value = qualification,
            options = qualificationOptions,
            label = "Select qualification or level",
            onValueChange = {

                if (qualification != it) {
                    qualification = it
                    stream = ""
                    specialization = ""
                    selectedJuniorCollegeSpecializations = emptyList()
                    otherSpecialization = ""
                    academicYear = ""
                    semester = ""
                }
            }
        )

        Spacer(Modifier.height(22.dp))

        // -----------------------------------------------------
        // STREAM / FIELD
        // -----------------------------------------------------

        if (streamOptions.isNotEmpty()) {

            SectionTitle(
                when {
                    isCollege -> "Stream"
                    isProgramming -> "Programming area"
                    isLanguageLearning -> "Language category"
                    else -> "Learning area"
                }
            )

            DropdownOrOtherField(
                value = stream,
                options = streamOptions,
                label = "Select stream or field",
                onValueChange = {

                    if (stream != it) {
                        stream = it
                        specialization = ""
                        selectedJuniorCollegeSpecializations = emptyList()
                        otherSpecialization = ""
                    }
                }
            )

            Spacer(Modifier.height(22.dp))
        }

        // -----------------------------------------------------
        // SPECIALIZATION
        // -----------------------------------------------------

        if (specializationOptions.isNotEmpty()) {

            SectionTitle(
                when {
                    isCollege -> "Subjects / specializations"
                    isProgramming -> "Programming language / skill"
                    isLanguageLearning -> "Language to learn"
                    else -> "Specialization"
                }
            )

            if (isCollege) {

                MultiSelectDropdownField(
                    selectedValues = selectedJuniorCollegeSpecializations,
                    options = specializationOptions,
                    label = "Select subjects or specializations",
                    onSelectionChange = {
                        selectedJuniorCollegeSpecializations = it
                    }
                )

                if (OTHER_OPTION in selectedJuniorCollegeSpecializations) {

                    Spacer(Modifier.height(10.dp))

                    OutlinedTextField(
                        value = otherSpecialization,
                        onValueChange = {
                            otherSpecialization = it
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = {
                            Text("Enter another subject")
                        },
                        placeholder = {
                            Text("Type your subject")
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                }

            } else {

                DropdownOrOtherField(
                    value = specialization,
                    options = specializationOptions,
                    label = "Select specialization",
                    onValueChange = {
                        specialization = it
                    }
                )
            }

            Spacer(Modifier.height(22.dp))
        }

        // -----------------------------------------------------
        // ACADEMIC YEAR
        // UG: 3 or 4 years based on degree.
        // PG: 2 years.
        // -----------------------------------------------------

        if (academicYearOptions.isNotEmpty()) {

            SectionTitle("Academic year")

            DropdownOrOtherField(
                value = academicYear,
                options = academicYearOptions,
                label = "Select academic year",
                onValueChange = {
                    academicYear = it
                }
            )

            Spacer(Modifier.height(22.dp))
        }

        // -----------------------------------------------------
        // SEMESTER
        // UG: 6 or 8 semesters.
        // PG: 4 semesters.
        // -----------------------------------------------------

        if (semesterOptions.isNotEmpty()) {

            SectionTitle("Semester")

            DropdownOrOtherField(
                value = semester,
                options = semesterOptions,
                label = "Select semester",
                onValueChange = {
                    semester = it
                }
            )

            Spacer(Modifier.height(22.dp))
        }

        // -----------------------------------------------------
        // INSTITUTION
        // -----------------------------------------------------

        SectionTitle("Institution (optional)")

        OutlinedTextField(
            value = institution,
            onValueChange = {
                institution = it
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("School / College / Institution")
            },
            placeholder = {
                Text("Enter institution name")
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp)
        )

        Spacer(Modifier.height(22.dp))

        // -----------------------------------------------------
        // BOARD / UNIVERSITY
        // -----------------------------------------------------

        if (boardOptions.isNotEmpty()) {

            SectionTitle(
                if (isSchool || isCollege) {
                    "Board (optional)"
                } else {
                    "University (optional)"
                }
            )

            DropdownOrOtherField(
                value = boardOrUniversity,
                options = boardOptions,
                label = "Select board or university",
                onValueChange = {
                    boardOrUniversity = it
                }
            )

        } else {

            SectionTitle("Platform / Provider (optional)")

            OutlinedTextField(
                value = boardOrUniversity,
                onValueChange = {
                    boardOrUniversity = it
                },
                modifier = Modifier.fillMaxWidth(),
                label = {
                    Text("Platform / Provider")
                },
                placeholder = {
                    Text("e.g. Coursera, Udemy, YouTube")
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
        }

        Spacer(Modifier.height(22.dp))

        // -----------------------------------------------------
        // SUBJECTS / TOPICS
        // -----------------------------------------------------

        SectionTitle("Subjects or topics")

        Text(
            text = "Add the subjects or topics you want SCAI to consider.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = subjectInput,
            onValueChange = {
                subjectInput = it
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Add a subject or topic")
            },
            placeholder = {
                Text("e.g. Mathematics, Python, Physics")
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp)
        )

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {

                val subject = subjectInput.trim()

                if (
                    subject.isNotBlank() &&
                    !selectedSubjects.any {
                        it.equals(subject, ignoreCase = true)
                    }
                ) {
                    selectedSubjects = selectedSubjects + subject
                    subjectInput = ""
                }
            },
            enabled = subjectInput.isNotBlank()
        ) {
            Text("Add subject")
        }

        if (selectedSubjects.isNotEmpty()) {

            Spacer(Modifier.height(12.dp))

            selectedSubjects.forEach { subject ->

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {

                    Text(
                        text = subject,
                        style = MaterialTheme.typography.bodyLarge
                    )

                    TextButton(
                        onClick = {
                            selectedSubjects =
                                selectedSubjects.filterNot { it == subject }
                        }
                    ) {
                        Text("Remove")
                    }
                }
            }
        }

        Spacer(Modifier.height(30.dp))

        // -----------------------------------------------------
        // CONTINUE
        // Existing callback signature preserved.
        // -----------------------------------------------------

        Button(
            onClick = {

                val finalStream = if (isHigherEducation) {
                    ""
                } else {
                    stream.trim()
                }

                val finalSpecialization = when {
                    isCollege -> juniorCollegeSpecializationValue
                    else -> specialization.trim()
                }

                onContinue(
                    category,
                    qualification.trim(),
                    finalStream,
                    finalSpecialization,
                    academicYear.trim(),
                    semester.trim(),
                    institution.trim(),
                    boardOrUniversity.trim(),
                    selectedSubjects.toList()
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                text = "Continue",
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(Modifier.height(16.dp))
    }
}

// =============================================================
// MULTI-SELECT DROPDOWN
// =============================================================

@Composable
private fun MultiSelectDropdownField(
    selectedValues: List<String>,
    options: List<String>,
    label: String,
    onSelectionChange: (List<String>) -> Unit
) {

    var expanded by rememberSaveable {
        mutableStateOf(false)
    }

    val displayValue = selectedValues
        .filterNot { it == OTHER_OPTION }
        .joinToString(", ")
        .ifBlank {
            if (OTHER_OPTION in selectedValues) OTHER_OPTION else ""
        }

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {

        Box(
            modifier = Modifier.fillMaxWidth()
        ) {

            OutlinedTextField(
                value = displayValue,
                onValueChange = {},
                modifier = Modifier.fillMaxWidth(),
                readOnly = true,
                label = {
                    Text(label)
                },
                placeholder = {
                    Text("Choose one or more subjects")
                },
                trailingIcon = {
                    Text(if (expanded) "▲" else "▼")
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )

            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clickable {
                        expanded = !expanded
                    }
            )

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = {
                    expanded = false
                },
                modifier = Modifier.fillMaxWidth(0.95f)
            ) {

                options.distinct().forEach { option ->

                    val selected = option in selectedValues

                    DropdownMenuItem(
                        text = {

                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                Checkbox(
                                    checked = selected,
                                    onCheckedChange = null
                                )

                                Text(option)
                            }
                        },
                        onClick = {

                            val updated = if (selected) {
                                selectedValues.filterNot { it == option }
                            } else {
                                selectedValues + option
                            }

                            onSelectionChange(updated.distinct())
                        }
                    )
                }
            }
        }

        if (selectedValues.isNotEmpty()) {

            Spacer(Modifier.height(8.dp))

            Text(
                text = "${selectedValues.size} selected",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// =============================================================
// REUSABLE DROPDOWN WITH MANUAL OTHER OPTION
// =============================================================

@Composable
private fun DropdownOrOtherField(
    value: String,
    options: List<String>,
    label: String,
    onValueChange: (String) -> Unit
) {

    var expanded by rememberSaveable {
        mutableStateOf(false)
    }

    val isManualValue =
        value == OTHER_OPTION ||
            (value.isNotBlank() && value !in options)

    val displayedValue = if (isManualValue) {
        OTHER_OPTION
    } else {
        value
    }

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {

        Box(
            modifier = Modifier.fillMaxWidth()
        ) {

            OutlinedTextField(
                value = displayedValue,
                onValueChange = {},
                modifier = Modifier.fillMaxWidth(),
                readOnly = true,
                label = {
                    Text(label)
                },
                placeholder = {
                    Text("Choose an option")
                },
                trailingIcon = {
                    Text(if (expanded) "▲" else "▼")
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )

            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clickable {
                        expanded = !expanded
                    }
            )

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = {
                    expanded = false
                },
                modifier = Modifier.fillMaxWidth(0.95f)
            ) {

                options.distinct().forEach { option ->

                    DropdownMenuItem(
                        text = {
                            Text(option)
                        },
                        onClick = {
                            onValueChange(option)
                            expanded = false
                        }
                    )
                }
            }
        }

        if (isManualValue) {

            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = if (value == OTHER_OPTION) "" else value,
                onValueChange = {
                    onValueChange(it)
                },
                modifier = Modifier.fillMaxWidth(),
                label = {
                    Text("Enter manually")
                },
                placeholder = {
                    Text("Type your own option")
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
        }
    }
}

// =============================================================
// SECTION TITLE
// =============================================================

@Composable
private fun SectionTitle(title: String) {

    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold
    )

    Spacer(Modifier.height(10.dp))
}
