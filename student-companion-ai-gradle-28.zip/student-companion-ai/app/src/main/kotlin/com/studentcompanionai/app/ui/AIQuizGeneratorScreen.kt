
package com.studentcompanionai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.studentcompanionai.app.data.AdaptiveDifficulty
import com.studentcompanionai.app.data.AIQuizGenerator
import com.studentcompanionai.app.data.PerformanceTrend
import com.studentcompanionai.app.data.PracticePerformanceAnalyzer
import com.studentcompanionai.app.data.PracticePerformanceAnalysis
import com.studentcompanionai.app.data.PracticeQuiz
import com.studentcompanionai.app.data.StoredPracticeResult
import com.studentcompanionai.app.data.TopicPerformanceInsight
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiSectionTitle
import com.studentcompanionai.app.ui.components.ScaiTopBar
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIQuizGeneratorScreen(
    onBackClick: () -> Unit,
    onQuizGenerated: (PracticeQuiz) -> Unit,
    practiceHistory: List<StoredPracticeResult> = emptyList()
) {

    var subject by remember {
        mutableStateOf("Programming")
    }

    var topic by remember {
        mutableStateOf("")
    }

    var difficulty by remember {
        mutableStateOf("Beginner")
    }

    var questionCount by remember {
        mutableStateOf(10)
    }

    var adaptiveMode by remember {
        mutableStateOf(false)
    }

    var subjectExpanded by remember {
        mutableStateOf(false)
    }

    var difficultyExpanded by remember {
        mutableStateOf(false)
    }

    var formatExpanded by remember {
        mutableStateOf(false)
    }

    var questionFormat by remember {
        mutableStateOf(AIQuizGenerator.MCQ_ONLY)
    }

    var isGenerating by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    val coroutineScope = rememberCoroutineScope()

    val generator = remember {
        AIQuizGenerator()
    }

    val subjects = listOf(
        "Engineering Physics",
        "Engineering Mathematics",
        "Engineering Graphics",
        "Fundamentals of Programming Language",
        "Basic Electrical Engineering",
        "Chemistry",
        "Mechanics and Robotics",
        "Programming",
        "Computer Science",
        "English",
        "Other"
    )

    val difficulties = listOf(
        "Beginner",
        "Intermediate",
        "Advanced"
    )

    val questionCounts = listOf(
        5,
        10,
        15,
        20
    )

    val difficultyMapping = mapOf(
        "Beginner" to "EASY",
        "Intermediate" to "MEDIUM",
        "Advanced" to "HARD"
    )

    val questionFormats = listOf(
        AIQuizGenerator.MCQ_ONLY to "MCQs Only",
        AIQuizGenerator.MCQ_AND_SHORT_ANSWER to "MCQs + Short Answers",
        AIQuizGenerator.SHORT_ANSWER_ONLY to "Short Answers Only",
        AIQuizGenerator.MIXED_ASSESSMENT to "Mixed Assessment"
    )

    val formatDescription = when (questionFormat) {

        AIQuizGenerator.MCQ_ONLY ->
            "Every question will have four options and one correct answer."

        AIQuizGenerator.MCQ_AND_SHORT_ANSWER ->
            "The quiz will contain both multiple-choice and written-answer questions."

        AIQuizGenerator.SHORT_ANSWER_ONLY ->
            "Answer every question by writing your own response."

        AIQuizGenerator.MIXED_ASSESSMENT ->
            "Includes MCQs, short answers and problem-solving questions."

        else -> ""
    }

    /*
     * Subject-specific analysis.
     *
     * The selected subject is analyzed independently.
     */
    val performanceAnalysis = remember(
        practiceHistory,
        subject,
        adaptiveMode
    ) {
        if (adaptiveMode) {
            PracticePerformanceAnalyzer.analyze(
                results = practiceHistory,
                subject = subject
            )
        } else {
            null
        }
    }

    /*
     * Analyze the selected topic separately.
     */
    val topicInsight = remember(
        practiceHistory,
        subject,
        topic,
        adaptiveMode
    ) {
        if (adaptiveMode && topic.isNotBlank()) {
            PracticePerformanceAnalyzer.getTopicInsight(
                results = practiceHistory,
                subject = subject,
                topic = topic.trim()
            )
        } else {
            null
        }
    }

    val recommendedDifficulty = topicInsight
        ?.takeIf { it.isSufficientlyAnalyzed }
        ?.recommendedDifficulty
        ?: AdaptiveDifficulty.MEDIUM

    val recommendedDifficultyLabel = when (recommendedDifficulty) {
        AdaptiveDifficulty.EASY -> "Beginner"
        AdaptiveDifficulty.MEDIUM -> "Intermediate"
        AdaptiveDifficulty.HARD -> "Advanced"
    }

    val priorityTopics = performanceAnalysis
        ?.recommendedTopics
        ?.take(5)
        ?: emptyList()

    Scaffold(
        topBar = {
            ScaiTopBar(
                title = "AI Quiz Generator",
                onBackClick = if (isGenerating) {
                    null
                } else {
                    onBackClick
                }
            )
        }
    ) { innerPadding ->

        ScaiScreen(
            modifier = Modifier.padding(innerPadding)
        ) {

            ScaiSectionTitle(
                title = "Create your quiz",
                description = "Choose what you want to practise."
            )

            // SUBJECT AND TOPIC

            ScaiCard {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {

                    Text(
                        text = "Subject or skill",
                        style = MaterialTheme.typography.titleSmall
                    )

                    ExposedDropdownMenuBox(
                        expanded = subjectExpanded,
                        onExpandedChange = {
                            if (!isGenerating) {
                                subjectExpanded = !subjectExpanded
                            }
                        }
                    ) {

                        OutlinedTextField(
                            value = subject,
                            onValueChange = {},
                            readOnly = true,
                            enabled = !isGenerating,
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(
                                    expanded = subjectExpanded
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            singleLine = true
                        )

                        ExposedDropdownMenu(
                            expanded = subjectExpanded,
                            onDismissRequest = {
                                subjectExpanded = false
                            }
                        ) {

                            subjects.forEach { item ->

                                DropdownMenuItem(
                                    text = {
                                        Text(item)
                                    },
                                    onClick = {
                                        subject = item
                                        subjectExpanded = false
                                        errorMessage = null
                                    },
                                    enabled = !isGenerating
                                )
                            }
                        }
                    }

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = "Topic or chapter",
                        style = MaterialTheme.typography.titleSmall
                    )

                    OutlinedTextField(
                        value = topic,
                        onValueChange = {
                            topic = it
                            errorMessage = null
                        },
                        enabled = !isGenerating,
                        placeholder = {
                            Text(
                                "e.g. Newton's Laws, Python loops"
                            )
                        },
                        supportingText = {
                            Text(
                                "Enter the specific topic you want to practise."
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )
                }
            }

            // ADAPTIVE MODE

            ScaiCard {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Column(
                            modifier = Modifier.weight(1f)
                        ) {

                            Text(
                                text = "Adaptive Practice",
                                style = MaterialTheme.typography.titleMedium
                            )

                            Text(
                                text = "Let SCAI personalize your next quiz using your performance history.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Switch(
                            checked = adaptiveMode,
                            onCheckedChange = {
                                adaptiveMode = it
                                errorMessage = null
                            },
                            enabled = !isGenerating
                        )
                    }

                    if (adaptiveMode) {

                        HorizontalAdaptiveDivider()

                        if (practiceHistory.isEmpty()) {

                            AdaptiveInformation(
                                title = "No practice history available",
                                description = "SCAI will generate a balanced assessment. Complete quizzes to enable personalized difficulty and topic recommendations."
                            )

                        } else {

                            if (performanceAnalysis?.hasEnoughData == true) {

                                AdaptiveInformation(
                                    title = "Your subject performance",
                                    description = "${performanceAnalysis.overallAccuracy}% overall accuracy across ${performanceAnalysis.totalEvaluatedAnswers} evaluated answers."
                                )

                            } else {

                                AdaptiveInformation(
                                    title = "Collecting learning data",
                                    description = "There is not enough evaluated data for reliable adaptation yet. SCAI will avoid making unsupported assumptions."
                                )
                            }

                            if (topic.isNotBlank()) {

                                Spacer(
                                    modifier = Modifier.height(2.dp)
                                )

                                Text(
                                    text = "Selected topic analysis",
                                    style = MaterialTheme.typography.titleSmall
                                )

                                when {

                                    topicInsight == null -> {

                                        AdaptiveInformation(
                                            title = "New topic",
                                            description = "No evaluated history exists for this topic. SCAI will use the manually selected difficulty."
                                        )
                                    }

                                    !topicInsight.isSufficientlyAnalyzed -> {

                                        AdaptiveInformation(
                                            title = "Insufficient data",
                                            description = "${topicInsight.evaluatedAnswers} evaluated answer(s) found. At least 3 are needed before adapting difficulty."
                                        )
                                    }

                                    else -> {

                                        TopicPerformancePreview(
                                            insight = topicInsight,
                                            recommendedDifficultyLabel = recommendedDifficultyLabel
                                        )
                                    }
                                }
                            }

                            if (priorityTopics.isNotEmpty()) {

                                Spacer(
                                    modifier = Modifier.height(4.dp)
                                )

                                Text(
                                    text = "Topics needing attention",
                                    style = MaterialTheme.typography.titleSmall
                                )

                                priorityTopics.forEach { insight ->

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {

                                        Column(
                                            modifier = Modifier.weight(1f)
                                        ) {

                                            Text(
                                                text = insight.topic,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                                            )

                                            Text(
                                                text = insight.recommendation,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Text(
                                            text = if (
                                                insight.level.name == "INSUFFICIENT_DATA"
                                            ) {
                                                "New"
                                            } else {
                                                "${insight.accuracy}%"
                                            },
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // DIFFICULTY

            ScaiCard {

                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    Text(
                        text = "Difficulty level",
                        style = MaterialTheme.typography.titleSmall
                    )

                    ExposedDropdownMenuBox(
                        expanded = difficultyExpanded,
                        onExpandedChange = {
                            if (!isGenerating) {
                                difficultyExpanded = !difficultyExpanded
                            }
                        }
                    ) {

                        OutlinedTextField(
                            value = difficulty,
                            onValueChange = {},
                            readOnly = true,
                            enabled = !isGenerating,
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(
                                    expanded = difficultyExpanded
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            singleLine = true
                        )

                        ExposedDropdownMenu(
                            expanded = difficultyExpanded,
                            onDismissRequest = {
                                difficultyExpanded = false
                            }
                        ) {

                            difficulties.forEach { item ->

                                DropdownMenuItem(
                                    text = {
                                        Text(item)
                                    },
                                    onClick = {
                                        difficulty = item
                                        difficultyExpanded = false
                                    },
                                    enabled = !isGenerating
                                )
                            }
                        }
                    }

                    if (
                        adaptiveMode &&
                        topicInsight?.isSufficientlyAnalyzed == true
                    ) {

                        Text(
                            text = "Adaptive recommendation: $recommendedDifficultyLabel",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Text(
                            text = "Your selected difficulty will be overridden for this topic because sufficient performance data is available.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = "Number of questions",
                        style = MaterialTheme.typography.titleSmall
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {

                        questionCounts.forEach { count ->

                            FilterChip(
                                selected = questionCount == count,
                                onClick = {
                                    questionCount = count
                                },
                                enabled = !isGenerating,
                                label = {
                                    Text("$count")
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    if (
                        adaptiveMode &&
                        topicInsight?.isSufficientlyAnalyzed == true
                    ) {

                        Text(
                            text = "Recommended practice length: ${topicInsight.recommendedQuestionCount} questions. You can still choose your preferred count.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // QUESTION FORMAT

            ScaiCard {

                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    Text(
                        text = "Question format",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Text(
                        text = "Choose how you want to answer your questions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    ExposedDropdownMenuBox(
                        expanded = formatExpanded,
                        onExpandedChange = {
                            if (!isGenerating) {
                                formatExpanded = !formatExpanded
                            }
                        }
                    ) {

                        OutlinedTextField(
                            value = questionFormats.first {
                                it.first == questionFormat
                            }.second,
                            onValueChange = {},
                            readOnly = true,
                            enabled = !isGenerating,
                            label = {
                                Text("Select question format")
                            },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(
                                    expanded = formatExpanded
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            singleLine = true
                        )

                        ExposedDropdownMenu(
                            expanded = formatExpanded,
                            onDismissRequest = {
                                formatExpanded = false
                            }
                        ) {

                            questionFormats.forEach { format ->

                                DropdownMenuItem(
                                    text = {
                                        Text(format.second)
                                    },
                                    onClick = {
                                        questionFormat = format.first
                                        formatExpanded = false
                                    },
                                    enabled = !isGenerating
                                )
                            }
                        }
                    }

                    Text(
                        text = formatDescription,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // ERROR MESSAGE

            if (errorMessage != null) {

                Text(
                    text = errorMessage.orEmpty(),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // GENERATE QUIZ

            ScaiPrimaryButton(
                text = if (isGenerating) {
                    "Generating quiz..."
                } else {
                    if (adaptiveMode) {
                        "Generate Adaptive Quiz"
                    } else {
                        "Generate AI Quiz"
                    }
                },
                onClick = {

                    if (isGenerating || topic.isBlank()) {
                        return@ScaiPrimaryButton
                    }

                    coroutineScope.launch {

                        isGenerating = true
                        errorMessage = null

                        try {

                            val quiz = generator.generateQuiz(
                                subject = subject,
                                topic = topic.trim(),
                                difficulty = difficultyMapping.getValue(
                                    difficulty
                                ),
                                questionCount = questionCount,
                                questionFormat = questionFormat,
                                practiceHistory = practiceHistory,
                                adaptiveMode = adaptiveMode
                            )

                            onQuizGenerated(quiz)

                        } catch (exception: Exception) {

                            errorMessage = exception.message
                                ?: "Quiz generation failed. Please try again."

                        } finally {

                            isGenerating = false
                        }
                    }
                },
                enabled = topic.isNotBlank() && !isGenerating,
                loading = isGenerating,
                modifier = Modifier.fillMaxWidth()
            )

            if (isGenerating) {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    CircularProgressIndicator(
                        modifier = Modifier.height(20.dp),
                        strokeWidth = 2.dp
                    )

                    Spacer(
                        modifier = Modifier.width(10.dp)
                    )

                    Text(
                        text = if (adaptiveMode) {
                            "Analyzing performance and creating your quiz..."
                        } else {
                            "Creating and validating your questions..."
                        },
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Text(
                text = if (adaptiveMode) {
                    "SCAI uses evaluated practice history to personalize your quiz."
                } else {
                    "Generated questions are validated before the quiz begins."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun HorizontalAdaptiveDivider() {
    androidx.compose.material3.HorizontalDivider(
        color = MaterialTheme.colorScheme.outlineVariant
    )
}

@Composable
private fun AdaptiveInformation(
    title: String,
    description: String
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {

        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall
        )

        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TopicPerformancePreview(
    insight: TopicPerformanceInsight,
    recommendedDifficultyLabel: String
) {

    Column(
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Text(
                text = "${insight.accuracy}% accuracy",
                style = MaterialTheme.typography.bodyMedium
            )

            Text(
                text = "${insight.correctAnswers}/${insight.evaluatedAnswers} correct",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Text(
            text = "Recommended difficulty: $recommendedDifficultyLabel",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
        )

        Text(
            text = "Performance trend: ${insight.trend.name.lowercase().replace('_', ' ')}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Text(
            text = insight.recommendation,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
