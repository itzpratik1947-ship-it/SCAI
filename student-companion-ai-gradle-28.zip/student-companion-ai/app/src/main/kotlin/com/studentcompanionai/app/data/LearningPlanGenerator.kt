
package com.studentcompanionai.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

class LearningPlanGenerator(
    private val resourceRepository: ResourceRepository = ResourceRepository()
) {

    private val aiService = StudyAIService()

    companion object {
        private const val MAX_RESOURCE_TOPICS_PER_PLAN = 5
        private const val RESOURCE_RESULTS_PER_SEARCH = 5
        private const val MIN_RESULTS_BEFORE_HINDI_FALLBACK = 2
        private const val MAX_RESOURCES_PER_ACTIVITY = 4
    }

    suspend fun generatePlan(
        goal: String,
        subject: String,
        currentLevel: String,
        targetDays: Int,
        dailyStudyMinutes: Int,
        assessmentResult: InitialAssessmentResult? = null
    ): LearningPlan = withContext(Dispatchers.IO) {

        require(goal.isNotBlank()) {
            "Please enter your learning goal."
        }

        require(subject.isNotBlank()) {
            "Please enter a subject or skill."
        }

        require(targetDays in 1..90) {
            "Choose a plan duration between 1 and 90 days."
        }

        require(dailyStudyMinutes in 10..600) {
            "Daily study time must be between 10 and 600 minutes."
        }

        val relevantAssessment = assessmentResult?.takeIf {
            it.profileSubject.trim().equals(
                subject.trim(),
                ignoreCase = true
            )
        }

        val assessmentContext = buildAssessmentContext(
            assessmentResult = relevantAssessment
        )

        val prompt = """
            You are the intelligent adaptive learning-plan engine
            for Student Companion AI.

            Your task is to create a realistic, personalized,
            progressive learning roadmap.

            LEARNER DETAILS

            Goal: $goal
            Subject or skill: $subject
            Self-reported current level: $currentLevel
            Duration: $targetDays days
            Available study time per day: $dailyStudyMinutes minutes

            $assessmentContext

            ADAPTIVE LEARNING REQUIREMENTS

            1. Create exactly $targetDays days, numbered from 1.

            2. Respect the learner's goal, available time and
               demonstrated knowledge.

            3. When diagnostic assessment data is available,
               use it as stronger evidence of current knowledge
               than the learner's self-reported level.

            4. Prioritize topics marked as:
               - Needs Improvement
               - Developing

            5. Provide targeted foundational explanations and
               additional practice for weak topics.

            6. Topics marked Strong should receive less basic
               repetition and more advanced application where
               appropriate.

            7. Topics marked Good should receive appropriate
               practice and periodic revision.

            8. Use identified strengths and weaknesses to decide
               what the learner should study next.

            9. Do not assume that a high score in one topic means
               mastery of the entire subject.

            10. If assessment data is unavailable, create a
                progressive plan using the self-reported level.

            11. Keep each day's workload within the available
                study time of $dailyStudyMinutes minutes.

            12. Include learning, practice, revision and testing
                where appropriate.

            13. Make objectives and activities specific and actionable.

            14. Progress from foundational concepts to harder concepts.

            15. Include small projects or practical applications
                when suitable.

            16. Do not invent external resource URLs.

            17. Return ONLY valid JSON. No markdown or extra text.

            REQUIRED JSON STRUCTURE

            {
              "title": "Short plan title",
              "days": [
                {
                  "dayNumber": 1,
                  "title": "Day title",
                  "objectives": [
                    "Objective one"
                  ],
                  "activities": [
                    {
                      "title": "Activity title",
                      "description": "What the learner should do",
                      "type": "LEARN",
                      "estimatedMinutes": 20
                    }
                  ],
                  "estimatedMinutes": 60
                }
              ]
            }

            ACTIVITY TYPES

            LEARN, PRACTICE, REVISION, TEST, PROJECT.

            Use valid JSON strings and numbers.

            Do not include completion status, IDs, dates or
            scheduling information. The application generates
            and manages these locally.

            Return exactly $targetDays days.
        """.trimIndent()

        val response = aiService.generateStructuredReply(prompt)

        val draftPlan = parsePlan(
            response = response,
            goal = goal.trim(),
            subject = subject.trim(),
            currentLevel = currentLevel.trim(),
            targetDays = targetDays,
            dailyStudyMinutes = dailyStudyMinutes
        )

        // Resource discovery is supplementary.
        // A discovery failure must never invalidate the plan.
        attachResourcesToPlan(draftPlan)
    }

    // --------------------------------------------------
    // AUTOMATIC RESOURCE DISCOVERY
    // --------------------------------------------------

    private suspend fun attachResourcesToPlan(
        plan: LearningPlan
    ): LearningPlan {

        // Cache search results by topic to reduce API calls.
        // Cached resource IDs are NOT reused between activities.
        val resourceCache =
            mutableMapOf<String, List<LearningResource>>()

        var searchedTopicCount = 0

        val updatedDays = plan.days.map { day ->

            val updatedActivities = day.activities.map activityLoop@{ activity ->

                if (!shouldDiscoverResources(activity)) {
                    return@activityLoop activity
                }

                val query = buildResourceQuery(
                    plan = plan,
                    activity = activity
                )

                if (query.isBlank()) {
                    return@activityLoop activity
                }

                val cacheKey = query
                    .trim()
                    .lowercase(Locale.ROOT)

                // Repeated topics reuse search results,
                // but receive fresh IDs for each activity.
                val cachedResources = resourceCache[cacheKey]

                if (cachedResources != null) {
                    return@activityLoop activity.copy(
                        resources = createUniqueResourceCopies(
                            cachedResources
                        )
                    )
                }

                if (
                    searchedTopicCount >=
                    MAX_RESOURCE_TOPICS_PER_PLAN
                ) {
                    return@activityLoop activity
                }

                searchedTopicCount++

                val discoveredResources = try {
                    discoverResources(
                        query = query
                    )
                } catch (_: Exception) {
                    emptyList()
                }

                resourceCache[cacheKey] = discoveredResources

                activity.copy(
                    resources = createUniqueResourceCopies(
                        discoveredResources
                    )
                )
            }

            day.copy(
                activities = updatedActivities
            )
        }

        return plan.copy(
            days = updatedDays,
            updatedAt = System.currentTimeMillis()
        )
    }

    /**
     * Creates a separate resource ID for every activity attachment.
     *
     * The same resource URL can appear in multiple activities,
     * but its attachment ID must be unique throughout the plan.
     */
    private fun createUniqueResourceCopies(
        resources: List<LearningResource>
    ): List<LearningResource> {

        return resources.map { resource ->
            resource.copy(
                id = UUID.randomUUID().toString()
            )
        }
    }

    private fun shouldDiscoverResources(
        activity: LearningActivity
    ): Boolean {
        return activity.type in setOf(
            ActivityType.LEARN,
            ActivityType.PRACTICE,
            ActivityType.REVISION,
            ActivityType.RESOURCE
        )
    }

    private fun buildResourceQuery(
        plan: LearningPlan,
        activity: LearningActivity
    ): String {

        val topic = activity.topic.trim()

        val activityText = listOf(
            activity.title,
            activity.description
        )
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .joinToString(" ")

        return listOf(
            plan.subject,
            topic.ifBlank { activityText }
        )
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(" ")
            .take(300)
    }

    private suspend fun discoverResources(
        query: String
    ): List<LearningResource> {

        // First search in English.
        val englishResults = runCatching {
            resourceRepository.searchResources(
                query = query,
                language = ResourceLanguage.ENGLISH,
                limit = RESOURCE_RESULTS_PER_SEARCH,
                includeVideos = true,
                includeWeb = true
            ).resources
        }.getOrDefault(emptyList())

        val validEnglishResults = englishResults
            .filter { it.hasValidUrl && it.title.isNotBlank() }
            .distinctBy {
                it.url.trim().lowercase(Locale.ROOT)
            }

        // Search Hindi only when English results are insufficient.
        val combinedResults = if (
            validEnglishResults.size <
            MIN_RESULTS_BEFORE_HINDI_FALLBACK
        ) {

            val hindiResults = runCatching {
                resourceRepository.searchResources(
                    query = query,
                    language = ResourceLanguage.HINDI,
                    limit = RESOURCE_RESULTS_PER_SEARCH,
                    includeVideos = true,
                    includeWeb = true
                ).resources
            }.getOrDefault(emptyList())

            (
                validEnglishResults +
                    hindiResults.filter {
                        it.hasValidUrl && it.title.isNotBlank()
                    }
                )
                .distinctBy {
                    it.url.trim().lowercase(Locale.ROOT)
                }

        } else {
            validEnglishResults
        }

        return combinedResults
            .take(MAX_RESOURCES_PER_ACTIVITY)
            .map { resource ->
                resource.toLearningResource(
                    activityTopic = query
                )
            }
    }

    // --------------------------------------------------
    // ASSESSMENT CONTEXT
    // --------------------------------------------------

    private fun buildAssessmentContext(
        assessmentResult: InitialAssessmentResult?
    ): String {

        if (assessmentResult == null) {
            return """
                INITIAL KNOWLEDGE ASSESSMENT

                No matching assessment result is available.

                Create the learning plan using the learner's
                self-reported current level.
            """.trimIndent()
        }

        val topicDetails = assessmentResult.topicResults
            .joinToString("\n\n") { topic ->

                val strengths = topic.identifiedStrengths
                    .take(3)
                    .joinToString("; ")
                    .ifBlank { "None identified" }

                val weaknesses = topic.identifiedWeaknesses
                    .take(3)
                    .joinToString("; ")
                    .ifBlank { "None identified" }

                """
                Topic: ${topic.topic}
                Score: ${topic.scorePercent}%
                Knowledge level: ${topic.knowledgeLevel}
                Correct answers: ${topic.correctAnswers}/${topic.totalQuestions}
                Strengths: $strengths
                Weaknesses: $weaknesses
                """.trimIndent()
            }

        return """
            INITIAL KNOWLEDGE ASSESSMENT

            A completed diagnostic assessment is available.

            Overall score:
            ${assessmentResult.overallScorePercent}%

            Marks:
            ${assessmentResult.awardedMarks}/${assessmentResult.totalMarks}

            Total questions:
            ${assessmentResult.totalQuestions}

            TOPIC-WISE KNOWLEDGE PROFILE

            $topicDetails

            ADAPTATION INSTRUCTIONS

            Use these actual assessment measurements to personalize
            the learning roadmap.

            Give additional attention to weak topics.

            Avoid spending excessive time teaching concepts
            the learner has already demonstrated understanding of.

            Use the identified weaknesses to create targeted
            learning activities and practice exercises.

            Include revision and short tests to verify improvement.
        """.trimIndent()
    }

    // --------------------------------------------------
    // PLAN PARSING AND VALIDATION
    // --------------------------------------------------

    private fun parsePlan(
        response: String,
        goal: String,
        subject: String,
        currentLevel: String,
        targetDays: Int,
        dailyStudyMinutes: Int
    ): LearningPlan {

        val jsonText = extractJson(response)
        val root = JSONObject(jsonText)

        val planTitle = root.optString(
            "title",
            "$subject Learning Plan"
        ).trim().ifBlank {
            "$subject Learning Plan"
        }

        val jsonDays = root.optJSONArray("days")
            ?: throw IllegalStateException(
                "The AI response did not contain a learning plan. Please try again."
            )

        if (jsonDays.length() != targetDays) {
            throw IllegalStateException(
                "The AI generated ${jsonDays.length()} days, " +
                    "but $targetDays days were required. Please try again."
            )
        }

        val days = mutableListOf<LearningDay>()

        for (i in 0 until jsonDays.length()) {

            val dayObject = jsonDays.optJSONObject(i)
                ?: throw IllegalStateException(
                    "Invalid learning-plan data for day ${i + 1}."
                )

            val dayNumber = dayObject.optInt(
                "dayNumber",
                -1
            )

            if (dayNumber != i + 1) {
                throw IllegalStateException(
                    "The learning plan contains an invalid day sequence."
                )
            }

            val objectives = readStringArray(
                dayObject.optJSONArray("objectives")
            )

            val activitiesJson = dayObject.optJSONArray("activities")
                ?: JSONArray()

            if (activitiesJson.length() == 0) {
                throw IllegalStateException(
                    "Day ${i + 1} does not contain any learning activities."
                )
            }

            val activities = mutableListOf<LearningActivity>()

            for (j in 0 until activitiesJson.length()) {

                val activityObject =
                    activitiesJson.optJSONObject(j)
                        ?: throw IllegalStateException(
                            "Invalid activity in day ${i + 1}."
                        )

                val activityTitle = activityObject.optString(
                    "title",
                    "Learning activity"
                ).trim()

                if (activityTitle.isBlank()) {
                    throw IllegalStateException(
                        "An activity in day ${i + 1} has no title."
                    )
                }

                val typeName = activityObject
                    .optString("type", "LEARN")
                    .uppercase()

                val activityType = runCatching {
                    ActivityType.valueOf(typeName)
                }.getOrDefault(ActivityType.LEARN)

                val estimatedMinutes = activityObject
                    .optInt("estimatedMinutes", 0)

                if (estimatedMinutes < 0) {
                    throw IllegalStateException(
                        "Activity duration cannot be negative."
                    )
                }

                activities.add(
                    LearningActivity(
                        id = UUID.randomUUID().toString(),
                        title = activityTitle,
                        description = activityObject.optString(
                            "description",
                            ""
                        ),
                        type = activityType,
                        estimatedMinutes = estimatedMinutes,
                        topic = activityObject.optString(
                            "topic",
                            ""
                        ).trim()
                    )
                )
            }

            val dayEstimatedMinutes = dayObject.optInt(
                "estimatedMinutes",
                dailyStudyMinutes
            )

            if (
                dayEstimatedMinutes < 0 ||
                dayEstimatedMinutes > dailyStudyMinutes
            ) {
                throw IllegalStateException(
                    "Day ${i + 1} exceeds the available daily study time."
                )
            }

            val activityTotal = activities.sumOf {
                it.estimatedMinutes
            }

            if (activityTotal > dailyStudyMinutes) {
                throw IllegalStateException(
                    "Activities on day ${i + 1} exceed the daily study limit."
                )
            }

            days.add(
                LearningDay(
                    dayNumber = dayNumber,
                    title = dayObject.optString(
                        "title",
                        "Day $dayNumber"
                    ).ifBlank {
                        "Day $dayNumber"
                    },
                    objectives = objectives,
                    activities = activities,
                    estimatedMinutes = dayEstimatedMinutes,
                    scheduledDate = 0L
                )
            )
        }

        return LearningPlan(
            id = UUID.randomUUID().toString(),
            title = planTitle,
            goal = goal,
            subject = subject,
            currentLevel = currentLevel,
            targetDays = targetDays,
            dailyStudyMinutes = dailyStudyMinutes,
            startDate = 0L,
            status = LearningPlanStatus.DRAFT,
            days = days
        )
    }

    // --------------------------------------------------
    // JSON HELPERS
    // --------------------------------------------------

    private fun readStringArray(
        array: JSONArray?
    ): List<String> {

        if (array == null) return emptyList()

        return buildList {

            for (i in 0 until array.length()) {

                val value = array.optString(i, "").trim()

                if (value.isNotEmpty()) {
                    add(value)
                }
            }
        }
    }

    private fun extractJson(
        response: String
    ): String {

        val cleaned = response
            .trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')

        if (start == -1 || end <= start) {
            throw IllegalStateException(
                "The AI did not return valid JSON. Please generate the plan again."
            )
        }

        return cleaned.substring(start, end + 1)
    }
}
