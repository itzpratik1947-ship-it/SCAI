
package com.studentcompanionai.app.data

import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class ResourceRepository(
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
) {

    companion object {
        private const val BASE_URL =
            "https://scai-resource-api.itz-pratik1947.workers.dev"

        private const val SEARCH_ENDPOINT =
            "$BASE_URL/api/resources/search"

        private const val CONNECT_TIMEOUT = 15000
        private const val READ_TIMEOUT = 25000
    }

    data class SearchResult(
        val resources: List<ResourceItem>,
        val query: String,
        val language: String,
        val providerErrors: Int
    )

    suspend fun searchResources(
        query: String,
        language: ResourceLanguage = ResourceLanguage.ENGLISH,
        limit: Int = 8,
        includeVideos: Boolean = true,
        includeWeb: Boolean = true
    ): SearchResult = withContext(Dispatchers.IO) {

        val cleanedQuery = query.trim()

        require(cleanedQuery.length >= 2) {
            "Enter a topic with at least two characters."
        }

        require(includeVideos || includeWeb) {
            "Select at least one resource category."
        }

        val user = firebaseAuth.currentUser
            ?: throw SecurityException(
                "Please sign in before searching for resources."
            )

        val token = user.getIdToken(false).await().token
            ?: throw SecurityException(
                "Unable to obtain your Firebase authentication token."
            )

        val requestBody = JSONObject().apply {
            put("query", cleanedQuery)
            put("language", language.code)
            put("limit", limit.coerceIn(1, 10))
            put("includeVideos", includeVideos)
            put("includeWeb", includeWeb)
        }

        val connection = (
            URL(SEARCH_ENDPOINT).openConnection()
                as HttpURLConnection
            ).apply {

            requestMethod = "POST"
            connectTimeout = CONNECT_TIMEOUT
            readTimeout = READ_TIMEOUT
            doOutput = true

            setRequestProperty(
                "Content-Type",
                "application/json; charset=utf-8"
            )

            setRequestProperty(
                "Accept",
                "application/json"
            )

            setRequestProperty(
                "Authorization",
                "Bearer $token"
            )
        }

        try {
            connection.outputStream.use { output ->
                output.write(
                    requestBody.toString().toByteArray(Charsets.UTF_8)
                )
            }

            val statusCode = connection.responseCode

            val responseStream =
                if (statusCode in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

            val responseText = responseStream
                ?.bufferedReader()
                ?.use { it.readText() }
                .orEmpty()

            if (statusCode !in 200..299) {

                val errorMessage = try {
                    JSONObject(responseText)
                        .optString("error")
                } catch (_: Exception) {
                    ""
                }

                when (statusCode) {
                    401 -> throw SecurityException(
                        errorMessage.ifBlank {
                            "Authentication failed. Please sign in again."
                        }
                    )

                    400 -> throw IllegalArgumentException(
                        errorMessage.ifBlank {
                            "Invalid resource search request."
                        }
                    )

                    429 -> throw IOException(
                        "Resource search limit reached. Please try later."
                    )

                    else -> throw IOException(
                        errorMessage.ifBlank {
                            "Resource search failed (HTTP $statusCode)."
                        }
                    )
                }
            }

            val root = JSONObject(responseText)

            if (!root.optBoolean("success", false)) {
                throw IOException(
                    root.optString(
                        "error",
                        "Resource search was unsuccessful."
                    )
                )
            }

            val resourcesArray =
                root.optJSONArray("resources")

            val resources = buildList {

                if (resourcesArray != null) {

                    for (index in 0 until resourcesArray.length()) {

                        val item = resourcesArray.optJSONObject(index)
                            ?: continue

                        val resource = parseResource(item)

                        if (resource != null) {
                            add(resource)
                        }
                    }
                }
            }

            SearchResult(
                resources = resources.distinctBy { it.url },
                query = root.optString("query", cleanedQuery),
                language = root.optString(
                    "language",
                    language.code
                ),
                providerErrors = root.optInt("providerErrors", 0)
            )

        } finally {
            connection.disconnect()
        }
    }

    private fun parseResource(
        item: JSONObject
    ): ResourceItem? {

        val id = item.optString("id").trim()
        val title = item.optString("title").trim()
        val resourceUrl = item.optString("url").trim()

        if (id.isBlank() || title.isBlank()) {
            return null
        }

        if (
            !resourceUrl.startsWith("https://") &&
            !resourceUrl.startsWith("http://")
        ) {
            return null
        }

        val resourceType = try {
            ResourceType.valueOf(
                item.optString("type", "WEBSITE")
                    .uppercase()
            )
        } catch (_: Exception) {
            ResourceType.WEBSITE
        }

        return ResourceItem(
            id = id,
            title = title,
            url = resourceUrl,
            description = item.optString("description", ""),
            type = resourceType,
            provider = item.optString("provider", ""),
            thumbnailUrl = item.optString("thumbnailUrl", ""),
            author = item.optString("author", ""),
            languageCode = item.optString("languageCode", "en"),
            subject = item.optString("subject", ""),
            topic = item.optString("topic", ""),
            difficulty = item.optString("difficulty", ""),
            durationSeconds = item.optLong("durationSeconds", 0L),
            isFree = item.optBoolean("isFree", false),
            publishedAt = item.optString("publishedAt", ""),
            retrievedAt = item.optLong(
                "retrievedAt",
                System.currentTimeMillis()
            ),
            relevanceScore = item.optDouble(
                "relevanceScore",
                0.0
            )
        )
    }
}
