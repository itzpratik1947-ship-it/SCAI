
package com.studentcompanionai.app.ui.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val goalOptions = listOf(
    "Improve academic performance",
    "Prepare for an examination",
    "Learn a new skill",
    "Master a programming language",
    "Build practical projects",
    "Improve problem-solving",
    "Learn a new language",
    "Prepare for a career",
    "Explore a new subject"
)

private val additionalGoalOptions = listOf(
    "Improve consistency",
    "Develop better study habits",
    "Improve concentration",
    "Prepare for competitive exams",
    "Build real-world experience",
    "Improve confidence",
    "Complete a certification"
)

private val levelOptions = listOf(
    "Beginner",
    "Intermediate",
    "Advanced"
)

private val learningStyleOptions = listOf(
    "Examples",
    "Theory",
    "Practice",
    "Visual",
    "Detailed Notes",
    "Videos",
    "Problem Solving",
    "Interactive Quizzes",
    "Step by Step",
    "Combination"
)

@Composable
fun LearningGoalsScreen(
    initialLearningGoal: String = "",
    initialSecondaryGoals: List<String> = emptyList(),
    initialTargetAchievement: String = "",
    initialCurrentLevel: String = "BEGINNER",
    initialTargetDays: Int = 30,
    initialLearningStyle: String = "MIXED",
    onBack: () -> Unit,
    onContinue: (
        learningGoal: String,
        secondaryGoals: List<String>,
        targetAchievement: String,
        currentLevel: String,
        targetDays: Int,
        preferredLearningStyle: String
    ) -> Unit
) {
    var selectedGoal by rememberSaveable {
        mutableStateOf(initialLearningGoal)
    }

    var customGoal by rememberSaveable {
        mutableStateOf("")
    }

    // Saveable immutable list instead of mutableStateListOf.
    var selectedSecondaryGoals by rememberSaveable {
        mutableStateOf(initialSecondaryGoals.toList())
    }

    var targetAchievement by rememberSaveable {
        mutableStateOf(initialTargetAchievement)
    }

    var currentLevel by rememberSaveable {
        mutableStateOf(initialCurrentLevel)
    }

    var targetDays by rememberSaveable {
        mutableStateOf(initialTargetDays.coerceIn(7, 365))
    }

    var learningStyle by rememberSaveable {
        mutableStateOf(initialLearningStyle)
    }

    val finalGoal = if (selectedGoal == "Other") {
        customGoal.trim()
    } else {
        selectedGoal
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {

        TextButton(onClick = onBack) {
            Text("← Back")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Define your learning goals",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "What do you want to achieve? Your answers will help SCAI create a learning journey around your ambitions.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("What's your primary goal?")

        Text(
            text = "Choose the most important thing you want to achieve.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            goalOptions.chunked(2).forEach { goalRow ->

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    goalRow.forEach { goal ->

                        FilterChip(
                            selected = selectedGoal == goal,
                            onClick = {
                                selectedGoal = goal
                            },
                            label = {
                                Text(goal)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            FilterChip(
                selected = selectedGoal == "Other",
                onClick = {
                    selectedGoal = "Other"
                },
                label = {
                    Text("Other")
                }
            )
        }

        if (selectedGoal == "Other") {

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = customGoal,
                onValueChange = {
                    customGoal = it
                },
                modifier = Modifier.fillMaxWidth(),
                label = {
                    Text("Describe your goal")
                },
                placeholder = {
                    Text("What do you want to learn or achieve?")
                },
                shape = RoundedCornerShape(14.dp)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Any additional goals?")

        Text(
            text = "Select all that apply. These are optional.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            additionalGoalOptions.chunked(2).forEach { goalRow ->

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    goalRow.forEach { goal ->

                        FilterChip(
                            selected = selectedSecondaryGoals.contains(goal),
                            onClick = {

                                selectedSecondaryGoals =
                                    if (selectedSecondaryGoals.contains(goal)) {
                                        selectedSecondaryGoals.filterNot {
                                            it == goal
                                        }
                                    } else {
                                        selectedSecondaryGoals + goal
                                    }
                            },
                            label = {
                                Text(goal)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("What do you want to achieve?")

        OutlinedTextField(
            value = targetAchievement,
            onValueChange = {
                targetAchievement = it
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Your target outcome")
            },
            placeholder = {
                Text("e.g. Build an Android app independently")
            },
            minLines = 2,
            shape = RoundedCornerShape(14.dp)
        )

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("What's your current level?")

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            levelOptions.forEach { level ->

                FilterChip(
                    selected = currentLevel == level.uppercase(),
                    onClick = {
                        currentLevel = level.uppercase()
                    },
                    label = {
                        Text(level)
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("When do you want to achieve your goal?")

        Text(
            text = "$targetDays days",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )

        Slider(
            value = targetDays.toFloat(),
            onValueChange = {
                targetDays = it.toInt().coerceIn(7, 365)
            },
            valueRange = 7f..365f,
            steps = 357
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "7 days",
                style = MaterialTheme.typography.bodySmall
            )

            Text(
                text = "365 days",
                style = MaterialTheme.typography.bodySmall
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("How do you prefer to learn?")

        Text(
            text = "Choose the style that suits you best.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            learningStyleOptions.chunked(2).forEach { styleRow ->

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    styleRow.forEach { style ->

                        val styleValue = style
                            .uppercase()
                            .replace(" ", "_")

                        FilterChip(
                            selected = learningStyle == styleValue,
                            onClick = {
                                learningStyle = styleValue
                            },
                            label = {
                                Text(style)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                onContinue(
                    finalGoal,
                    selectedSecondaryGoals.toList(),
                    targetAchievement.trim(),
                    currentLevel,
                    targetDays,
                    learningStyle
                )
            },
            enabled = finalGoal.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                text = "Continue",
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun SectionTitle(title: String) {

    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(10.dp))
}
