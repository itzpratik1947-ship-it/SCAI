
package com.studentcompanionai.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.ResourceItem
import com.studentcompanionai.app.data.ResourceLanguage
import com.studentcompanionai.app.data.ResourceRepository
import com.studentcompanionai.app.data.ResourceStorage
import com.studentcompanionai.app.data.ResourceType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun ResourceDiscoveryScreen(
    onBackClick: () -> Unit = {},
    refreshKey: Int = 0
) {
    val context = LocalContext.current
    val uid = FirebaseAuth.getInstance().currentUser?.uid

    val repository = remember {
        ResourceRepository()
    }

    val storage = remember(uid) {
        uid?.let { ResourceStorage(it) }
    }

    val scope = rememberCoroutineScope()

    var query by remember {
        mutableStateOf("")
    }

    var language by remember {
        mutableStateOf(ResourceLanguage.ENGLISH)
    }

    var includeVideos by remember {
        mutableStateOf(true)
    }

    var includeWeb by remember {
        mutableStateOf(true)
    }

    var selectedType by remember {
        mutableStateOf<ResourceType?>(null)
    }

    var resources by remember {
        mutableStateOf<List<ResourceItem>>(emptyList())
    }

    var savedIds by remember(uid) {
        mutableStateOf<Set<String>>(emptySet())
    }

    var isLoading by remember {
        mutableStateOf(false)
    }

    var hasSearched by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    var savingResourceId by remember {
        mutableStateOf<String?>(null)
    }

    LaunchedEffect(uid, refreshKey) {
        savedIds = emptySet()

        if (uid == null) return@LaunchedEffect

        try {
            val saved = storage?.getSavedResources().orEmpty()
            if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                savedIds = saved
                    .map { it.resource.id }
                    .toSet()
            }
        } catch (_: Exception) {
            // Searching remains available if bookmarks cannot load.
        }
    }

    fun searchResources() {
        if (uid == null) {
            errorMessage = "Please sign in to discover resources."
            return
        }

        if (query.trim().length < 2) {
            errorMessage = "Enter at least two characters to search."
            return
        }

        if (!includeVideos && !includeWeb) {
            errorMessage = "Select videos or web resources."
            return
        }

        if (isLoading) return

        isLoading = true
        hasSearched = true
        errorMessage = null
        resources = emptyList()
        selectedType = null

        scope.launch {
            try {
                val result = repository.searchResources(
                    query = query.trim(),
                    language = language,
                    limit = 8,
                    includeVideos = includeVideos,
                    includeWeb = includeWeb
                )

                if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
                    return@launch
                }

                resources = result.resources

                if (result.resources.isEmpty()) {
                    errorMessage = if (result.providerErrors > 0) {
                        "Some search providers were unavailable. Try again."
                    } else {
                        "No resources found. Try another topic."
                    }
                } else if (result.providerErrors > 0) {
                    errorMessage =
                        "Some providers were unavailable. Showing available results."
                }

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                    errorMessage = e.localizedMessage
                        ?: "Unable to search resources. Check your connection."
                }
            } finally {
                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                    isLoading = false
                }
            }
        }
    }

    fun toggleBookmark(resource: ResourceItem) {
        val currentStorage = storage ?: return

        if (savingResourceId != null) return

        savingResourceId = resource.id

        scope.launch {
            try {
                if (resource.id in savedIds) {
                    currentStorage.removeResource(resource.id)
                    savedIds = savedIds - resource.id
                } else {
                    currentStorage.saveResource(resource)
                    savedIds = savedIds + resource.id
                }
            } catch (e: Exception) {
                errorMessage = e.localizedMessage
                    ?: "Unable to update saved resources."
            } finally {
                savingResourceId = null
            }
        }
    }

    fun openResource(resource: ResourceItem) {
        if (!resource.hasValidUrl) {
            errorMessage = "This resource has an invalid link."
            return
        }

        scope.launch {
            try {
                storage?.recordResourceOpened(resource)
            } catch (_: Exception) {
                // Opening a resource should not depend on history storage.
            }

            try {
                context.startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(resource.url)
                    )
                )
            } catch (_: Exception) {
                errorMessage = "Unable to open this resource."
            }
        }
    }

    val visibleResources = if (selectedType == null) {
        resources
    } else {
        resources.filter { it.type == selectedType }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {

            

            Text(
                text = "Discover Resources",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(5.dp))

            Text(
                text = "Find free videos, articles and documentation for your learning goals.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                enabled = !isLoading,
                label = { Text("What do you want to learn?") },
                placeholder = {
                    Text("e.g. Python, recursion, physics...")
                },
                shape = RoundedCornerShape(14.dp)
            )

            Spacer(Modifier.height(10.dp))

            Text(
                text = "Resource language",
                style = MaterialTheme.typography.labelLarge
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = language == ResourceLanguage.ENGLISH,
                    onClick = {
                        language = ResourceLanguage.ENGLISH
                    },
                    label = { Text("English") },
                    enabled = !isLoading
                )

                FilterChip(
                    selected = language == ResourceLanguage.HINDI,
                    onClick = {
                        language = ResourceLanguage.HINDI
                    },
                    label = { Text("हिन्दी") },
                    enabled = !isLoading
                )
            }

            Text(
                text = "Search sources",
                style = MaterialTheme.typography.labelLarge
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = includeVideos,
                    onClick = {
                        includeVideos = !includeVideos
                    },
                    label = { Text("YouTube") },
                    enabled = !isLoading
                )

                FilterChip(
                    selected = includeWeb,
                    onClick = {
                        includeWeb = !includeWeb
                    },
                    label = { Text("Web") },
                    enabled = !isLoading
                )
            }

            Button(
                onClick = { searchResources() },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading && uid != null
            ) {
                Text(
                    if (isLoading) "Searching..."
                    else "Search Resources"
                )
            }

            Spacer(Modifier.height(12.dp))

            if (resources.isNotEmpty()) {

                Text(
                    text = "${resources.size} resources found",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedType == null,
                        onClick = { selectedType = null },
                        label = { Text("All") }
                    )

                    FilterChip(
                        selected = selectedType == ResourceType.VIDEO,
                        onClick = {
                            selectedType = ResourceType.VIDEO
                        },
                        label = { Text("Videos") }
                    )

                    FilterChip(
                        selected = selectedType == ResourceType.WEBSITE,
                        onClick = {
                            selectedType = ResourceType.WEBSITE
                        },
                        label = { Text("Websites") }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedType == ResourceType.ARTICLE,
                        onClick = {
                            selectedType = ResourceType.ARTICLE
                        },
                        label = { Text("Articles") }
                    )

                    FilterChip(
                        selected = selectedType == ResourceType.DOCUMENTATION,
                        onClick = {
                            selectedType = ResourceType.DOCUMENTATION
                        },
                        label = { Text("Documentation") }
                    )
                }
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }

            if (errorMessage != null) {
                Text(
                    text = errorMessage!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            if (!isLoading && hasSearched && visibleResources.isEmpty() &&
                errorMessage == null
            ) {
                Text(
                    text = "No resources match this filter.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(
                    items = visibleResources,
                    key = { it.id }
                ) { resource ->

                    ResourceResultCard(
                        resource = resource,
                        isSaved = resource.id in savedIds,
                        isSaving = savingResourceId == resource.id,
                        onOpen = { openResource(resource) },
                        onBookmark = { toggleBookmark(resource) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ResourceResultCard(
    resource: ResourceItem,
    isSaved: Boolean,
    isSaving: Boolean,
    onOpen: () -> Unit,
    onBookmark: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 2.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {

            Text(
                text = when (resource.type) {
                    ResourceType.VIDEO -> "▶ VIDEO"
                    ResourceType.ARTICLE -> "ARTICLE"
                    ResourceType.DOCUMENTATION -> "DOCUMENTATION"
                    ResourceType.WEBSITE -> "WEBSITE"
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = resource.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (resource.description.isNotBlank()) {
                Spacer(Modifier.height(6.dp))

                Text(
                    text = resource.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(8.dp))

            Text(
                text = buildString {
                    if (resource.provider.isNotBlank()) {
                        append(resource.provider)
                    }

                    if (resource.author.isNotBlank()) {
                        if (isNotEmpty()) append(" • ")
                        append(resource.author)
                    }

                    if (isNotEmpty()) append(" • ")

                    append(if (resource.isFree) "Free-access result" else "Access not verified")
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onOpen,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Open Resource")
                }

                OutlinedButton(
                    onClick = onBookmark,
                    enabled = !isSaving
                ) {
                    Text(
                        when {
                            isSaving -> "Saving..."
                            isSaved -> "Saved"
                            else -> "Save"
                        }
                    )
                }
            }
        }
    }
}
