
package com.studentcompanionai.app.ui.onboarding

import android.app.TimePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private val scheduleDays = listOf(
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
)

private val studyTimeOptions = listOf(
    "Early Morning",
    "Morning",
    "Afternoon",
    "Evening",
    "Night"
)

private fun parseTime(time: String): Pair<Int, Int> {
    return try {
        val normalized = time.trim().uppercase(Locale.getDefault())

        val parts = normalized.split(Regex("\\s+"))
        val timeParts = parts[0].split(":")

        var hour = timeParts[0].toInt()
        val minute = timeParts.getOrNull(1)?.toInt() ?: 0

        if (parts.size > 1) {
            when (parts[1]) {
                "AM" -> {
                    if (hour == 12) hour = 0
                }

                "PM" -> {
                    if (hour != 12) hour += 12
                }
            }
        }

        hour.coerceIn(0, 23) to minute.coerceIn(0, 59)
    } catch (_: Exception) {
        6 to 0
    }
}

private fun formatTime(hour: Int, minute: Int): String {
    val period = if (hour >= 12) "PM" else "AM"
    val displayHour = when (hour % 12) {
        0 -> 12
        else -> hour % 12
    }

    return String.format(
        Locale.getDefault(),
        "%02d:%02d %s",
        displayHour,
        minute,
        period
    )
}

@Composable
fun ScheduleScreen(
    initialWakeTime: String = "06:00 AM",
    initialSleepTime: String = "10:00 PM",
    initialDailyStudyMinutes: Int = 120,
    initialAvailableDays: List<String> = emptyList(),
    initialAvailableSlots: List<String> = emptyList(),
    onBack: () -> Unit,
    onContinue: (
        wakeTime: String,
        sleepTime: String,
        dailyStudyMinutes: Int,
        availableDays: List<String>,
        availableSlots: List<String>
    ) -> Unit
) {
    val context = LocalContext.current

    var wakeTime by rememberSaveable {
        mutableStateOf(initialWakeTime)
    }

    var sleepTime by rememberSaveable {
        mutableStateOf(initialSleepTime)
    }

    var showWakeTimePicker by remember {
        mutableStateOf(false)
    }

    var showSleepTimePicker by remember {
        mutableStateOf(false)
    }

    var dailyStudyMinutes by rememberSaveable {
        mutableStateOf(initialDailyStudyMinutes.coerceIn(15, 720))
    }

    var selectedDays by rememberSaveable {
        mutableStateOf(initialAvailableDays.toList())
    }

    var selectedTimeSlots by rememberSaveable {
        mutableStateOf(initialAvailableSlots.toList())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {

        TextButton(onClick = onBack) {
            Text("← Back")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Your study schedule",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Let's understand your daily routine so SCAI can create a realistic learning schedule for you.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Your daily routine")

        // WAKE-UP TIME

        Text(
            text = "When do you usually wake up?",
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = wakeTime,
            onValueChange = {},
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    showWakeTimePicker = true
                },
            readOnly = true,
            enabled = true,
            label = {
                Text("Wake-up time")
            },
            placeholder = {
                Text("Select wake-up time")
            },
            trailingIcon = {
                Text("◷")
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp)
        )

        Spacer(modifier = Modifier.height(18.dp))

        // SLEEP TIME

        Text(
            text = "When do you usually sleep?",
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = sleepTime,
            onValueChange = {},
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    showSleepTimePicker = true
                },
            readOnly = true,
            enabled = true,
            label = {
                Text("Sleep time")
            },
            placeholder = {
                Text("Select sleep time")
            },
            trailingIcon = {
                Text("◷")
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp)
        )

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Daily study commitment")

        Text(
            text = "How much time can you dedicate to learning each day?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        val hours = dailyStudyMinutes / 60
        val minutes = dailyStudyMinutes % 60

        val studyTimeLabel = buildString {
            if (hours > 0) {
                append("$hours hr")
                if (minutes > 0) append(" ")
            }

            if (minutes > 0 || hours == 0) {
                append("$minutes min")
            }
        }

        Text(
            text = studyTimeLabel,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Slider(
            value = dailyStudyMinutes.toFloat(),
            onValueChange = {
                dailyStudyMinutes = it.toInt().coerceIn(15, 720)
            },
            valueRange = 15f..720f,
            steps = 46
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "15 minutes",
                style = MaterialTheme.typography.bodySmall
            )

            Text(
                text = "12 hours",
                style = MaterialTheme.typography.bodySmall
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Which days are you available?")

        Text(
            text = "Select all the days when you can study.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            scheduleDays.chunked(2).forEach { dayRow ->

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    dayRow.forEach { day ->

                        FilterChip(
                            selected = selectedDays.contains(day),
                            onClick = {
                                selectedDays =
                                    if (selectedDays.contains(day)) {
                                        selectedDays.filterNot {
                                            it == day
                                        }
                                    } else {
                                        selectedDays + day
                                    }
                            },
                            label = {
                                Text(day)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("When do you prefer to study?")

        Text(
            text = "Choose the time periods that work best for you.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            studyTimeOptions.forEach { time ->

                FilterChip(
                    selected = selectedTimeSlots.contains(time),
                    onClick = {
                        selectedTimeSlots =
                            if (selectedTimeSlots.contains(time)) {
                                selectedTimeSlots.filterNot {
                                    it == time
                                }
                            } else {
                                selectedTimeSlots + time
                            }
                    },
                    label = {
                        Text(time)
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                onContinue(
                    wakeTime.trim(),
                    sleepTime.trim(),
                    dailyStudyMinutes,
                    selectedDays.toList(),
                    selectedTimeSlots.toList()
                )
            },
            enabled = selectedDays.isNotEmpty() &&
                selectedTimeSlots.isNotEmpty(),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                text = "Continue",
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // NATIVE WAKE-UP TIME PICKER

    if (showWakeTimePicker) {
        val (hour, minute) = parseTime(wakeTime)

        TimePickerDialog(
            context,
            { _, selectedHour, selectedMinute ->
                wakeTime = formatTime(
                    selectedHour,
                    selectedMinute
                )
                showWakeTimePicker = false
            },
            hour,
            minute,
            false
        ).show()

        // Dialog dismissal is handled by the Android dialog itself.
        // The state is reset when the selected time is changed.
    }

    // NATIVE SLEEP TIME PICKER

    if (showSleepTimePicker) {
        val (hour, minute) = parseTime(sleepTime)

        TimePickerDialog(
            context,
            { _, selectedHour, selectedMinute ->
                sleepTime = formatTime(
                    selectedHour,
                    selectedMinute
                )
                showSleepTimePicker = false
            },
            hour,
            minute,
            false
        ).show()
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(10.dp))
}
