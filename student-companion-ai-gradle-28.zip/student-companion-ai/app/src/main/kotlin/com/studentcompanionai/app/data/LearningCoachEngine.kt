
package com.studentcompanionai.app.data

class LearningCoachEngine(
    private val aiService: StudyAIService = StudyAIService()
) {

    // =========================================
    // LEARNER CONTEXT
    // =========================================

    private fun buildLearnerContext(
        profile: LearningCoachProfile
    ): String {

        return buildString {

            appendLine("LEARNER PROFILE")
            appendLine("Use this information to personalise learning assistance.")
            appendLine()

            appendLine("Learning goal: ${profile.learningGoal}")
            appendLine("Subject or skill: ${profile.subject}")
            appendLine("Current learning level: ${profile.currentLevel.displayName}")
            appendLine("Target duration: ${profile.targetDays} days")
            appendLine("Available daily study time: ${profile.dailyStudyMinutes} minutes")
            appendLine("Preferred learning style: ${profile.preferredLearningStyle.displayName}")

            appendLine()
            appendLine("PERSONALISATION RULES")
            appendLine("- Adapt explanations to the learner's current level.")
            appendLine("- Respect the preferred learning style.")
            appendLine("- Keep recommendations within the available study time.")
            appendLine("- Do not invent syllabus, examination dates or progress.")
            appendLine("- Ask only for information that is genuinely missing.")
        }
    }


    // =========================================
    // CREATE LEARNING STRATEGY
    // =========================================

    suspend fun createLearningStrategy(
        profile: LearningCoachProfile
    ): String {

        require(profile.isValid()) {
            "Please complete your learning profile correctly."
        }

        val learnerContext = buildLearnerContext(profile)

        val prompt = """
            Create a practical, personalised learning strategy
            for the learner using the supplied learner context.

            YOUR TASK

            1. Briefly restate the learner's learning target.
            2. Explain the major milestones required to reach it.
            3. Recommend a realistic daily study structure.
            4. Adapt the teaching approach to the learner's level
               and preferred learning style.
            5. Explain how practice and revision should be used.
            6. Suggest a simple weekly progress-checking method.
            7. Identify important assumptions or limitations.
            8. End with one concrete first learning activity.

            RULES

            - Support any subject, academic stream or skill.
            - Keep the strategy practical and achievable.
            - Do not guarantee that the goal will be achieved
              within the requested duration.
            - Do not invent the learner's syllabus or background.
            - Use clear headings and concise language.
            - Do not create a long day-by-day plan here.
            - A separate learning-plan feature will handle
              detailed daily planning.
        """.trimIndent()

        return aiService.generateReply(
            userMessage = prompt,
            learnerContext = learnerContext
        )
    }


    // =========================================
    // RESPOND TO LEARNER
    // =========================================

    suspend fun respondToLearner(
        profile: LearningCoachProfile,
        learnerMessage: String,
        recentContext: String = ""
    ): String {

        require(profile.isValid()) {
            "Please complete your learning profile correctly."
        }

        require(learnerMessage.isNotBlank()) {
            "Please enter a message."
        }

        val learnerContext = buildLearnerContext(profile)

        val prompt = """
            Respond to the learner's message as their
            Universal AI Learning Coach.

            RECENT LEARNING CONTEXT

            ${recentContext.ifBlank {
                "No recent learning context has been provided."
            }}

            LEARNER MESSAGE

            $learnerMessage

            INSTRUCTIONS

            1. Answer the learner's actual message first.
            2. Adapt explanations to their stated learning level.
            3. Use examples suited to their preferred learning style.
            4. Break difficult ideas into manageable steps.
            5. If the learner is confused, explain differently
               rather than simply repeating the same explanation.
            6. If they ask for practice, provide relevant exercises.
            7. If they ask for an unrelated subject, help them
               without forcing the conversation back to their goal.
            8. Never pretend to know their progress when no
               progress information has been supplied.
            9. Use recent learning context when it is relevant.
            10. Be accurate, clear and avoid unnecessary filler.

            Do not invent information about the learner.
        """.trimIndent()

        return aiService.generateReply(
            userMessage = prompt,
            learnerContext = learnerContext
        )
    }
}
