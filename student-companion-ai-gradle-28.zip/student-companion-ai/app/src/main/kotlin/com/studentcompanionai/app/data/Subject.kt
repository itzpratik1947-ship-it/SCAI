package com.studentcompanionai.app.data

data class Subject(
    val id: Int,
    val name: String
)