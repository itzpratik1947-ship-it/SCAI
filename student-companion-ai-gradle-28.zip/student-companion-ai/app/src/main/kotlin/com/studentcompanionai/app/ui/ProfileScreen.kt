
package com.studentcompanionai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiSectionTitle
import com.studentcompanionai.app.ui.components.ScaiTopBar

@Composable
fun ProfileScreen(
    email: String,
    isSyncing: Boolean,
    isDarkTheme: Boolean,
    onThemeChange: (Boolean) -> Unit,
    onSyncClick: () -> Unit,
    onSignOutClick: () -> Unit,
    onDeleteProfileClick: () -> Unit,
    onMenuClick: () -> Unit
) {
    ScaiScreen(scrollable = true) {

        ScaiTopBar(
            title = "Profile",
            subtitle = "Manage your account and preferences",
            onMenuClick = onMenuClick
        )

        ScaiSectionTitle(
            title = "Account",
            description = "Your signed-in account"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScaiCard {
            Text(
                text = "Email address",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = email,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyLarge
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Appearance",
            description = "Choose how Student Companion AI looks"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScaiCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isDarkTheme) "Dark theme" else "Light theme",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (isDarkTheme) {
                            "Use the dark appearance."
                        } else {
                            "Use the light appearance."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Switch(
                    checked = isDarkTheme,
                    onCheckedChange = onThemeChange
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Data synchronization",
            description = "Keep your learning data connected to your account"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScaiCard {
            Text(
                text = "Sync your subjects, tasks and focus records with your account.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            ScaiPrimaryButton(
                text = if (isSyncing) "Syncing..." else "Sync now",
                onClick = onSyncClick,
                enabled = !isSyncing,
                loading = isSyncing
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Account actions",
            description = "Manage access to this account"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScaiCard {
            TextButton(
                onClick = onSignOutClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Sign out",
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.titleSmall
                )
            }

            ScaiDivider()

            TextButton(
                onClick = onDeleteProfileClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Delete learner profile",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.titleSmall
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}
