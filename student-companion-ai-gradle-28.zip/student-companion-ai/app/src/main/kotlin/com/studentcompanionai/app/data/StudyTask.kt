package com.studentcompanionai.app.data

data class StudyTask(
    val id: Int,
    val title: String,
    val subjectId: Int? = null,
    val isCompleted: Boolean = false,
    val description: String = "",
    val learningPlanId: String? = null,
    val learningActivityId: String? = null,

    // Scheduled calendar date (existing field).
    // Preserved for backward compatibility.
    val scheduledDate: Long = 0L,

    // Complete scheduled date and time in epoch milliseconds.
    // Zero means no specific time has been assigned.
    val scheduledDateTime: Long = 0L,

    val estimatedMinutes: Int = 0,
    val actualMinutes: Int = 0,
    val completedAt: Long = 0L,
    val isSkipped: Boolean = false,
    val skippedAt: Long = 0L,

    // Resources automatically attached from the linked
    // learning activity.
    val resources: List<LearningResource> = emptyList()
)