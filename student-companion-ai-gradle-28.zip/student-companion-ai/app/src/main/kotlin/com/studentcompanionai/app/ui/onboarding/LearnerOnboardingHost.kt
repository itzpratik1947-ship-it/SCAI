
package com.studentcompanionai.app.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.data.Subject

@Composable
fun LearnerOnboardingHost(
    storage: StudentStorage,
    onSignOut: () -> Unit,
    onCompleted: () -> Unit
) {

    var isSaving by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {

        LearnerOnboardingScreen(
            onSignOut = onSignOut,

            onComplete = { profile ->

                if (isSaving) {
                    return@LearnerOnboardingScreen
                }

                errorMessage = null

                val completedProfile = profile.copy(
                    profileCompleted = true,
                    updatedAt = System.currentTimeMillis()
                )

                // -------------------------------------------------
                // PROFILE VALIDATION
                // -------------------------------------------------

                val validationError = when {

                    !completedProfile.hasValidIdentity() ->
                        "Please enter your preferred name."

                    completedProfile.subject.isBlank() ->
                        "Please provide your education or learning area."

                    completedProfile.dailyStudyMinutes !in 15..720 ->
                        "Please select a valid daily study duration."

                    !completedProfile.hasValidFocusPreferences() ->
                        "Please check your focus and break preferences."

                    else -> null
                }

                if (validationError != null) {
                    errorMessage = validationError
                    return@LearnerOnboardingScreen
                }

                isSaving = true

                try {

                    // -------------------------------------------------
                    // STEP 1: SYNCHRONIZE ACADEMIC SUBJECTS
                    // -------------------------------------------------

                    val existingSubjects =
                        storage.loadSubjects().toMutableList()

                    val existingNames = existingSubjects
                        .map { it.name.trim().lowercase() }
                        .toMutableSet()

                    var nextSubjectId =
                        (existingSubjects.maxOfOrNull { it.id } ?: 0) + 1

                    val newSubjects = completedProfile.subjects
                        .map { it.trim() }
                        .filter { it.isNotBlank() }
                        .distinctBy { it.lowercase() }
                        .filter { it.lowercase() !in existingNames }
                        .map { subjectName ->

                            existingNames.add(subjectName.lowercase())

                            Subject(
                                id = nextSubjectId++,
                                name = subjectName
                            )
                        }

                    if (newSubjects.isNotEmpty()) {

                        val updatedSubjects =
                            existingSubjects + newSubjects

                        storage.saveSubjects(updatedSubjects)
                    }

                    // -------------------------------------------------
                    // STEP 2: SAVE LEARNER PROFILE
                    // -------------------------------------------------

                    storage.saveLearnerProfile(completedProfile)

                    // -------------------------------------------------
                    // STEP 3: VERIFY BOTH SAVES
                    // -------------------------------------------------

                    val profileSaved =
                        storage.isProfileCompleted()

                    val savedSubjectNames = storage.loadSubjects()
                        .map { it.name.trim().lowercase() }
                        .toSet()

                    val allAcademicSubjectsSaved =
                        completedProfile.subjects
                            .map { it.trim() }
                            .filter { it.isNotBlank() }
                            .all { it.lowercase() in savedSubjectNames }

                    if (profileSaved && allAcademicSubjectsSaved) {

                        isSaving = false

                        onCompleted()

                    } else {

                        isSaving = false

                        errorMessage =
                            "Some profile information could not be saved. Please try again."
                    }

                } catch (exception: Exception) {

                    isSaving = false

                    errorMessage =
                        exception.localizedMessage
                            ?: "Something went wrong while saving your profile."
                }
            }
        )

        // ---------------------------------------------------------
        // ERROR MESSAGE
        // ---------------------------------------------------------

        if (errorMessage != null) {

            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),

                color = MaterialTheme.colorScheme.errorContainer,
                shape = MaterialTheme.shapes.medium
            ) {

                Text(
                    text = errorMessage.orEmpty(),
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // ---------------------------------------------------------
        // SAVING OVERLAY
        // ---------------------------------------------------------

        if (isSaving) {

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        MaterialTheme.colorScheme.scrim.copy(
                            alpha = 0.35f
                        )
                    ),

                contentAlignment = Alignment.Center
            ) {

                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface
                ) {

                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {

                        CircularProgressIndicator()

                        Spacer(
                            modifier = Modifier.height(16.dp)
                        )

                        Text(
                            text = "Saving your learner profile...",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}
