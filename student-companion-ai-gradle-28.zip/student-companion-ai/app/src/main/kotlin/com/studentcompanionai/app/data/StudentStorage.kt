package com.studentcompanionai.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

enum class LegacyMigrationStatus {
    NOT_ACCOUNT_SCOPED,
    ALREADY_MIGRATED,
    NO_LEGACY_DATA,
    OWNERSHIP_CONFIRMATION_REQUIRED,
    OWNER_MISMATCH,
    DESTINATION_NOT_EMPTY,
    MIGRATED,
    FAILED
}

class StudentStorage(
    context: Context,
    private val accountUid: String? = null
) {

    private val appContext = context.applicationContext

    init {
        require(accountUid == null || accountUid.isNotBlank()) {
            "Firebase UID cannot be blank."
        }
    }

    private val preferences = appContext.getSharedPreferences(
        if (accountUid == null) {
            LEGACY_PREFERENCES_NAME
        } else {
            accountPreferencesName(accountUid)
        },
        Context.MODE_PRIVATE
    )

    companion object {
        private const val LEGACY_PREFERENCES_NAME =
            "student_companion_data"

        private const val ACCOUNT_PREFERENCES_PREFIX =
            "student_companion_data_"

        private const val KEY_MIGRATION_COMPLETED =
            "_legacy_migration_completed"

        private const val KEY_SYNC_OWNER_UID =
            "sync_owner_uid"

        private const val LEGACY_GAMIFICATION_PREFERENCES_NAME =
            "student_gamification"

        private const val ACCOUNT_GAMIFICATION_PREFIX =
            "student_gamification_"

        private const val LEGACY_CLAIM_PREFERENCES_NAME =
            "student_companion_legacy_claim"

        private const val KEY_LEGACY_CLAIMED_UID =
            "claimed_uid"

        private val migrationLock = Any()

        private fun accountPreferencesName(uid: String): String {
            require(uid.isNotBlank()) {
                "Firebase UID cannot be blank."
            }

            return ACCOUNT_PREFERENCES_PREFIX + uid
        }

        private const val KEY_SUBJECTS = "subjects"
        private const val KEY_TASKS = "tasks"
        private const val KEY_FOCUS_SESSIONS = "focus_session_records"
        private const val KEY_DELETED_SUBJECTS = "deleted_subject_ids"
        private const val KEY_DELETED_TASKS = "deleted_task_ids"
        private const val KEY_LEARNING_PLANS = "learning_plans"

        private const val KEY_LEARNING_COACH_PROFILE =
            "learning_coach_profile"

        private const val KEY_INITIAL_ASSESSMENTS =
            "initial_assessment_results"

        private val JSON_ARRAY_MERGE_KEYS = setOf(
            KEY_SUBJECTS,
            KEY_TASKS,
            KEY_FOCUS_SESSIONS,
            KEY_DELETED_SUBJECTS,
            KEY_DELETED_TASKS,
            KEY_LEARNING_PLANS,
            KEY_INITIAL_ASSESSMENTS,
            "practice_quiz_results"
        )

        private val RECORD_ID_KEYS = listOf(
            "id",
            "quizId",
            "resultId",
            "sessionId"
        )
    }

    // --------------------------------------------------
    // LEARNER PROFILE / LEARNING COACH PROFILE
    // --------------------------------------------------

    /**
     * Saves the complete learner profile.
     *
     * Unlike saveLearningCoachProfile(), this method also supports
     * incomplete onboarding drafts.
     *
     * The profile is stored in the current account's preferences.
     */
    fun saveLearnerProfile(profile: LearningCoachProfile) {

    val saved = preferences.edit()
        .putString(
            KEY_LEARNING_COACH_PROFILE,
            learningCoachProfileToJson(profile).toString()
        )
        .commit()

    if (!saved) {
        throw IllegalStateException(
            "Failed to save learner profile to device storage."
        )
    }
}

    /**
     * Retrieves the complete learner profile.
     *
     * Returns incomplete profiles too, allowing onboarding
     * to be restored after the application is restarted.
     */
    fun getLearnerProfile(): LearningCoachProfile? {
        return loadLearningCoachProfile()
    }

    /**
     * Returns true only when a saved profile has completed onboarding.
     */
    fun isProfileCompleted(): Boolean {
        return getLearnerProfile()?.profileCompleted == true
    }

    /**
     * Updates an existing learner profile.
     *
     * This uses the same account-specific storage key and
     * serialization format as saveLearnerProfile().
     */
    fun updateLearnerProfile(profile: LearningCoachProfile) {
        saveLearnerProfile(
            profile.copy(
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    /**
     * Removes the learner profile from the current account only.
     *
     * Does not remove subjects, tasks, learning plans,
     * assessment results or other learning history.
     */
    fun clearLearnerProfile() {
        preferences.edit()
            .remove(KEY_LEARNING_COACH_PROFILE)
            .apply()
    }

    /**
     * Original Learning Coach API.
     *
     * Retained for compatibility with existing screens and services.
     * This method preserves the original validation requirements.
     */
    fun saveLearningCoachProfile(profile: LearningCoachProfile) {
        require(profile.isValid()) {
            "Invalid learning coach profile."
        }

        saveLearnerProfile(profile)
    }

    /**
     * Original Learning Coach API.
     *
     * Existing callers continue receiving the expanded profile.
     */
    fun loadLearningCoachProfile(): LearningCoachProfile? {
        return try {
            val json = preferences.getString(
                KEY_LEARNING_COACH_PROFILE,
                null
            ) ?: return null

            learningCoachProfileFromJson(JSONObject(json))
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Original Learning Coach API.
     */
    fun deleteLearningCoachProfile() {
        clearLearnerProfile()
    }

    // --------------------------------------------------
    // LEARNER PROFILE JSON SERIALIZATION
    // --------------------------------------------------

    private fun learningCoachProfileToJson(
        profile: LearningCoachProfile
    ): JSONObject {

        val subjectsArray = JSONArray()
        profile.subjects.forEach {
            subjectsArray.put(it)
        }

        val secondaryGoalsArray = JSONArray()
        profile.secondaryGoals.forEach {
            secondaryGoalsArray.put(it)
        }

        val learningTracksArray = JSONArray()
        profile.learningTracks.forEach { track ->
            learningTracksArray.put(
                JSONObject()
                    .put("title", track.title)
                    .put("category", track.category)
                    .put("currentLevel", track.currentLevel.name)
                    .put("targetAchievement", track.targetAchievement)
                    .put("targetDays", track.targetDays)
                    .put("isPrimary", track.isPrimary)
            )
        }

        val occupiedSlotsArray = JSONArray()
        profile.occupiedSlots.forEach { slot ->
            occupiedSlotsArray.put(
                JSONObject()
                    .put("day", slot.day)
                    .put("startTime", slot.startTime)
                    .put("endTime", slot.endTime)
                    .put("label", slot.label)
            )
        }

        val availableSlotsArray = JSONArray()
        profile.availableSlots.forEach { slot ->
            availableSlotsArray.put(
                JSONObject()
                    .put("day", slot.day)
                    .put("startTime", slot.startTime)
                    .put("endTime", slot.endTime)
                    .put("label", slot.label)
            )
        }

        val availableDaysArray = JSONArray()
        profile.availableDays.forEach {
            availableDaysArray.put(it)
        }

        val areasOfDifficultyArray = JSONArray()
        profile.areasOfDifficulty.forEach {
            areasOfDifficultyArray.put(it)
        }

        val notificationJson = JSONObject()
            .put(
                "studyReminders",
                profile.notificationPreferences.studyReminders
            )
            .put(
                "learningPlanReminders",
                profile.notificationPreferences.learningPlanReminders
            )
            .put(
                "focusReminders",
                profile.notificationPreferences.focusReminders
            )
            .put(
                "dailyProgressSummary",
                profile.notificationPreferences.dailyProgressSummary
            )
            .put(
                "achievementNotifications",
                profile.notificationPreferences.achievementNotifications
            )

        return JSONObject()
            // Original Learning Coach fields
            .put("learningGoal", profile.learningGoal)
            .put("subject", profile.subject)
            .put("currentLevel", profile.currentLevel.name)
            .put("targetDays", profile.targetDays)
            .put("dailyStudyMinutes", profile.dailyStudyMinutes)
            .put(
                "preferredLearningStyle",
                profile.preferredLearningStyle.name
            )
            .put("createdAt", profile.createdAt)
            .put("updatedAt", profile.updatedAt)

            // Personal information
            .put("preferredName", profile.preferredName)
            .put("avatar", profile.avatar ?: JSONObject.NULL)
            .put("userType", profile.userType.name)

            // Education
            .put("educationCategory", profile.educationCategory.name)
            .put("qualification", profile.qualification)
            .put("stream", profile.stream)
            .put("specialization", profile.specialization)
            .put("academicYear", profile.academicYear)
            .put("semester", profile.semester)
            .put("institution", profile.institution)
            .put("boardOrUniversity", profile.boardOrUniversity)
            .put("subjects", subjectsArray)

            // Learning goals
            .put("secondaryGoals", secondaryGoalsArray)
            .put("targetAchievement", profile.targetAchievement)
            .put("learningTracks", learningTracksArray)

            // Schedule
            .put("wakeTime", profile.wakeTime)
            .put("sleepTime", profile.sleepTime)
            .put("occupiedSlots", occupiedSlotsArray)
            .put("availableSlots", availableSlotsArray)
            .put("availableDays", availableDaysArray)

            // Focus preferences
            .put("focusDuration", profile.focusDuration)
            .put("breakDuration", profile.breakDuration)
            .put("dailyFocusTarget", profile.dailyFocusTarget)
            .put("preferredFocusTime", profile.preferredFocusTime.name)

            // Learning preferences
            .put("preferredLanguage", profile.preferredLanguage)
            .put("preferredDifficulty", profile.preferredDifficulty.name)
            .put("notificationPreferences", notificationJson)
            .put("areasOfDifficulty", areasOfDifficultyArray)

            // Onboarding
            .put("profileCompleted", profile.profileCompleted)
    }

    private fun learningCoachProfileFromJson(
        item: JSONObject
    ): LearningCoachProfile? {

        return try {

            // Original fields are read first.
            // Defaults allow older profile JSON to remain readable.

            val level = readEnum(
                item.optString("currentLevel", ""),
                LearningLevel.BEGINNER
            )

            val learningStyle = readEnum(
                item.optString("preferredLearningStyle", ""),
                LearningStyle.MIXED
            )

            val userType = readEnum(
                item.optString("userType", ""),
                UserType.STUDENT
            )

            val educationCategory = readEnum(
                item.optString("educationCategory", ""),
                EducationCategory.INDEPENDENT_LEARNING
            )

            val preferredFocusTime = readEnum(
                item.optString("preferredFocusTime", ""),
                PreferredFocusTime.FLEXIBLE
            )

            val preferredDifficulty = readEnum(
                item.optString("preferredDifficulty", ""),
                LearningDifficulty.ADAPTIVE
            )

            // Subjects
            val subjects = readStorageStringArray(
                item.optJSONArray("subjects")
            )

            // Secondary goals
            val secondaryGoals = readStorageStringArray(
                item.optJSONArray("secondaryGoals")
            )

            // Learning tracks
            val learningTracksArray =
                item.optJSONArray("learningTracks") ?: JSONArray()

            val learningTracks = mutableListOf<LearningTrack>()

            for (i in 0 until learningTracksArray.length()) {
                val trackItem =
                    learningTracksArray.optJSONObject(i) ?: continue

                val title = trackItem.optString("title", "").trim()

                if (title.isBlank()) continue

                learningTracks.add(
                    LearningTrack(
                        title = title,
                        category = trackItem.optString("category", ""),
                        currentLevel = readEnum(
                            trackItem.optString("currentLevel", ""),
                            LearningLevel.BEGINNER
                        ),
                        targetAchievement = trackItem.optString(
                            "targetAchievement",
                            ""
                        ),
                        targetDays = trackItem.optInt(
                            "targetDays",
                            30
                        ).coerceIn(1, 3650),
                        isPrimary = trackItem.optBoolean(
                            "isPrimary",
                            false
                        )
                    )
                )
            }

            // Occupied schedule slots
            val occupiedSlots = readScheduleSlots(
                item.optJSONArray("occupiedSlots")
            )

            // Available schedule slots
            val availableSlots = readScheduleSlots(
                item.optJSONArray("availableSlots")
            )

            // Available days
            val availableDays = readStorageStringArray(
                item.optJSONArray("availableDays")
            )

            // Areas of difficulty
            val areasOfDifficulty = readStorageStringArray(
                item.optJSONArray("areasOfDifficulty")
            )

            // Notification preferences
            val notificationJson =
                item.optJSONObject("notificationPreferences")
                    ?: JSONObject()

            val notificationPreferences = NotificationPreferences(
                studyReminders = notificationJson.optBoolean(
                    "studyReminders",
                    true
                ),
                learningPlanReminders = notificationJson.optBoolean(
                    "learningPlanReminders",
                    true
                ),
                focusReminders = notificationJson.optBoolean(
                    "focusReminders",
                    true
                ),
                dailyProgressSummary = notificationJson.optBoolean(
                    "dailyProgressSummary",
                    false
                ),
                achievementNotifications = notificationJson.optBoolean(
                    "achievementNotifications",
                    true
                )
            )

            val avatar = if (
                item.isNull("avatar") ||
                !item.has("avatar")
            ) {
                null
            } else {
                item.optString("avatar", "")
                    .takeIf { it.isNotBlank() }
            }

            LearningCoachProfile(
                // Original Learning Coach fields
                learningGoal = item.optString(
                    "learningGoal",
                    ""
                ),
                subject = item.optString(
                    "subject",
                    ""
                ),
                currentLevel = level,
                targetDays = item.optInt(
                    "targetDays",
                    30
                ),
                dailyStudyMinutes = item.optInt(
                    "dailyStudyMinutes",
                    60
                ),
                preferredLearningStyle = learningStyle,
                createdAt = item.optLong(
                    "createdAt",
                    System.currentTimeMillis()
                ),
                updatedAt = item.optLong(
                    "updatedAt",
                    System.currentTimeMillis()
                ),

                // Personal information
                preferredName = item.optString(
                    "preferredName",
                    ""
                ),
                avatar = avatar,
                userType = userType,

                // Education
                educationCategory = educationCategory,
                qualification = item.optString(
                    "qualification",
                    ""
                ),
                stream = item.optString(
                    "stream",
                    ""
                ),
                specialization = item.optString(
                    "specialization",
                    ""
                ),
                academicYear = item.optString(
                    "academicYear",
                    ""
                ),
                semester = item.optString(
                    "semester",
                    ""
                ),
                institution = item.optString(
                    "institution",
                    ""
                ),
                boardOrUniversity = item.optString(
                    "boardOrUniversity",
                    ""
                ),
                subjects = subjects,

                // Learning goals
                secondaryGoals = secondaryGoals,
                targetAchievement = item.optString(
                    "targetAchievement",
                    ""
                ),
                learningTracks = learningTracks,

                // Schedule
                wakeTime = item.optString(
                    "wakeTime",
                    ""
                ),
                sleepTime = item.optString(
                    "sleepTime",
                    ""
                ),
                occupiedSlots = occupiedSlots,
                availableSlots = availableSlots,
                availableDays = availableDays,

                // Focus preferences
                focusDuration = item.optInt(
                    "focusDuration",
                    25
                ),
                breakDuration = item.optInt(
                    "breakDuration",
                    5
                ),
                dailyFocusTarget = item.optInt(
                    "dailyFocusTarget",
                    4
                ),
                preferredFocusTime = preferredFocusTime,

                // Learning preferences
                preferredLanguage = item.optString(
                    "preferredLanguage",
                    ""
                ),
                preferredDifficulty = preferredDifficulty,
                notificationPreferences = notificationPreferences,
                areasOfDifficulty = areasOfDifficulty,

                // Onboarding
                profileCompleted = item.optBoolean(
                    "profileCompleted",
                    false
                )
            )

        } catch (_: Exception) {
            null
        }
    }

    /**
     * Safely reads enum values.
     *
     * This protects stored profiles if an enum value is missing,
     * renamed in older data or unavailable in a future version.
     */
    private inline fun <reified T : Enum<T>> readEnum(
        value: String,
        defaultValue: T
    ): T {
        return try {
            enumValueOf<T>(value)
        } catch (_: Exception) {
            defaultValue
        }
    }

    private fun readScheduleSlots(
        array: JSONArray?
    ): List<ScheduleSlot> {

        if (array == null) return emptyList()

        val result = mutableListOf<ScheduleSlot>()

        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue

            val day = item.optString("day", "").trim()
            val startTime = item.optString("startTime", "").trim()
            val endTime = item.optString("endTime", "").trim()

            if (
                day.isBlank() ||
                startTime.isBlank() ||
                endTime.isBlank()
            ) {
                continue
            }

            result.add(
                ScheduleSlot(
                    day = day,
                    startTime = startTime,
                    endTime = endTime,
                    label = item.optString("label", "")
                )
            )
        }

        return result
    }

    private fun readStorageStringArray(
        array: JSONArray?
    ): List<String> {

        if (array == null) return emptyList()

        return buildList {
            for (i in 0 until array.length()) {
                val value = array.optString(i, "").trim()

                if (value.isNotBlank()) {
                    add(value)
                }
            }
        }
    }

    // --------------------------------------------------
    // INITIAL ASSESSMENT STORAGE
    // --------------------------------------------------

    fun saveInitialAssessmentResult(
        result: InitialAssessmentResult
    ) {
        val results = loadInitialAssessmentResults().toMutableList()

        val index = results.indexOfFirst {
            it.id == result.id
        }

        if (index >= 0) {
            results[index] = result
        } else {
            results.add(result)
        }

        val array = JSONArray()

        results.distinctBy { it.id }.forEach {
            array.put(initialAssessmentToJson(it))
        }

        preferences.edit()
            .putString(
                KEY_INITIAL_ASSESSMENTS,
                array.toString()
            )
            .apply()
    }

    fun loadInitialAssessmentResults():
        List<InitialAssessmentResult> {

        return try {
            val json = preferences.getString(
                KEY_INITIAL_ASSESSMENTS,
                null
            ) ?: return emptyList()

            val array = JSONArray(json)
            val results = mutableListOf<InitialAssessmentResult>()

            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val result = initialAssessmentFromJson(item)

                if (result != null) {
                    results.add(result)
                }
            }

            results
                .distinctBy { it.id }
                .sortedByDescending { it.completedAt }

        } catch (_: Exception) {
            emptyList()
        }
    }

    fun getLatestInitialAssessmentResult():
        InitialAssessmentResult? {

        return loadInitialAssessmentResults()
            .maxByOrNull { it.completedAt }
    }

    fun getInitialAssessmentResultById(
        id: String
    ): InitialAssessmentResult? {

        if (id.isBlank()) return null

        return loadInitialAssessmentResults()
            .firstOrNull { it.id == id }
    }

    fun deleteInitialAssessmentResult(id: String) {
        if (id.isBlank()) return

        val remaining = loadInitialAssessmentResults()
            .filterNot { it.id == id }

        val array = JSONArray()

        remaining.forEach {
            array.put(initialAssessmentToJson(it))
        }

        preferences.edit()
            .putString(
                KEY_INITIAL_ASSESSMENTS,
                array.toString()
            )
            .apply()
    }

    fun clearInitialAssessmentResults() {
        preferences.edit()
            .remove(KEY_INITIAL_ASSESSMENTS)
            .apply()
    }

    // --------------------------------------------------
    // INITIAL ASSESSMENT JSON SERIALIZATION
    // --------------------------------------------------

    private fun initialAssessmentToJson(
        result: InitialAssessmentResult
    ): JSONObject {

        val responsesArray = JSONArray()

        result.responses.forEach { response ->
            responsesArray.put(
                JSONObject()
                    .put("questionId", response.questionId)
                    .put(
                        "selectedOptionIndex",
                        response.selectedOptionIndex
                            ?: JSONObject.NULL
                    )
                    .put("writtenAnswer", response.writtenAnswer)
                    .put("submittedAt", response.submittedAt)
            )
        }

        val evaluationsArray = JSONArray()

        result.evaluations.forEach { evaluation ->
            evaluationsArray.put(
                JSONObject()
                    .put("questionId", evaluation.questionId)
                    .put("awardedMarks", evaluation.awardedMarks)
                    .put("maximumMarks", evaluation.maximumMarks)
                    .put("isCorrect", evaluation.isCorrect)
                    .put("feedback", evaluation.feedback)
                    .put(
                        "evaluationBasis",
                        evaluation.evaluationBasis
                    )
            )
        }

        val topicsArray = JSONArray()

        result.topicResults.forEach { topic ->
            val strengthsArray = JSONArray()
            topic.identifiedStrengths.forEach {
                strengthsArray.put(it)
            }

            val weaknessesArray = JSONArray()
            topic.identifiedWeaknesses.forEach {
                weaknessesArray.put(it)
            }

            topicsArray.put(
                JSONObject()
                    .put("topic", topic.topic)
                    .put("totalQuestions", topic.totalQuestions)
                    .put("correctAnswers", topic.correctAnswers)
                    .put("scorePercent", topic.scorePercent)
                    .put("knowledgeLevel", topic.knowledgeLevel)
                    .put("identifiedStrengths", strengthsArray)
                    .put("identifiedWeaknesses", weaknessesArray)
            )
        }

        return JSONObject()
            .put("id", result.id)
            .put("profileSubject", result.profileSubject)
            .put("completedAt", result.completedAt)
            .put("totalQuestions", result.totalQuestions)
            .put("totalMarks", result.totalMarks)
            .put("awardedMarks", result.awardedMarks)
            .put("overallScorePercent", result.overallScorePercent)
            .put("responses", responsesArray)
            .put("evaluations", evaluationsArray)
            .put("topicResults", topicsArray)
    }

    private fun initialAssessmentFromJson(
        item: JSONObject
    ): InitialAssessmentResult? {

        return try {
            val id = item.optString("id", "")
            val subject = item.optString("profileSubject", "")

            if (id.isBlank() || subject.isBlank()) {
                return null
            }

            val responsesArray =
                item.optJSONArray("responses") ?: JSONArray()

            val responses =
                mutableListOf<InitialAssessmentResponse>()

            for (i in 0 until responsesArray.length()) {
                val responseItem =
                    responsesArray.optJSONObject(i) ?: continue

                val questionId =
                    responseItem.optString("questionId", "")

                if (questionId.isBlank()) continue

                val selectedIndex =
                    if (responseItem.isNull("selectedOptionIndex")) {
                        null
                    } else {
                        responseItem.optInt(
                            "selectedOptionIndex",
                            -1
                        ).takeIf { it >= 0 }
                    }

                responses.add(
                    InitialAssessmentResponse(
                        questionId = questionId,
                        selectedOptionIndex = selectedIndex,
                        writtenAnswer = responseItem.optString(
                            "writtenAnswer",
                            ""
                        ),
                        submittedAt = responseItem.optLong(
                            "submittedAt",
                            0L
                        )
                    )
                )
            }

            val evaluationsArray =
                item.optJSONArray("evaluations") ?: JSONArray()

            val evaluations =
                mutableListOf<AssessmentAnswerEvaluation>()

            for (i in 0 until evaluationsArray.length()) {
                val evaluationItem =
                    evaluationsArray.optJSONObject(i) ?: continue

                val questionId =
                    evaluationItem.optString("questionId", "")

                if (questionId.isBlank()) continue

                val awardedMarks = evaluationItem.optDouble(
                    "awardedMarks",
                    Double.NaN
                )

                val maximumMarks = evaluationItem.optInt(
                    "maximumMarks",
                    0
                )

                if (
                    !awardedMarks.isFinite() ||
                    maximumMarks <= 0 ||
                    awardedMarks < 0.0 ||
                    awardedMarks > maximumMarks
                ) {
                    continue
                }

                evaluations.add(
                    AssessmentAnswerEvaluation(
                        questionId = questionId,
                        awardedMarks = awardedMarks,
                        maximumMarks = maximumMarks,
                        isCorrect = evaluationItem.optBoolean(
                            "isCorrect",
                            false
                        ),
                        feedback = evaluationItem.optString(
                            "feedback",
                            ""
                        ),
                        evaluationBasis = evaluationItem.optString(
                            "evaluationBasis",
                            ""
                        )
                    )
                )
            }

            val topicsArray =
                item.optJSONArray("topicResults") ?: JSONArray()

            val topicResults =
                mutableListOf<TopicKnowledgeResult>()

            for (i in 0 until topicsArray.length()) {
                val topicItem =
                    topicsArray.optJSONObject(i) ?: continue

                val topicName =
                    topicItem.optString("topic", "")

                if (topicName.isBlank()) continue

                topicResults.add(
                    TopicKnowledgeResult(
                        topic = topicName,
                        totalQuestions = topicItem.optInt(
                            "totalQuestions",
                            0
                        ),
                        correctAnswers = topicItem.optInt(
                            "correctAnswers",
                            0
                        ),
                        scorePercent = topicItem.optInt(
                            "scorePercent",
                            0
                        ),
                        knowledgeLevel = topicItem.optString(
                            "knowledgeLevel",
                            "Unknown"
                        ),
                        identifiedStrengths = readStorageStringArray(
                            topicItem.optJSONArray(
                                "identifiedStrengths"
                            )
                        ),
                        identifiedWeaknesses = readStorageStringArray(
                            topicItem.optJSONArray(
                                "identifiedWeaknesses"
                            )
                        )
                    )
                )
            }

            InitialAssessmentResult(
                id = id,
                profileSubject = subject,
                completedAt = item.optLong(
                    "completedAt",
                    System.currentTimeMillis()
                ),
                totalQuestions = item.optInt(
                    "totalQuestions",
                    0
                ),
                totalMarks = item.optDouble(
                    "totalMarks",
                    0.0
                ),
                awardedMarks = item.optDouble(
                    "awardedMarks",
                    0.0
                ),
                overallScorePercent = item.optInt(
                    "overallScorePercent",
                    0
                ),
                responses = responses,
                evaluations = evaluations,
                topicResults = topicResults
            )

        } catch (_: Exception) {
            null
        }
    }

    // --------------------------------------------------
    // LEARNING PLANS
    // --------------------------------------------------

    fun saveLearningPlan(plan: LearningPlan) {
        val plans = loadLearningPlans().toMutableList()

        val index = plans.indexOfFirst {
            it.id == plan.id
        }

        if (index >= 0) {
            plans[index] = plan
        } else {
            plans.add(plan)
        }

        saveLearningPlans(plans)
    }

    fun saveLearningPlans(plans: List<LearningPlan>) {
        val array = JSONArray()

        plans.distinctBy { it.id }.forEach { plan ->
            array.put(learningPlanToJson(plan))
        }

        preferences.edit()
            .putString(KEY_LEARNING_PLANS, array.toString())
            .apply()
    }

    fun loadLearningPlans(): List<LearningPlan> {
        return try {
            val json = preferences.getString(
                KEY_LEARNING_PLANS,
                null
            ) ?: return emptyList()

            val array = JSONArray(json)
            val plans = mutableListOf<LearningPlan>()

            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val plan = learningPlanFromJson(item)

                if (plan != null) {
                    plans.add(plan)
                }
            }

            plans.distinctBy { it.id }
                .sortedByDescending { it.updatedAt }

        } catch (_: Exception) {
            emptyList()
        }
    }

    fun getLearningPlanById(id: String): LearningPlan? {
        if (id.isBlank()) return null

        return loadLearningPlans()
            .firstOrNull { it.id == id }
    }

    fun deleteLearningPlan(id: String) {
        if (id.isBlank()) return

        val remainingPlans = loadLearningPlans()
            .filterNot { it.id == id }

        saveLearningPlans(remainingPlans)
    }

    fun replaceLearningPlansFromSync(
        plans: List<LearningPlan>
    ) {
        saveLearningPlans(plans)
    }

    // --------------------------------------------------
    // LEARNING PLAN JSON SERIALIZATION
    // --------------------------------------------------

    private fun learningPlanToJson(
        plan: LearningPlan
    ): JSONObject {

        val daysArray = JSONArray()

        plan.days.forEach { day ->
            val objectivesArray = JSONArray()
            day.objectives.forEach { objectivesArray.put(it) }

            val activitiesArray = JSONArray()
            day.activities.forEach { activity ->
                val resourcesArray = JSONArray()
                activity.resources.forEach { resource ->
                    resourcesArray.put(
                        JSONObject()
                            .put("id", resource.id)
                            .put("title", resource.title)
                            .put("url", resource.url)
                            .put("type", resource.type.name)
                            .put("provider", resource.provider)
                            .put("description", resource.description)
                            .put("estimatedMinutes", resource.estimatedMinutes)
                            .put("allocatedMinutes", resource.allocatedMinutes)
                            .put("topic", resource.topic)
                    )
                }

                activitiesArray.put(
                    JSONObject()
                        .put("id", activity.id)
                        .put("title", activity.title)
                        .put("description", activity.description)
                        .put("type", activity.type.name)
                        .put("estimatedMinutes", activity.estimatedMinutes)
                        .put("isCompleted", activity.isCompleted)
                        .put("topic", activity.topic)
                        .put("actualMinutes", activity.actualMinutes)
                        .put("completedAt", activity.completedAt)
                        .put("linkedTaskId", activity.linkedTaskId ?: JSONObject.NULL)
                        .put("linkedAssessmentId", activity.linkedAssessmentId ?: JSONObject.NULL)
                        .put("resources", resourcesArray)
                )
            }

            val assessmentsArray = JSONArray()
            day.assessments.forEach { assessment ->
                assessmentsArray.put(
                    JSONObject()
                        .put("id", assessment.id)
                        .put("title", assessment.title)
                        .put("description", assessment.description)
                        .put("topic", assessment.topic)
                        .put("scheduledDate", assessment.scheduledDate)
                        .put("availableFrom", assessment.availableFrom)
                        .put("expiresAt", assessment.expiresAt)
                        .put("estimatedMinutes", assessment.estimatedMinutes)
                        .put("status", assessment.status.name)
                        .put("linkedQuizId", assessment.linkedQuizId ?: JSONObject.NULL)
                        .put("completedAt", assessment.completedAt)
                        .put("scorePercent", assessment.scorePercent ?: JSONObject.NULL)
                )
            }

            val allocation = day.timeAllocation
            val allocationJson = JSONObject()
                .put("mandatoryMinutes", allocation.mandatoryMinutes)
                .put("taskMinutes", allocation.taskMinutes)
                .put("resourceMinutes", allocation.resourceMinutes)
                .put("assessmentMinutes", allocation.assessmentMinutes)
                .put("revisionMinutes", allocation.revisionMinutes)
                .put("actualMinutes", allocation.actualMinutes)

            daysArray.put(
                JSONObject()
                    .put("dayNumber", day.dayNumber)
                    .put("title", day.title)
                    .put("objectives", objectivesArray)
                    .put("activities", activitiesArray)
                    .put("estimatedMinutes", day.estimatedMinutes)
                    .put("isCompleted", day.isCompleted)
                    .put("scheduledDate", day.scheduledDate)
                    .put("actualMinutes", day.actualMinutes)
                    .put("timeAllocation", allocationJson)
                    .put("assessments", assessmentsArray)
            )
        }

        return JSONObject()
            .put("id", plan.id)
            .put("title", plan.title)
            .put("goal", plan.goal)
            .put("subject", plan.subject)
            .put("currentLevel", plan.currentLevel)
            .put("targetDays", plan.targetDays)
            .put("dailyStudyMinutes", plan.dailyStudyMinutes)
            .put("createdAt", plan.createdAt)
            .put("updatedAt", plan.updatedAt)
            .put("days", daysArray)
            .put("startDate", plan.startDate)
            .put("status", plan.status.name)
    }

    private fun learningPlanFromJson(
        item: JSONObject
    ): LearningPlan? {
        return try {
            val id = item.optString("id", "")
            val title = item.optString("title", "")
            if (id.isBlank() || title.isBlank()) return null

            val daysArray = item.optJSONArray("days") ?: JSONArray()
            val days = mutableListOf<LearningDay>()

            for (i in 0 until daysArray.length()) {
                val dayItem = daysArray.optJSONObject(i) ?: continue

                val objectivesArray = dayItem.optJSONArray("objectives") ?: JSONArray()
                val objectives = mutableListOf<String>()
                for (j in 0 until objectivesArray.length()) {
                    val objective = objectivesArray.optString(j, "")
                    if (objective.isNotBlank()) objectives.add(objective)
                }

                val activitiesArray = dayItem.optJSONArray("activities") ?: JSONArray()
                val activities = mutableListOf<LearningActivity>()

                for (j in 0 until activitiesArray.length()) {
                    val activityItem = activitiesArray.optJSONObject(j) ?: continue
                    val activityId = activityItem.optString("id", "")
                    val activityTitle = activityItem.optString("title", "")
                    if (activityId.isBlank() || activityTitle.isBlank()) continue

                    val activityType = enumValueOrDefault(
                        activityItem.optString("type", ActivityType.LEARN.name),
                        ActivityType.LEARN
                    )

                    val resourcesArray = activityItem.optJSONArray("resources") ?: JSONArray()
                    val resources = mutableListOf<LearningResource>()
                    for (k in 0 until resourcesArray.length()) {
                        val resourceItem = resourcesArray.optJSONObject(k) ?: continue
                        val resourceId = resourceItem.optString("id", "")
                        val resourceTitle = resourceItem.optString("title", "")
                        if (resourceId.isBlank() || resourceTitle.isBlank()) continue

                        resources.add(
                            LearningResource(
                                id = resourceId,
                                title = resourceTitle,
                                url = resourceItem.optString("url", ""),
                                type = enumValueOrDefault(
                                    resourceItem.optString("type", LearningResourceType.WEBSITE.name),
                                    LearningResourceType.WEBSITE
                                ),
                                provider = resourceItem.optString("provider", ""),
                                description = resourceItem.optString("description", ""),
                                estimatedMinutes = resourceItem.optInt("estimatedMinutes", 0),
                                allocatedMinutes = resourceItem.optInt("allocatedMinutes", 0),
                                topic = resourceItem.optString("topic", "")
                            )
                        )
                    }

                    activities.add(
                        LearningActivity(
                            id = activityId,
                            title = activityTitle,
                            description = activityItem.optString("description", ""),
                            type = activityType,
                            estimatedMinutes = activityItem.optInt("estimatedMinutes", 0),
                            isCompleted = activityItem.optBoolean("isCompleted", false),
                            topic = activityItem.optString("topic", ""),
                            actualMinutes = activityItem.optInt("actualMinutes", 0),
                            completedAt = activityItem.optLong("completedAt", 0L),
                            linkedTaskId = activityItem.optNullableInt("linkedTaskId"),
                            linkedAssessmentId = activityItem.optNullableString("linkedAssessmentId"),
                            resources = resources
                        )
                    )
                }

                val allocationItem = dayItem.optJSONObject("timeAllocation") ?: JSONObject()
                val allocation = DailyTimeAllocation(
                    mandatoryMinutes = allocationItem.optInt("mandatoryMinutes", 0),
                    taskMinutes = allocationItem.optInt("taskMinutes", 0),
                    resourceMinutes = allocationItem.optInt("resourceMinutes", 0),
                    assessmentMinutes = allocationItem.optInt("assessmentMinutes", 0),
                    revisionMinutes = allocationItem.optInt("revisionMinutes", 0),
                    actualMinutes = allocationItem.optInt("actualMinutes", 0)
                )

                val assessmentsArray = dayItem.optJSONArray("assessments") ?: JSONArray()
                val assessments = mutableListOf<PlannedAssessment>()
                for (j in 0 until assessmentsArray.length()) {
                    val assessmentItem = assessmentsArray.optJSONObject(j) ?: continue
                    val assessmentId = assessmentItem.optString("id", "")
                    val assessmentTitle = assessmentItem.optString("title", "")
                    if (assessmentId.isBlank() || assessmentTitle.isBlank()) continue

                    assessments.add(
                        PlannedAssessment(
                            id = assessmentId,
                            title = assessmentTitle,
                            description = assessmentItem.optString("description", ""),
                            topic = assessmentItem.optString("topic", ""),
                            scheduledDate = assessmentItem.optLong("scheduledDate", 0L),
                            availableFrom = assessmentItem.optLong("availableFrom", 0L),
                            expiresAt = assessmentItem.optLong("expiresAt", 0L),
                            estimatedMinutes = assessmentItem.optInt("estimatedMinutes", 0),
                            status = enumValueOrDefault(
                                assessmentItem.optString("status", AssessmentStatus.SCHEDULED.name),
                                AssessmentStatus.SCHEDULED
                            ),
                            linkedQuizId = assessmentItem.optNullableString("linkedQuizId"),
                            completedAt = assessmentItem.optLong("completedAt", 0L),
                            scorePercent = assessmentItem.optNullableInt("scorePercent")
                        )
                    )
                }

                days.add(
                    LearningDay(
                        dayNumber = dayItem.optInt("dayNumber", i + 1),
                        title = dayItem.optString("title", ""),
                        objectives = objectives,
                        activities = activities,
                        estimatedMinutes = dayItem.optInt("estimatedMinutes", 0),
                        isCompleted = dayItem.optBoolean("isCompleted", false),
                        scheduledDate = dayItem.optLong("scheduledDate", 0L),
                        actualMinutes = dayItem.optInt("actualMinutes", 0),
                        timeAllocation = allocation,
                        assessments = assessments
                    )
                )
            }

            LearningPlan(
                id = id,
                title = title,
                goal = item.optString("goal", ""),
                subject = item.optString("subject", ""),
                currentLevel = item.optString("currentLevel", ""),
                targetDays = item.optInt("targetDays", 0),
                dailyStudyMinutes = item.optInt("dailyStudyMinutes", 0),
                createdAt = item.optLong("createdAt", System.currentTimeMillis()),
                days = days,
                updatedAt = item.optLong(
                    "updatedAt",
                    item.optLong("createdAt", System.currentTimeMillis())
                ),
                startDate = item.optLong("startDate", 0L),
                status = enumValueOrDefault(
                    item.optString("status", LearningPlanStatus.ACTIVE.name),
                    LearningPlanStatus.ACTIVE
                )
            )
        } catch (_: Exception) {
            null
        }
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(
        value: String,
        default: T
    ): T {
        return try {
            enumValueOf<T>(value)
        } catch (_: IllegalArgumentException) {
            default
        }
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        return optString(key).takeIf { it.isNotBlank() }
    }

    private fun JSONObject.optNullableInt(key: String): Int? {
        if (!has(key) || isNull(key)) return null
        return optInt(key)
    }

    // --------------------------------------------------
    // SUBJECTS
    // --------------------------------------------------

    fun saveSubjects(subjects: List<Subject>) {
        val oldSubjects = loadSubjects()
        val newIds = subjects.map { it.id }.toSet()

        val deletedIds = loadDeletedSubjectIds().toMutableSet()

        oldSubjects
            .filter { it.id !in newIds }
            .forEach { deletedIds.add(it.id) }

        newIds.forEach { deletedIds.remove(it) }

        preferences.edit()
            .putString(KEY_SUBJECTS, subjectsToJson(subjects))
            .putString(
                KEY_DELETED_SUBJECTS,
                idsToJson(deletedIds)
            )
            .apply()
    }

    fun loadSubjects(): List<Subject> {
        return try {
            val json = preferences.getString(KEY_SUBJECTS, null)
                ?: return emptyList()

            val array = JSONArray(json)
            val result = mutableListOf<Subject>()

            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val name = item.optString("name", "")

                if (item.has("id") && name.isNotBlank()) {
                    result.add(
                        Subject(
                            id = item.getInt("id"),
                            name = name
                        )
                    )
                }
            }

            result.distinctBy { it.id }

        } catch (_: Exception) {
            emptyList()
        }
    }

    fun replaceSubjectsFromSync(subjects: List<Subject>) {
        val deletedIds = loadDeletedSubjectIds().toMutableSet()
        subjects.forEach { deletedIds.remove(it.id) }

        preferences.edit()
            .putString(KEY_SUBJECTS, subjectsToJson(subjects))
            .putString(
                KEY_DELETED_SUBJECTS,
                idsToJson(deletedIds)
            )
            .apply()
    }

    private fun subjectsToJson(
        subjects: List<Subject>
    ): String {
        val array = JSONArray()

        subjects.distinctBy { it.id }.forEach { subject ->
            array.put(
                JSONObject()
                    .put("id", subject.id)
                    .put("name", subject.name)
            )
        }

        return array.toString()
    }

    // --------------------------------------------------
    // TASKS
    // --------------------------------------------------

    fun saveTasks(tasks: List<StudyTask>) {
        val oldTasks = loadTasks()
        val newIds = tasks.map { it.id }.toSet()

        val deletedIds = loadDeletedTaskIds().toMutableSet()

        oldTasks
            .filter { it.id !in newIds }
            .forEach { deletedIds.add(it.id) }

        newIds.forEach { deletedIds.remove(it) }

        preferences.edit()
            .putString(KEY_TASKS, tasksToJson(tasks))
            .putString(
                KEY_DELETED_TASKS,
                idsToJson(deletedIds)
            )
            .apply()
    }

    fun loadTasks(): List<StudyTask> {
        return try {
            val json = preferences.getString(KEY_TASKS, null)
                ?: return emptyList()

            val array = JSONArray(json)
            val result = mutableListOf<StudyTask>()

            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue

                if (!item.has("id") || !item.has("title")) {
                    continue
                }

                result.add(
                    StudyTask(
                        id = item.getInt("id"),
                        title = item.getString("title"),
                        subjectId = if (item.isNull("subjectId")) {
                            null
                        } else {
                            item.optInt("subjectId")
                        },
                        isCompleted = item.optBoolean(
                            "isCompleted",
                            false
                        ),
                        description = item.optString("description", ""),
                        learningPlanId = item.optNullableString("learningPlanId"),
                        learningActivityId = item.optNullableString("learningActivityId"),
                        scheduledDate = item.optLong("scheduledDate", 0L),
                        // Backward compatible: older task records do not contain this field.
                        scheduledDateTime = item.optLong("scheduledDateTime", 0L),
                        estimatedMinutes = item.optInt("estimatedMinutes", 0),
                        actualMinutes = item.optInt("actualMinutes", 0),
                        completedAt = item.optLong("completedAt", 0L),
                        isSkipped = item.optBoolean("isSkipped", false),
                        skippedAt = item.optLong("skippedAt", 0L),
                        resources = readTaskResources(
                            item.optJSONArray("resources")
                        )
                    )
                )
            }

            result.distinctBy { it.id }

        } catch (_: Exception) {
            emptyList()
        }
    }

    fun replaceTasksFromSync(tasks: List<StudyTask>) {
        val deletedIds = loadDeletedTaskIds().toMutableSet()
        tasks.forEach { deletedIds.remove(it.id) }

        preferences.edit()
            .putString(KEY_TASKS, tasksToJson(tasks))
            .putString(
                KEY_DELETED_TASKS,
                idsToJson(deletedIds)
            )
            .apply()
    }

    private fun readTaskResources(
        resourcesArray: JSONArray?
    ): List<LearningResource> {
        if (resourcesArray == null) return emptyList()

        val resources = mutableListOf<LearningResource>()

        for (index in 0 until resourcesArray.length()) {
            val resourceItem = resourcesArray.optJSONObject(index) ?: continue
            val resourceId = resourceItem.optString("id", "")
            val resourceTitle = resourceItem.optString("title", "")

            if (resourceId.isBlank() || resourceTitle.isBlank()) continue

            resources.add(
                LearningResource(
                    id = resourceId,
                    title = resourceTitle,
                    url = resourceItem.optString("url", ""),
                    type = enumValueOrDefault(
                        resourceItem.optString(
                            "type",
                            LearningResourceType.WEBSITE.name
                        ),
                        LearningResourceType.WEBSITE
                    ),
                    provider = resourceItem.optString("provider", ""),
                    description = resourceItem.optString("description", ""),
                    estimatedMinutes = resourceItem.optInt("estimatedMinutes", 0),
                    allocatedMinutes = resourceItem.optInt("allocatedMinutes", 0),
                    topic = resourceItem.optString("topic", "")
                )
            )
        }

        return resources
    }

    private fun tasksToJson(
        tasks: List<StudyTask>
    ): String {
        val array = JSONArray()

        tasks.distinctBy { it.id }.forEach { task ->
            val resourcesArray = JSONArray()
            task.resources.forEach { resource ->
                resourcesArray.put(
                    JSONObject()
                        .put("id", resource.id)
                        .put("title", resource.title)
                        .put("url", resource.url)
                        .put("type", resource.type.name)
                        .put("provider", resource.provider)
                        .put("description", resource.description)
                        .put("estimatedMinutes", resource.estimatedMinutes)
                        .put("allocatedMinutes", resource.allocatedMinutes)
                        .put("topic", resource.topic)
                )
            }

            val item = JSONObject()
                .put("id", task.id)
                .put("title", task.title)
                .put("isCompleted", task.isCompleted)
                .put("description", task.description)
                .put("scheduledDate", task.scheduledDate)
                .put("scheduledDateTime", task.scheduledDateTime)
                .put("estimatedMinutes", task.estimatedMinutes)
                .put("actualMinutes", task.actualMinutes)
                .put("completedAt", task.completedAt)
                .put("isSkipped", task.isSkipped)
                .put("skippedAt", task.skippedAt)
                .put("resources", resourcesArray)

            item.put(
                "subjectId",
                task.subjectId ?: JSONObject.NULL
            )
            item.put(
                "learningPlanId",
                task.learningPlanId ?: JSONObject.NULL
            )
            item.put(
                "learningActivityId",
                task.learningActivityId ?: JSONObject.NULL
            )

            array.put(item)
        }

        return array.toString()
    }

    // --------------------------------------------------
    // DELETION TRACKING
    // --------------------------------------------------

    fun loadDeletedSubjectIds(): Set<Int> {
        return loadIds(KEY_DELETED_SUBJECTS)
    }

    fun loadDeletedTaskIds(): Set<Int> {
        return loadIds(KEY_DELETED_TASKS)
    }

    fun markSubjectDeleted(id: Int) {
        val ids = loadDeletedSubjectIds().toMutableSet()
        ids.add(id)

        preferences.edit()
            .putString(KEY_DELETED_SUBJECTS, idsToJson(ids))
            .apply()
    }

    fun markTaskDeleted(id: Int) {
        val ids = loadDeletedTaskIds().toMutableSet()
        ids.add(id)

        preferences.edit()
            .putString(KEY_DELETED_TASKS, idsToJson(ids))
            .apply()
    }

    fun clearDeletedSubjectIds(ids: Set<Int>) {
        val remaining = loadDeletedSubjectIds() - ids

        preferences.edit()
            .putString(
                KEY_DELETED_SUBJECTS,
                idsToJson(remaining)
            )
            .apply()
    }

    fun clearDeletedTaskIds(ids: Set<Int>) {
        val remaining = loadDeletedTaskIds() - ids

        preferences.edit()
            .putString(
                KEY_DELETED_TASKS,
                idsToJson(remaining)
            )
            .apply()
    }

    private fun loadIds(key: String): Set<Int> {
        return try {
            val json = preferences.getString(key, null)
                ?: return emptySet()

            val array = JSONArray(json)

            buildSet {
                for (i in 0 until array.length()) {
                    add(array.getInt(i))
                }
            }

        } catch (_: Exception) {
            emptySet()
        }
    }

    private fun idsToJson(
        ids: Collection<Int>
    ): String {
        val array = JSONArray()

        ids.sorted().forEach {
            array.put(it)
        }

        return array.toString()
    }

    // --------------------------------------------------
    // FOCUS SESSION SUMMARY
    // --------------------------------------------------

    fun saveFocusSessions(
        sessionCount: Int,
        totalMinutes: Int
    ) {
        preferences.edit()
            .putInt("focus_sessions", sessionCount)
            .putInt("focus_minutes", totalMinutes)
            .apply()
    }

    fun loadFocusSessionCount(): Int {
        return preferences.getInt("focus_sessions", 0)
    }

    fun loadFocusMinutes(): Int {
        return preferences.getInt("focus_minutes", 0)
    }

    // --------------------------------------------------
    // FOCUS SESSION RECORDS
    // --------------------------------------------------

    fun saveFocusSession(session: FocusSession) {
        val sessions = loadFocusSessions().toMutableList()

        val index = sessions.indexOfFirst {
            it.id == session.id
        }

        if (index >= 0) {
            sessions[index] = session
        } else {
            sessions.add(session)
        }

        replaceFocusSessions(sessions)

        saveFocusSessions(
            sessionCount = sessions.size,
            totalMinutes = sessions.sumOf { it.minutes }
        )
    }

    fun replaceFocusSessions(sessions: List<FocusSession>) {
        val array = JSONArray()

        sessions.distinctBy { it.id }.forEach { session ->
            array.put(
                JSONObject()
                    .put("id", session.id)
                    .put("minutes", session.minutes)
                    .put("timestamp", session.timestamp)
                    .put(
                        "subjectId",
                        session.subjectId ?: JSONObject.NULL
                    )
                    .put(
                        "taskId",
                        session.taskId ?: JSONObject.NULL
                    )
                    .put("learningPlanId", session.learningPlanId ?: JSONObject.NULL)
                    .put("learningActivityId", session.learningActivityId ?: JSONObject.NULL)
                    .put("startedAt", session.startedAt)
                    .put("endedAt", session.endedAt)
                    .put("completed", session.completed)
            )
        }

        preferences.edit()
            .putString(KEY_FOCUS_SESSIONS, array.toString())
            .apply()
    }

    fun loadFocusSessions(): List<FocusSession> {
        return try {
            val json = preferences.getString(
                KEY_FOCUS_SESSIONS,
                null
            ) ?: return emptyList()

            val array = JSONArray(json)
            val sessions = mutableListOf<FocusSession>()

            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue

                if (
                    !item.has("id") ||
                    !item.has("minutes") ||
                    !item.has("timestamp")
                ) {
                    continue
                }

                sessions.add(
                    FocusSession(
                        id = item.getLong("id"),
                        minutes = item.getInt("minutes"),
                        timestamp = item.getLong("timestamp"),
                        subjectId = if (item.isNull("subjectId")) {
                            null
                        } else {
                            item.getInt("subjectId")
                        },
                        taskId = if (item.isNull("taskId")) {
                            null
                        } else {
                            item.getInt("taskId")
                        },
                        learningPlanId = item.optNullableString("learningPlanId"),
                        learningActivityId = item.optNullableString("learningActivityId"),
                        startedAt = item.optLong("startedAt", 0L),
                        endedAt = item.optLong("endedAt", 0L),
                        completed = item.optBoolean("completed", true)
                    )
                )
            }

            sessions.distinctBy { it.id }

        } catch (_: Exception) {
            emptyList()
        }
    }

    fun getTodayFocusSessions(): List<FocusSession> {
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val end = Calendar.getInstance().apply {
            timeInMillis = start
            add(Calendar.DAY_OF_MONTH, 1)
        }.timeInMillis

        return loadFocusSessions().filter {
            it.timestamp >= start && it.timestamp < end
        }
    }

    fun getTodayFocusMinutes(): Int {
        return getTodayFocusSessions().sumOf { it.minutes }
    }

    // --------------------------------------------------
    // ACTIVE FOCUS SESSION
    // --------------------------------------------------

    fun saveActiveFocusSession(
        durationMinutes: Int,
        endTime: Long,
        remainingSeconds: Int,
        isPaused: Boolean,
        subjectId: Int? = null,
        taskId: Int? = null
    ) {
        preferences.edit()
            .putBoolean("active_focus", true)
            .putInt("focus_duration_minutes", durationMinutes)
            .putLong("focus_end_time", endTime)
            .putInt("focus_remaining_seconds", remainingSeconds)
            .putBoolean("focus_is_paused", isPaused)
            .putInt("focus_subject_id", subjectId ?: -1)
            .putInt("focus_task_id", taskId ?: -1)
            .apply()
    }

    fun hasActiveFocusSession(): Boolean {
        return preferences.getBoolean("active_focus", false)
    }

    fun loadFocusDuration(): Int {
        return preferences.getInt("focus_duration_minutes", 25)
    }

    fun loadFocusEndTime(): Long {
        return preferences.getLong("focus_end_time", 0L)
    }

    fun loadFocusRemainingSeconds(): Int {
        return preferences.getInt(
            "focus_remaining_seconds",
            25 * 60
        )
    }

    fun loadFocusPaused(): Boolean {
        return preferences.getBoolean("focus_is_paused", false)
    }

    fun loadFocusSubjectId(): Int? {
        val id = preferences.getInt("focus_subject_id", -1)
        return if (id == -1) null else id
    }

    fun loadFocusTaskId(): Int? {
        val id = preferences.getInt("focus_task_id", -1)
        return if (id == -1) null else id
    }

    fun clearActiveFocusSession() {
        preferences.edit()
            .remove("active_focus")
            .remove("focus_duration_minutes")
            .remove("focus_end_time")
            .remove("focus_remaining_seconds")
            .remove("focus_is_paused")
            .remove("focus_subject_id")
            .remove("focus_task_id")
            .apply()
    }

    // --------------------------------------------------
    // SYNC ACCOUNT OWNERSHIP
    // --------------------------------------------------

    fun getSyncOwnerUid(): String? {
        return preferences.getString(KEY_SYNC_OWNER_UID, null)
    }

    fun setSyncOwnerUid(uid: String) {
        require(uid.isNotBlank()) {
            "Firebase UID cannot be blank."
        }

        preferences.edit()
            .putString(KEY_SYNC_OWNER_UID, uid)
            .apply()
    }

    // --------------------------------------------------
    // LEGACY DATA OWNERSHIP
    // --------------------------------------------------

    /**
     * Returns the owner recorded in the old device-wide preferences.
     * If the old data was explicitly claimed, returns that claimed UID.
     */
    fun getLegacyDataOwnerUid(): String? {
        val legacy = appContext.getSharedPreferences(
            LEGACY_PREFERENCES_NAME,
            Context.MODE_PRIVATE
        )

        val originalOwner = legacy.getString(
            KEY_SYNC_OWNER_UID,
            null
        )

        if (!originalOwner.isNullOrBlank()) {
            return originalOwner
        }

        return appContext.getSharedPreferences(
            LEGACY_CLAIM_PREFERENCES_NAME,
            Context.MODE_PRIVATE
        ).getString(KEY_LEGACY_CLAIMED_UID, null)
    }

    /**
     * Checks the old student and gamification preference files.
     * Does not modify or delete either file.
     */
    fun hasLegacyLocalData(): Boolean {
        val legacy = appContext.getSharedPreferences(
            LEGACY_PREFERENCES_NAME,
            Context.MODE_PRIVATE
        )

        val hasStudentData = legacy.all.keys.any {
            it != KEY_SYNC_OWNER_UID
        }

        val legacyGamification = appContext.getSharedPreferences(
            LEGACY_GAMIFICATION_PREFERENCES_NAME,
            Context.MODE_PRIVATE
        )

        return hasStudentData ||
            legacyGamification.all.isNotEmpty()
    }

    // --------------------------------------------------
    // SAFE LEGACY MIGRATION
    // --------------------------------------------------

    /**
     * Migrates legacy student preferences only when the recorded
     * or explicitly claimed owner matches this account UID.
     *
     * Unknown ownership requires explicit confirmation.
     * Legacy preferences are never modified or deleted.
     */
    fun migrateLegacyDataIfSafe(): LegacyMigrationStatus {
        val uid = accountUid?.takeIf { it.isNotBlank() }
            ?: return LegacyMigrationStatus.NOT_ACCOUNT_SCOPED

        synchronized(migrationLock) {

            if (
                preferences.getBoolean(
                    KEY_MIGRATION_COMPLETED,
                    false
                )
            ) {
                return LegacyMigrationStatus.ALREADY_MIGRATED
            }

            val legacy = appContext.getSharedPreferences(
                LEGACY_PREFERENCES_NAME,
                Context.MODE_PRIVATE
            )

            val legacyData = legacy.all.filterKeys {
                it != KEY_SYNC_OWNER_UID &&
                    it != KEY_MIGRATION_COMPLETED
            }

            if (legacyData.isEmpty()) {
                return LegacyMigrationStatus.NO_LEGACY_DATA
            }

            val legacyOwner = getLegacyDataOwnerUid()

            if (legacyOwner.isNullOrBlank()) {
                return LegacyMigrationStatus.OWNERSHIP_CONFIRMATION_REQUIRED
            }

            if (legacyOwner != uid) {
                return LegacyMigrationStatus.OWNER_MISMATCH
            }

            return copyLegacyPreferences(
                legacyData = legacyData,
                uid = uid
            )
        }
    }

    /**
     * Claims unowned legacy student data after explicit user confirmation.
     *
     * A claim already assigned to another UID cannot be transferred.
     * The claim is persisted before copying, so a process interruption
     * cannot make the archive available for another account to claim.
     *
     * The same UID can safely retry if copying fails.
     */
    fun claimLegacyDataForCurrentUser(
        confirmedOwnership: Boolean
    ): LegacyMigrationStatus {

        val uid = accountUid?.takeIf { it.isNotBlank() }
            ?: return LegacyMigrationStatus.NOT_ACCOUNT_SCOPED

        if (!confirmedOwnership) {
            return LegacyMigrationStatus.OWNERSHIP_CONFIRMATION_REQUIRED
        }

        synchronized(migrationLock) {

            if (
                preferences.getBoolean(
                    KEY_MIGRATION_COMPLETED,
                    false
                )
            ) {
                return LegacyMigrationStatus.ALREADY_MIGRATED
            }

            val legacy = appContext.getSharedPreferences(
                LEGACY_PREFERENCES_NAME,
                Context.MODE_PRIVATE
            )

            val legacyData = legacy.all.filterKeys {
                it != KEY_SYNC_OWNER_UID &&
                    it != KEY_MIGRATION_COMPLETED
            }

            if (legacyData.isEmpty()) {
                return LegacyMigrationStatus.NO_LEGACY_DATA
            }

            val originalOwner = legacy.getString(
                KEY_SYNC_OWNER_UID,
                null
            )

            if (
                !originalOwner.isNullOrBlank() &&
                originalOwner != uid
            ) {
                return LegacyMigrationStatus.OWNER_MISMATCH
            }

            val claimPreferences = appContext.getSharedPreferences(
                LEGACY_CLAIM_PREFERENCES_NAME,
                Context.MODE_PRIVATE
            )

            val existingClaim = claimPreferences.getString(
                KEY_LEGACY_CLAIMED_UID,
                null
            )

            if (
                !existingClaim.isNullOrBlank() &&
                existingClaim != uid
            ) {
                return LegacyMigrationStatus.OWNER_MISMATCH
            }

            if (originalOwner.isNullOrBlank()) {

                val claimSaved = claimPreferences.edit()
                    .putString(KEY_LEGACY_CLAIMED_UID, uid)
                    .commit()

                if (!claimSaved) {
                    return LegacyMigrationStatus.FAILED
                }
            }

            return copyLegacyPreferences(
                legacyData = legacyData,
                uid = uid
            )
        }
    }

    /**
     * Copies supported SharedPreferences values using their original types.
     *
     * The practice_quiz_results key is copied automatically because
     * it exists in the same legacy preferences file.
     */
    private fun copyLegacyPreferences(
        legacyData: Map<String, *>,
        uid: String
    ): LegacyMigrationStatus {

        if (
            preferences.getBoolean(
                KEY_MIGRATION_COMPLETED,
                false
            )
        ) {
            return LegacyMigrationStatus.ALREADY_MIGRATED
        }

        return try {
            val destinationOwner = preferences.getString(
                KEY_SYNC_OWNER_UID,
                null
            )

            if (
                !destinationOwner.isNullOrBlank() &&
                destinationOwner != uid
            ) {
                return LegacyMigrationStatus.OWNER_MISMATCH
            }

            val destinationData = preferences.all
            val editor = preferences.edit()

            legacyData.forEach { (key, legacyValue) ->
                val destinationHasKey = destinationData.containsKey(key)
                val destinationValue = destinationData[key]

                // Never overwrite an account's existing scalar value.
                // For known record collections, merge by stable ID instead.
                val valueToStore = if (!destinationHasKey) {
                    legacyValue
                } else {
                    mergeLegacyPreferenceValue(
                        key = key,
                        destinationValue = destinationValue,
                        legacyValue = legacyValue
                    )
                }

                when (valueToStore) {
                    is String -> editor.putString(key, valueToStore)
                    is Int -> editor.putInt(key, valueToStore)
                    is Long -> editor.putLong(key, valueToStore)
                    is Float -> editor.putFloat(key, valueToStore)
                    is Boolean -> editor.putBoolean(key, valueToStore)
                    is Set<*> -> {
                        editor.putStringSet(
                            key,
                            valueToStore.filterIsInstance<String>().toMutableSet()
                        )
                    }
                    null -> {
                        // A null legacy value must never erase existing account data.
                        if (!destinationHasKey) editor.remove(key)
                    }
                    else -> throw IllegalArgumentException(
                        "Unsupported legacy preference type for key: $key"
                    )
                }
            }

            val committed = editor
                .putString(KEY_SYNC_OWNER_UID, uid)
                .putBoolean(KEY_MIGRATION_COMPLETED, true)
                .commit()

            if (committed) {
                LegacyMigrationStatus.MIGRATED
            } else {
                LegacyMigrationStatus.FAILED
            }
        } catch (_: Exception) {
            LegacyMigrationStatus.FAILED
        }
    }

    /**
     * Merges legacy preference values without overwriting account data.
     *
     * The account-scoped value always wins when the same record ID exists.
     * Missing legacy records are appended, so records that exist only in
     * the legacy archive are not silently discarded.
     */
    private fun mergeLegacyPreferenceValue(
        key: String,
        destinationValue: Any?,
        legacyValue: Any?
    ): Any? {
        if (destinationValue == null) return legacyValue
        if (legacyValue == null) return destinationValue

        if (destinationValue is String && legacyValue is String) {
            if (key in JSON_ARRAY_MERGE_KEYS) {
                return mergeJsonArrayStrings(
                    destinationJson = destinationValue,
                    legacyJson = legacyValue
                )
            }

            return destinationValue
        }

        if (destinationValue is Set<*> && legacyValue is Set<*>) {
            return (
                destinationValue.filterIsInstance<String>() +
                    legacyValue.filterIsInstance<String>()
                ).toSet()
        }

        // Keep the destination's original type and value on conflicts.
        return destinationValue
    }

    /**
     * Merges JSON arrays by record identity. Destination records are inserted
     * first and therefore take precedence over legacy records with the same ID.
     */
    private fun mergeJsonArrayStrings(
        destinationJson: String,
        legacyJson: String
    ): String {
        val destinationArray = JSONArray(destinationJson)
        val legacyArray = JSONArray(legacyJson)
        val merged = JSONArray()
        val seen = LinkedHashSet<String>()

        fun append(item: Any?) {
            if (item == null || item === JSONObject.NULL) return

            val identity = when (item) {
                is JSONObject -> {
                    val idKey = RECORD_ID_KEYS.firstOrNull { candidate ->
                        item.has(candidate) && !item.isNull(candidate) &&
                            item.optString(candidate).isNotBlank()
                    }

                    if (idKey != null) {
                        "$idKey:${item.optString(idKey)}"
                    } else {
                        "json:${item.toString()}"
                    }
                }
                else -> "value:${item}"
            }

            if (seen.add(identity)) {
                merged.put(item)
            }
        }

        for (index in 0 until destinationArray.length()) {
            append(destinationArray.opt(index))
        }

        for (index in 0 until legacyArray.length()) {
            append(legacyArray.opt(index))
        }

        return merged.toString()
    }

    // --------------------------------------------------
    // LOCAL DATA DETECTION
    // --------------------------------------------------

    /**
     * Detects local student data, including:
     *
     * - Subjects
     * - Tasks
     * - Focus sessions
     * - Deleted subject/task IDs
     * - Learning plans
     * - Learning Coach profile
     * - Initial assessments
     * - Practice history
     * - Active focus session
     * - Focus summaries
     * - Gamification data
     *
     * The gamification preferences checked depend on the storage scope.
     */
    fun hasLocalSyncData(): Boolean {

        val hasStudentData = preferences.all.keys.any {
            it != KEY_SYNC_OWNER_UID &&
                it != KEY_MIGRATION_COMPLETED
        }

        val gamificationPreferencesName =
            if (accountUid == null) {
                LEGACY_GAMIFICATION_PREFERENCES_NAME
            } else {
                ACCOUNT_GAMIFICATION_PREFIX + accountUid
            }

        val hasGamificationData = appContext.getSharedPreferences(
            gamificationPreferencesName,
            Context.MODE_PRIVATE
        ).all.isNotEmpty()

        return hasStudentData || hasGamificationData
    }
}