
package com.studentcompanionai.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

private val PageBackground = Color(0xFF0A0F1C)
private val CardBackground = Color(0xFF111827)
private val MutedText = Color(0xFF9CAAC0)
private val CyanAccent = Color(0xFF67E8F9)
private val PurpleAccent = Color(0xFFA5B4FC)
private val GreenAccent = Color(0xFF6EE7B7)

@Composable
fun HomeScreen(
    focusSessions: Int,
    focusMinutes: Int,
    totalTasks: Int,
    completedTasks: Int,
    subjectCount: Int,
    onSubjectsClick: () -> Unit,
    onTasksClick: () -> Unit,
    onFocusClick: () -> Unit,
    onStatisticsClick: () -> Unit,
    onAIChatClick: () -> Unit,
    onLearningPlansClick: () -> Unit = {},
    onLearningCoachClick: () -> Unit = {},
    preferredName: String = "Learner",
    profilePhotoUrl: String? = null
) {
    val dailyGoal = 120

    val progress = (focusMinutes.toFloat() / dailyGoal)
        .coerceIn(0f, 1f)

    val hour = java.util.Calendar.getInstance()
        .get(java.util.Calendar.HOUR_OF_DAY)

    val greeting = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..20 -> "Good evening"
        else -> "Good night"
    }

    val displayName = preferredName
        .trim()
        .ifBlank { "Learner" }

    // Load the signed-in account's profile picture.
    val profileBitmap by produceState<Bitmap?>(
        initialValue = null,
        key1 = profilePhotoUrl
    ) {
        value = null

        if (!profilePhotoUrl.isNullOrBlank()) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val connection = URL(profilePhotoUrl)
                        .openConnection()

                    connection.connectTimeout = 8000
                    connection.readTimeout = 8000

                    connection.getInputStream().use { stream ->
                        BitmapFactory.decodeStream(stream)
                    }
                }.getOrNull()
            }
        }
    }

    val initials = displayName
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") {
            it.first().uppercase()
        }
        .ifBlank { "S" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PageBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {

        // PERSONALIZED WELCOME HEADER
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text(
                    text = "$greeting, $displayName!",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyanAccent,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = "SCAI is Here for You!",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                Text(
                    text = "Your Personal Educational Agent.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF283957)),
                contentAlignment = Alignment.Center
            ) {
                if (profileBitmap != null) {
                    Image(
                        bitmap = profileBitmap!!.asImageBitmap(),
                        contentDescription = "Account profile picture",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Text(
                        text = initials,
                        color = CyanAccent,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        // PRIMARY FEATURE: UNIVERSAL AI LEARNING COACH
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onLearningCoachClick),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF173849)
            )
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(
                                Color(0xFF24516A),
                                RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "AI",
                            color = CyanAccent,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = "YOUR PERSONAL LEARNING COACH",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanAccent,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Learn without limits.",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = "Your AI-powered learning journey starts here.",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = "Set your goals, build personalized learning plans, " +
                        "understand concepts, practise skills and track your progress.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFD0E4EC)
                )

                Button(
                    onClick = onLearningCoachClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = Color(0xFF06202A)
                    )
                ) {
                    Text(
                        text = "Start Learning with AI  →",
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "LEARN  •  PRACTISE  •  TEST  •  PROGRESS",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFB9DCE5),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // DAILY FOCUS OVERVIEW
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SectionHeading("TODAY'S FOCUS")

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = CardBackground
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Focus time",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )

                            Text(
                                text = "$focusMinutes min",
                                style = MaterialTheme.typography.headlineMedium,
                                color = CyanAccent,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = "of $dailyGoal minutes",
                                style = MaterialTheme.typography.bodySmall,
                                color = MutedText
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .background(
                                    color = Color(0xFF183440),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${(progress * 100).toInt()}%",
                                color = CyanAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = CyanAccent,
                        trackColor = Color(0xFF293447)
                    )

                    Text(
                        text = when {
                            focusMinutes >= dailyGoal ->
                                "Daily goal reached. Keep your progress sustainable."

                            focusMinutes == 0 ->
                                "Start with one focused session."

                            else ->
                                "${dailyGoal - focusMinutes} minutes left to reach your goal."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedText
                    )

                    Text(
                        text = "Start a focus session  →",
                        modifier = Modifier
                            .clickable(onClick = onFocusClick)
                            .padding(vertical = 4.dp),
                        color = CyanAccent,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // PROGRESS METRICS
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SectionHeading("YOUR PROGRESS")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Sessions",
                    value = focusSessions.toString(),
                    accent = PurpleAccent,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = "Tasks done",
                    value = "$completedTasks/$totalTasks",
                    accent = GreenAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // WORKSPACE
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SectionHeading("YOUR WORKSPACE")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                WorkspaceCard(
                    title = "Subjects",
                    description = "$subjectCount subjects",
                    symbol = "01",
                    accent = CyanAccent,
                    modifier = Modifier.weight(1f),
                    onClick = onSubjectsClick
                )

                WorkspaceCard(
                    title = "Tasks",
                    description = "${(totalTasks - completedTasks).coerceAtLeast(0)} remaining",
                    symbol = "02",
                    accent = PurpleAccent,
                    modifier = Modifier.weight(1f),
                    onClick = onTasksClick
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                WorkspaceCard(
                    title = "Focus",
                    description = "Study timer",
                    symbol = "03",
                    accent = GreenAccent,
                    modifier = Modifier.weight(1f),
                    onClick = onFocusClick
                )

                WorkspaceCard(
                    title = "Statistics",
                    description = "View progress",
                    symbol = "04",
                    accent = Color(0xFFFBBF74),
                    modifier = Modifier.weight(1f),
                    onClick = onStatisticsClick
                )
            }

            WorkspaceCard(
                title = "Learning Plans",
                description = "View saved plans and completion progress",
                symbol = "05",
                accent = CyanAccent,
                modifier = Modifier.fillMaxWidth(),
                onClick = onLearningPlansClick
            )
        }

        // GENERAL AI ASSISTANT
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onAIChatClick),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF19263B)
            )
        ) {
            Row(
                modifier = Modifier.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(
                            Color(0xFF283957),
                            RoundedCornerShape(14.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "AI",
                        color = PurpleAccent,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "General AI assistant",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Ask questions and explore topics freely.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedText
                    )
                }

                Text(
                    text = "›",
                    style = MaterialTheme.typography.headlineMedium,
                    color = PurpleAccent
                )
            }
        }

        Text(
            text = "LEARN  •  PRACTISE  •  PROGRESS",
            modifier = Modifier.fillMaxWidth(),
            style = MaterialTheme.typography.labelSmall,
            color = MutedText
        )

        Spacer(modifier = Modifier.height(4.dp))
    }
}

@Composable
private fun SectionHeading(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium,
        color = MutedText,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = CardBackground
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(accent, CircleShape)
            )

            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MutedText
            )
        }
    }
}

@Composable
private fun WorkspaceCard(
    title: String,
    description: String,
    symbol: String,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = CardBackground
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = symbol,
                style = MaterialTheme.typography.labelMedium,
                color = accent,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MutedText
            )
        }
    }
}
