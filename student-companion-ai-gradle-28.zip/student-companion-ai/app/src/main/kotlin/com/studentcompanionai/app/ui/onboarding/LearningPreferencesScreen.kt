
package com.studentcompanionai.app.ui.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val languageOptions = listOf(
    "English",
    "Hindi",
    "Marathi",
    "Gujarati",
    "Tamil",
    "Telugu",
    "Kannada",
    "Bengali",
    "Other"
)

private val difficultyOptions = listOf(
    "Easy",
    "Moderate",
    "Challenging",
    "Adaptive"
)

private val difficultyAreas = listOf(
    "Understanding concepts",
    "Remembering information",
    "Solving problems",
    "Time management",
    "Concentration",
    "Consistency",
    "Applying theory practically",
    "Exam preparation",
    "Writing answers",
    "Programming logic"
)

@Composable
fun LearningPreferencesScreen(
    initialLanguage: String = "English",
    initialDifficulty: String = "ADAPTIVE",
    initialAreasOfDifficulty: List<String> = emptyList(),
    initialNotificationsEnabled: Boolean = true,
    initialStudyReminders: Boolean = true,
    initialGoalReminders: Boolean = true,
    initialProgressUpdates: Boolean = true,
    onBack: () -> Unit,
    onContinue: (
        preferredLanguage: String,
        preferredDifficulty: String,
        areasOfDifficulty: List<String>,
        notificationsEnabled: Boolean,
        studyReminders: Boolean,
        goalReminders: Boolean,
        progressUpdates: Boolean
    ) -> Unit
) {
    var language by rememberSaveable {
        mutableStateOf(initialLanguage)
    }

    var customLanguage by rememberSaveable {
        mutableStateOf("")
    }

    var difficulty by rememberSaveable {
        mutableStateOf(initialDifficulty)
    }

    // Saveable immutable list.
    var selectedAreas by rememberSaveable {
        mutableStateOf(initialAreasOfDifficulty.toList())
    }

    var notificationsEnabled by rememberSaveable {
        mutableStateOf(initialNotificationsEnabled)
    }

    var studyReminders by rememberSaveable {
        mutableStateOf(initialStudyReminders)
    }

    var goalReminders by rememberSaveable {
        mutableStateOf(initialGoalReminders)
    }

    var progressUpdates by rememberSaveable {
        mutableStateOf(initialProgressUpdates)
    }

    val finalLanguage = if (language == "Other") {
        customLanguage.trim()
    } else {
        language
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {

        TextButton(onClick = onBack) {
            Text("← Back")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Personalise your learning experience",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Tell us how you prefer to learn. SCAI will use these preferences to make explanations, practice and study support more suitable for you.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Preferred language")

        Text(
            text = "Which language would you prefer for explanations and learning support?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            languageOptions.chunked(2).forEach { languageRow ->

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    languageRow.forEach { option ->

                        FilterChip(
                            selected = language == option,
                            onClick = {
                                language = option
                            },
                            label = {
                                Text(option)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (language == "Other") {

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = customLanguage,
                onValueChange = {
                    customLanguage = it
                },
                modifier = Modifier.fillMaxWidth(),
                label = {
                    Text("Enter your language")
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Preferred difficulty")

        Text(
            text = "How challenging should your learning activities be?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            difficultyOptions.forEach { option ->

                val value = option.uppercase()

                FilterChip(
                    selected = difficulty == value,
                    onClick = {
                        difficulty = value
                    },
                    label = {
                        Text(option)
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Where do you need more help?")

        Text(
            text = "Select all the areas where you face difficulties. This helps SCAI identify where you may need additional support.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            difficultyAreas.chunked(2).forEach { areaRow ->

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    areaRow.forEach { area ->

                        FilterChip(
                            selected = selectedAreas.contains(area),
                            onClick = {

                                selectedAreas =
                                    if (selectedAreas.contains(area)) {
                                        selectedAreas.filterNot {
                                            it == area
                                        }
                                    } else {
                                        selectedAreas + area
                                    }
                            },
                            label = {
                                Text(area)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Notification preferences")

        Text(
            text = "Choose which notifications you want to receive from SCAI.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        PreferenceSwitch(
            title = "Enable notifications",
            description = "Allow SCAI to send notifications.",
            checked = notificationsEnabled,
            onCheckedChange = {
                notificationsEnabled = it
            }
        )

        PreferenceSwitch(
            title = "Study reminders",
            description = "Reminders about your planned study sessions.",
            checked = studyReminders,
            enabled = notificationsEnabled,
            onCheckedChange = {
                studyReminders = it
            }
        )

        PreferenceSwitch(
            title = "Goal reminders",
            description = "Reminders to keep working towards your goals.",
            checked = goalReminders,
            enabled = notificationsEnabled,
            onCheckedChange = {
                goalReminders = it
            }
        )

        PreferenceSwitch(
            title = "Progress updates",
            description = "Updates about your learning progress and achievements.",
            checked = progressUpdates,
            enabled = notificationsEnabled,
            onCheckedChange = {
                progressUpdates = it
            }
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                onContinue(
                    finalLanguage,
                    difficulty,
                    selectedAreas.toList(),
                    notificationsEnabled,
                    studyReminders,
                    goalReminders,
                    progressUpdates
                )
            },
            enabled = finalLanguage.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                text = "Continue",
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun PreferenceSwitch(
    title: String,
    description: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = if (enabled) {
                    MaterialTheme.colorScheme.onSurface
                } else {
                    MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
                }
            )

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled
        )
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(10.dp))
}
