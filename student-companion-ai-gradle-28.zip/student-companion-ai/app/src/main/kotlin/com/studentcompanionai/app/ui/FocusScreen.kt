
package com.studentcompanionai.app.ui

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.FocusSession
import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiSecondaryButton
import com.studentcompanionai.app.ui.components.ScaiSectionTitle
import com.studentcompanionai.app.ui.components.ScaiTopBar
import kotlinx.coroutines.delay

@Composable
fun FocusScreen(
    context: Context,
    onBackClick: () -> Unit,
    onSessionCompleted: (FocusSession) -> Unit = {},
    onStartActiveFocus: () -> Unit,
    uid: String? = FirebaseAuth.getInstance().currentUser?.uid
) {

    val auth = remember {
        FirebaseAuth.getInstance()
    }

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    fun isCurrentAccount(): Boolean {
        return uid != null && auth.currentUser?.uid == uid
    }

    // -----------------------------------------
    // ACCOUNT DATA
    // -----------------------------------------

    val subjects = remember(uid) {
        storage.loadSubjects()
    }

    val allTasks = remember(uid) {
        storage.loadTasks()
    }

    var hasSavedSession by remember(uid) {
        mutableStateOf(storage.hasActiveFocusSession())
    }

    var selectedSubjectId by remember(uid) {
        mutableStateOf(storage.loadFocusSubjectId())
    }

    var selectedTaskId by remember(uid) {
        mutableStateOf(storage.loadFocusTaskId())
    }

    var selectedMinutes by remember(uid) {
        mutableStateOf(
            if (storage.hasActiveFocusSession()) {
                storage.loadFocusDuration().coerceIn(5, 90).toFloat()
            } else {
                25f
            }
        )
    }

    var subjectMenuExpanded by remember(uid) {
        mutableStateOf(false)
    }

    var taskMenuExpanded by remember(uid) {
        mutableStateOf(false)
    }

    // -----------------------------------------
    // TIMER STATE
    // -----------------------------------------

    var savedRemainingSeconds by remember(uid) {
        mutableIntStateOf(
            if (!hasSavedSession) {
                0
            } else if (storage.loadFocusPaused()) {
                storage.loadFocusRemainingSeconds().coerceAtLeast(0)
            } else {
                (
                    (
                        storage.loadFocusEndTime() -
                            System.currentTimeMillis() + 999L
                    ) / 1000L
                ).coerceAtLeast(0L).toInt()
            }
        )
    }

    var completionInProgress by remember(uid) {
        mutableStateOf(false)
    }

    var completedSessionId by remember(uid) {
        mutableStateOf<Long?>(null)
    }

    // -----------------------------------------
    // AUTOMATIC SESSION COMPLETION
    // -----------------------------------------

    LaunchedEffect(uid, hasSavedSession) {

        if (
            uid == null ||
            !hasSavedSession ||
            !isCurrentAccount()
        ) {
            return@LaunchedEffect
        }

        while (
            isCurrentAccount() &&
            hasSavedSession &&
            !completionInProgress
        ) {

            val isPaused = storage.loadFocusPaused()

            if (isPaused) {
                savedRemainingSeconds =
                    storage.loadFocusRemainingSeconds()
                        .coerceAtLeast(0)

                break
            }

            val endTime = storage.loadFocusEndTime()

            val remainingMillis =
                endTime - System.currentTimeMillis()

            val updatedSeconds = (
                (remainingMillis + 999L) / 1000L
            ).coerceAtLeast(0L).toInt()

            savedRemainingSeconds = updatedSeconds

            if (updatedSeconds <= 0) {

                if (
                    !isCurrentAccount() ||
                    completionInProgress
                ) {
                    break
                }

                completionInProgress = true

                val durationMinutes =
                    storage.loadFocusDuration()

                val subjectId =
                    storage.loadFocusSubjectId()

                val taskId =
                    storage.loadFocusTaskId()

                val completionTime =
                    System.currentTimeMillis()

                val session = FocusSession(
                    id = completionTime,
                    minutes = durationMinutes,
                    timestamp = completionTime,
                    subjectId = subjectId,
                    taskId = taskId
                )

                if (taskId != null) {

                    val updatedTasks =
                        storage.loadTasks().map { task ->

                            if (task.id == taskId) {
                                task.copy(isCompleted = true)
                            } else {
                                task
                            }
                        }

                    if (!isCurrentAccount()) {
                        completionInProgress = false
                        break
                    }

                    storage.saveTasks(updatedTasks)
                }

                if (!isCurrentAccount()) {
                    completionInProgress = false
                    break
                }

                storage.clearActiveFocusSession()

                completedSessionId = session.id

                hasSavedSession = false
                savedRemainingSeconds = 0

                completionInProgress = false

                onSessionCompleted(session)

                break
            }

            delay(250L)
        }
    }

    // -----------------------------------------
    // SUBJECT AND TASK SELECTION
    // -----------------------------------------

    val selectedSubject = subjects.firstOrNull {
        it.id == selectedSubjectId
    }

    val availableTasks = if (selectedSubjectId != null) {
        allTasks.filter {
            it.subjectId == selectedSubjectId && !it.isCompleted
        }
    } else {
        emptyList()
    }

    val selectedTask = availableTasks.firstOrNull {
        it.id == selectedTaskId
    }

    // -----------------------------------------
    // TIMER DISPLAY
    // -----------------------------------------

    val previewSeconds = if (hasSavedSession) {
        savedRemainingSeconds.coerceAtLeast(0)
    } else {
        selectedMinutes.toInt() * 60
    }

    val totalSeconds = selectedMinutes.toInt() * 60

    val progress = if (totalSeconds > 0) {
        (previewSeconds.toFloat() / totalSeconds).coerceIn(0f, 1f)
    } else {
        1f
    }

    // -----------------------------------------
    // UI
    // -----------------------------------------

    ScaiScreen(
        scrollable = true
    ) {

        ScaiTopBar(
            title = "Focus",
            subtitle = "Dedicated time for learning",
        )

        Spacer(Modifier.height(20.dp))

        // SESSION TIMER

        ScaiCard(
            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = "FOCUS SESSION",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.2.sp
            )

            Spacer(Modifier.height(20.dp))

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {

                Box(
                    modifier = Modifier.size(218.dp),
                    contentAlignment = Alignment.Center
                ) {

                    // FIX: Resolve theme colors in the composable scope.
                    // Canvas drawing lambdas cannot invoke composable APIs.

                    val trackColor =
                        MaterialTheme.colorScheme.surfaceVariant

                    val progressColor =
                        MaterialTheme.colorScheme.onSurface

                    Canvas(
                        modifier = Modifier.fillMaxSize()
                    ) {

                        drawArc(
                            color = trackColor,
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(
                                width = 9.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        )

                        drawArc(
                            color = progressColor,
                            startAngle = -90f,
                            sweepAngle = 360f * progress,
                            useCenter = false,
                            style = Stroke(
                                width = 9.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {

                        Text(
                            text = String.format(
                                "%02d:%02d",
                                previewSeconds / 60,
                                previewSeconds % 60
                            ),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(Modifier.height(6.dp))

                        Text(
                            text = when {
                                hasSavedSession && storage.loadFocusPaused() ->
                                    "PAUSED"

                                hasSavedSession ->
                                    "SAVED SESSION"

                                completedSessionId != null ->
                                    "COMPLETED"

                                else ->
                                    "READY TO FOCUS"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(22.dp))

            ScaiDivider()

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                FocusMetric(
                    value = "${selectedMinutes.toInt()} min",
                    label = "Duration",
                    modifier = Modifier.weight(1f)
                )

                FocusMetric(
                    value = selectedSubject?.name ?: "None",
                    label = "Subject",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(Modifier.height(28.dp))

        // SESSION SETUP

        ScaiSectionTitle(
            title = "Session setup",
            description = "Choose what you want to work on."
        )

        Spacer(Modifier.height(12.dp))

        ScaiCard(
            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = "Subject",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(Modifier.height(8.dp))

            Box {

                ScaiSecondaryButton(
                    text = selectedSubject?.name ?: "Select subject",
                    onClick = {
                        subjectMenuExpanded = true
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                DropdownMenu(
                    expanded = subjectMenuExpanded,
                    onDismissRequest = {
                        subjectMenuExpanded = false
                    }
                ) {

                    if (subjects.isEmpty()) {

                        DropdownMenuItem(
                            text = {
                                Text("No subjects available")
                            },
                            onClick = {
                                subjectMenuExpanded = false
                            }
                        )
                    }

                    subjects.forEach { subject ->

                        DropdownMenuItem(
                            text = {
                                Text(subject.name)
                            },
                            onClick = {
                                selectedSubjectId = subject.id
                                selectedTaskId = null
                                taskMenuExpanded = false
                                subjectMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            Text(
                text = "Linked task",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(Modifier.height(8.dp))

            Box {

                ScaiSecondaryButton(
                    text = selectedTask?.title ?: "Select task (optional)",
                    onClick = {
                        if (selectedSubjectId != null) {
                            taskMenuExpanded = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = selectedSubjectId != null
                )

                DropdownMenu(
                    expanded = taskMenuExpanded,
                    onDismissRequest = {
                        taskMenuExpanded = false
                    }
                ) {

                    DropdownMenuItem(
                        text = {
                            Text("No linked task")
                        },
                        onClick = {
                            selectedTaskId = null
                            taskMenuExpanded = false
                        }
                    )

                    availableTasks.forEach { task ->

                        DropdownMenuItem(
                            text = {
                                Text(task.title)
                            },
                            onClick = {
                                selectedTaskId = task.id
                                taskMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // SESSION DURATION

        ScaiCard(
            modifier = Modifier.fillMaxWidth()
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Column(
                    modifier = Modifier.weight(1f)
                ) {

                    Text(
                        text = "Session duration",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = "Choose between 5 and 90 minutes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "${selectedMinutes.toInt()} min",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(Modifier.height(12.dp))

            Slider(
                value = selectedMinutes,
                onValueChange = {
                    selectedMinutes = it
                },
                valueRange = 5f..90f,
                steps = 84,
                enabled = !hasSavedSession
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = "5 min",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "90 min",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        // START / RESUME

        ScaiPrimaryButton(
            text = if (hasSavedSession) {
                "Resume focus session"
            } else {
                "Start focus session"
            },
            onClick = {

                if (!isCurrentAccount()) {
                    return@ScaiPrimaryButton
                }

                storage.saveActiveFocusSession(
                    durationMinutes = selectedMinutes.toInt(),

                    endTime = if (
                        hasSavedSession &&
                        !storage.loadFocusPaused()
                    ) {
                        storage.loadFocusEndTime()
                    } else {
                        System.currentTimeMillis() +
                            selectedMinutes.toInt() * 60_000L
                    },

                    remainingSeconds = if (hasSavedSession) {
                        previewSeconds
                    } else {
                        selectedMinutes.toInt() * 60
                    },

                    isPaused = hasSavedSession &&
                        storage.loadFocusPaused(),

                    subjectId = selectedSubjectId,
                    taskId = selectedTaskId
                )

                onStartActiveFocus()
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = subjects.isNotEmpty() &&
                uid != null &&
                !completionInProgress
        )

        if (subjects.isEmpty()) {

            Spacer(Modifier.height(12.dp))

            Text(
                text = "Add a subject before starting a focus session.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(24.dp))

        ScaiDivider()

        Spacer(Modifier.height(16.dp))

        Text(
            text = "CONSISTENCY BEATS INTENSITY",
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.2.sp
        )

        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun FocusMetric(
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {

        Column(
            modifier = Modifier.padding(14.dp)
        ) {

            Text(
                text = value,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1
            )

            Spacer(Modifier.height(4.dp))

            Text(
                text = label,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
