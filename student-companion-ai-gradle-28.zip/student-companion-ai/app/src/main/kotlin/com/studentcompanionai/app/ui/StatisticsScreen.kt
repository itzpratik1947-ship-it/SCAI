
package com.studentcompanionai.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.FocusSession
import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiSectionTitle
import com.studentcompanionai.app.ui.components.ScaiTopBar
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun StatisticsScreen(
    context: Context,
    onMenuClick: () -> Unit,
    uid: String? = FirebaseAuth.getInstance().currentUser?.uid
) {
    val colors = MaterialTheme.colorScheme

    // ACCOUNT-SPECIFIC STORAGE

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    // LOAD ACCOUNT DATA

    val sessions = remember(context, uid) {
        storage.loadFocusSessions()
            .sortedByDescending { it.timestamp }
    }

    val tasks = remember(context, uid) {
        storage.loadTasks()
    }

    val subjects = remember(context, uid) {
        storage.loadSubjects()
    }

    // TODAY'S FOCUS TIME

    val todayStart = remember(uid) {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val todaySessions = sessions.filter {
        it.timestamp >= todayStart
    }

    val todayMinutes = todaySessions.sumOf {
        it.minutes
    }

    val totalMinutes = sessions.sumOf {
        it.minutes
    }

    // TASK PROGRESS

    val totalTasks = tasks.size

    val completedTasks = tasks.count {
        it.isCompleted
    }

    val taskProgress = if (totalTasks > 0) {
        (completedTasks.toFloat() / totalTasks)
            .coerceIn(0f, 1f)
    } else {
        0f
    }

    // WEEKLY FOCUS TIME

    val weeklyMinutes = remember(sessions) {
        val weekStart = System.currentTimeMillis() -
            7L * 24 * 60 * 60 * 1000

        sessions.filter {
            it.timestamp >= weekStart
        }.sumOf {
            it.minutes
        }
    }

    // SUBJECT FOCUS TIME

    val subjectMinutes = remember(subjects, sessions) {
        subjects.associate { subject ->
            subject.id to sessions
                .filter { it.subjectId == subject.id }
                .sumOf { it.minutes }
        }
    }

    // MAIN SCREEN

    ScaiScreen(
        scrollable = false,
        modifier = Modifier.fillMaxSize()
    ) {
        ScaiTopBar(
            title = "Your progress",
            subtitle = "Track your learning activity",
            onMenuClick = onMenuClick
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // OVERVIEW

            item {
                ScaiSectionTitle(
                    title = "Focus overview",
                    description = "Small sessions add up to meaningful progress"
                )
            }

            item {
                ScaiCard {
                    Text(
                        text = "TOTAL FOCUS TIME",
                        color = colors.onSurfaceVariant,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = formatDuration(totalMinutes),
                        color = colors.onSurface,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = "Across ${sessions.size} recorded sessions",
                        color = colors.onSurfaceVariant,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))
                    ScaiDivider()
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SummaryMetric(
                            label = "Today",
                            value = formatDuration(todayMinutes),
                            modifier = Modifier.weight(1f)
                        )

                        SummaryMetric(
                            label = "Last 7 days",
                            value = formatDuration(weeklyMinutes),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // TASK COMPLETION

            item {
                ScaiSectionTitle(
                    title = "Task completion",
                    description = "Your overall task progress"
                )
            }

            item {
                ScaiCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "$completedTasks of $totalTasks",
                                color = colors.onSurface,
                                fontSize = 25.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(
                                text = "Tasks completed",
                                color = colors.onSurfaceVariant,
                                fontSize = 12.sp
                            )
                        }

                        Text(
                            text = "${(taskProgress * 100).toInt()}%",
                            color = colors.onSurface,
                            fontSize = 23.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    LinearProgressIndicator(
                        progress = { taskProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(CircleShape),
                        color = colors.onSurface,
                        trackColor = colors.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(9.dp))

                    Text(
                        text = "${(totalTasks - completedTasks).coerceAtLeast(0)} tasks remaining",
                        color = colors.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
            }

            // SUBJECT BREAKDOWN

            item {
                ScaiSectionTitle(
                    title = "Subject breakdown",
                    description = "Focus time and task completion by subject"
                )
            }

            if (subjects.isEmpty()) {
                item {
                    EmptyStatsCard(
                        title = "No subjects yet",
                        message = "Add subjects to start organizing your learning statistics."
                    )
                }
            } else {
                items(
                    items = subjects,
                    key = { it.id }
                ) { subject ->

                    val minutes =
                        subjectMinutes[subject.id] ?: 0

                    val subjectTasks = tasks.filter {
                        it.subjectId == subject.id
                    }

                    val done = subjectTasks.count {
                        it.isCompleted
                    }

                    val subjectProgress =
                        if (subjectTasks.isNotEmpty()) {
                            (done.toFloat() / subjectTasks.size)
                                .coerceIn(0f, 1f)
                        } else {
                            0f
                        }

                    SubjectStatisticsCard(
                        name = subject.name,
                        minutes = minutes,
                        completedTasks = done,
                        totalTasks = subjectTasks.size,
                        progress = subjectProgress
                    )
                }
            }

            // RECENT SESSIONS

            item {
                ScaiSectionTitle(
                    title = "Recent sessions",
                    description = "Your latest recorded focus sessions"
                )
            }

            if (sessions.isEmpty()) {
                item {
                    EmptyStatsCard(
                        title = "No sessions recorded",
                        message = "Your completed focus sessions will appear here."
                    )
                }
            } else {
                items(
                    items = sessions.take(10),
                    key = { it.id }
                ) { session ->

                    val subjectName = subjects.firstOrNull {
                        it.id == session.subjectId
                    }?.name ?: "Independent study"

                    RecentSessionCard(
                        session = session,
                        subjectName = subjectName
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

// ==================================================
// SUMMARY METRIC
// ==================================================

@Composable
private fun SummaryMetric(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    val colors = MaterialTheme.colorScheme

    Surface(
        modifier = modifier,
        color = colors.surfaceVariant,
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Text(
                text = label,
                color = colors.onSurfaceVariant,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = value,
                color = colors.onSurface,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ==================================================
// SUBJECT STATISTICS CARD
// ==================================================

@Composable
private fun SubjectStatisticsCard(
    name: String,
    minutes: Int,
    completedTasks: Int,
    totalTasks: Int,
    progress: Float
) {
    val colors = MaterialTheme.colorScheme

    ScaiCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = name,
                    color = colors.onSurface,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = "$completedTasks of $totalTasks tasks completed",
                    color = colors.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }

            Text(
                text = formatDuration(minutes),
                color = colors.onSurface,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(13.dp))

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .clip(CircleShape),
            color = colors.onSurface,
            trackColor = colors.surfaceVariant
        )

        Spacer(modifier = Modifier.height(7.dp))

        Text(
            text = "${(progress * 100).toInt()}% task completion",
            color = colors.onSurfaceVariant,
            fontSize = 11.sp
        )
    }
}

// ==================================================
// RECENT SESSION CARD
// ==================================================

@Composable
private fun RecentSessionCard(
    session: FocusSession,
    subjectName: String
) {
    val colors = MaterialTheme.colorScheme

    ScaiCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(colors.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "✓",
                    color = colors.onSurface,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.size(12.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = subjectName,
                    color = colors.onSurface,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = SimpleDateFormat(
                        "dd MMM · hh:mm a",
                        Locale.getDefault()
                    ).format(Date(session.timestamp)),
                    color = colors.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            Text(
                text = "${session.minutes} min",
                color = colors.onSurface,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

// ==================================================
// EMPTY STATISTICS CARD
// ==================================================

@Composable
private fun EmptyStatsCard(
    title: String,
    message: String
) {
    val colors = MaterialTheme.colorScheme

    ScaiCard {
        Text(
            text = title,
            color = colors.onSurface,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = message,
            color = colors.onSurfaceVariant,
            fontSize = 13.sp,
            lineHeight = 19.sp
        )
    }
}

// ==================================================
// FORMAT DURATION
// ==================================================

private fun formatDuration(minutes: Int): String {
    val safeMinutes = minutes.coerceAtLeast(0)
    val hours = safeMinutes / 60
    val remainingMinutes = safeMinutes % 60

    return if (hours > 0) {
        "${hours}h ${remainingMinutes}m"
    } else {
        "${remainingMinutes}m"
    }
}
