
package com.studentcompanionai.app.ui.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val focusTimeOptions = listOf(
    "Early Morning",
    "Morning",
    "Afternoon",
    "Evening",
    "Night",
    "Flexible"
)

@Composable
fun FocusPreferencesScreen(
    initialFocusDuration: Int = 25,
    initialBreakDuration: Int = 5,
    initialDailyFocusTarget: Int = 4,
    initialPreferredFocusTime: String = "FLEXIBLE",
    onBack: () -> Unit,
    onContinue: (
        focusDuration: Int,
        breakDuration: Int,
        dailyFocusTarget: Int,
        preferredFocusTime: String
    ) -> Unit
) {
    var focusDuration by rememberSaveable {
        mutableStateOf(initialFocusDuration.coerceIn(10, 120))
    }

    var breakDuration by rememberSaveable {
        mutableStateOf(initialBreakDuration.coerceIn(5, 30))
    }

    var dailyFocusTarget by rememberSaveable {
        mutableStateOf(initialDailyFocusTarget.coerceIn(1, 16))
    }

    var preferredFocusTime by rememberSaveable {
        mutableStateOf(initialPreferredFocusTime)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {

        TextButton(onClick = onBack) {
            Text("← Back")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Set your focus preferences",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Everyone concentrates differently. Configure your focus sessions so SCAI can help you build a sustainable study routine.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Focus session duration")

        Text(
            text = "How long can you comfortably focus in one session?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "$focusDuration minutes",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )

        Slider(
            value = focusDuration.toFloat(),
            onValueChange = {
                focusDuration = it.toInt().coerceIn(10, 120)
            },
            valueRange = 10f..120f,
            steps = 21
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("10 min", style = MaterialTheme.typography.bodySmall)
            Text("120 min", style = MaterialTheme.typography.bodySmall)
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Break duration")

        Text(
            text = "How long would you like to rest between focus sessions?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "$breakDuration minutes",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )

        Slider(
            value = breakDuration.toFloat(),
            onValueChange = {
                breakDuration = it.toInt().coerceIn(5, 30)
            },
            valueRange = 5f..30f,
            steps = 4
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("5 min", style = MaterialTheme.typography.bodySmall)
            Text("30 min", style = MaterialTheme.typography.bodySmall)
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Daily focus target")

        Text(
            text = "How many focus sessions would you like to complete each day?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "$dailyFocusTarget sessions",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )

        Slider(
            value = dailyFocusTarget.toFloat(),
            onValueChange = {
                dailyFocusTarget = it.toInt().coerceIn(1, 16)
            },
            valueRange = 1f..16f,
            steps = 14
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("1 session", style = MaterialTheme.typography.bodySmall)
            Text("16 sessions", style = MaterialTheme.typography.bodySmall)
        }

        Spacer(modifier = Modifier.height(28.dp))

        SectionTitle("Preferred focus time")

        Text(
            text = "When do you feel most comfortable doing focused work?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            focusTimeOptions.chunked(2).forEach { timeRow ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    timeRow.forEach { time ->
                        val value = time.uppercase().replace(" ", "_")

                        FilterChip(
                            selected = preferredFocusTime == value,
                            onClick = {
                                preferredFocusTime = value
                            },
                            label = {
                                Text(time)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                onContinue(
                    focusDuration,
                    breakDuration,
                    dailyFocusTarget,
                    preferredFocusTime
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                text = "Continue",
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(10.dp))
}
