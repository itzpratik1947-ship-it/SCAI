
package com.studentcompanionai.app.ui

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.studentcompanionai.app.data.ResourceStorage
import com.studentcompanionai.app.data.StudentStorage
import com.studentcompanionai.app.data.StudyTask
import com.studentcompanionai.app.data.Subject
import com.studentcompanionai.app.data.toResourceItem
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiTopBar
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun TasksScreen(
    context: Context,
    onBackClick: () -> Unit,
    onTasksChanged: (Int, Int) -> Unit = { _, _ -> },
    refreshKey: Int = 0,
    uid: String? = FirebaseAuth.getInstance().currentUser?.uid
) {

    val storage = remember(context, uid) {
        StudentStorage(context, uid)
    }

    val tasks = remember(uid) {
        mutableStateListOf<StudyTask>()
    }

    val subjects = remember(uid) {
        mutableStateListOf<Subject>()
    }

    var showCompleted by remember(uid) {
        mutableStateOf(true)
    }

    var taskToDelete by remember(uid) {
        mutableStateOf<StudyTask?>(null)
    }

    var taskToSkip by remember(uid) {
        mutableStateOf<StudyTask?>(null)
    }

    val screenContext = LocalContext.current

    var todayStart by remember(uid) {
        mutableStateOf(getStartOfToday())
    }

    // -----------------------------------------
    // LOAD EXISTING DATA ONLY
    // -----------------------------------------

    LaunchedEffect(refreshKey, uid) {

        if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
            return@LaunchedEffect
        }

        todayStart = getStartOfToday()

        // Load existing tasks and subjects only.
        // No learning-plan activities are converted into tasks here.
        val savedTasks = storage.loadTasks()
        val savedSubjects = storage.loadSubjects()

        if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
            return@LaunchedEffect
        }

        tasks.clear()
        tasks.addAll(savedTasks)

        subjects.clear()
        subjects.addAll(savedSubjects)

        val independentTasks = tasks.filter {
            it.learningPlanId.isNullOrBlank()
        }

        onTasksChanged(
            independentTasks.size,
            independentTasks.count { it.isCompleted && !it.isSkipped }
        )
    }

    // -----------------------------------------
    // SHOW INDEPENDENT TASKS ONLY
    // -----------------------------------------

    // Preserve older planner-linked records in storage, but never display
    // them as Tasks. New task creation is handled exclusively through AI Chat.
    val categoryTasks = tasks.filter { task ->
        task.learningPlanId.isNullOrBlank()
    }

    val overdueTasks = categoryTasks
        .filter {
            !it.isSkipped && isTaskOverdue(it, todayStart)
        }
        .sortedBy { it.scheduledDate }

    val todayTasks = categoryTasks
        .filter {
            !it.isCompleted &&
                !it.isSkipped &&
                it.scheduledDate == todayStart
        }

    val upcomingTasks = categoryTasks
        .filter {
            !it.isCompleted &&
                !it.isSkipped &&
                (
                    it.scheduledDate == 0L ||
                        it.scheduledDate > todayStart
                    )
        }
        .sortedBy { it.scheduledDate }

    val completedTasks = categoryTasks
        .filter {
            it.isCompleted && !it.isSkipped
        }
        .sortedByDescending { it.completedAt }

    val skippedTasks = categoryTasks
        .filter { it.isSkipped }
        .sortedByDescending { it.skippedAt }

    // -----------------------------------------
    // PERSIST TASKS
    // -----------------------------------------

    fun persistTasks() {

        if (FirebaseAuth.getInstance().currentUser?.uid != uid) {
            return
        }

        storage.saveTasks(tasks)

        val independentTasks = tasks.filter {
            it.learningPlanId.isNullOrBlank()
        }

        onTasksChanged(
            independentTasks.size,
            independentTasks.count { it.isCompleted && !it.isSkipped }
        )
    }

    // -----------------------------------------
    // TASK COMPLETION
    // -----------------------------------------

    fun updateTaskCompletion(
        task: StudyTask,
        checked: Boolean
    ) {

        val index = tasks.indexOfFirst {
            it.id == task.id
        }

        if (index >= 0) {

            val updatedTask = task.copy(
                isCompleted = checked,
                completedAt = if (checked) {
                    System.currentTimeMillis()
                } else {
                    0L
                }
            )

            tasks[index] = updatedTask

            persistTasks()
        }
    }

    // -----------------------------------------
    // RESCHEDULE TASK
    // -----------------------------------------

    fun showRescheduleDialog(task: StudyTask) {

        val calendar = Calendar.getInstance()

        DatePickerDialog(
            screenContext,
            { _, year, month, dayOfMonth ->

                val selectedDate = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis

                val index = tasks.indexOfFirst {
                    it.id == task.id
                }

                if (index >= 0) {

                    val updatedDateTime = if (task.scheduledDateTime > 0L) {
                        Calendar.getInstance().apply {
                            timeInMillis = selectedDate
                            val previousTime = Calendar.getInstance().apply {
                                timeInMillis = task.scheduledDateTime
                            }
                            set(Calendar.HOUR_OF_DAY, previousTime.get(Calendar.HOUR_OF_DAY))
                            set(Calendar.MINUTE, previousTime.get(Calendar.MINUTE))
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }.timeInMillis
                    } else {
                        0L
                    }

                    val updatedTask = task.copy(
                        scheduledDate = selectedDate,
                        scheduledDateTime = updatedDateTime,
                        isSkipped = false,
                        skippedAt = 0L
                    )

                    tasks[index] = updatedTask

                    persistTasks()
                }
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).apply {
            datePicker.minDate = getStartOfToday()
        }.show()
    }

    // -----------------------------------------
    // ENTIRE SCREEN: ONE SCROLL CONTAINER
    // -----------------------------------------

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(
            horizontal = 20.dp,
            vertical = 14.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        // HEADER

        item(key = "task_screen_header") {

            Column {

                ScaiTopBar(
                    title = "Tasks",
                    subtitle = "Tasks created through AI Chat"
                )

            }
        }

        // Task creation is intentionally handled through AI Chat only.

        // OVERDUE RECOVERY

        if (overdueTasks.isNotEmpty()) {

            item(key = "overdue_recovery") {

                TaskRecoveryCard(
                    overdueCount = overdueTasks.size
                )
            }
        }

        // EMPTY STATE

        val hasVisibleTasks =
            overdueTasks.isNotEmpty() ||
                todayTasks.isNotEmpty() ||
                upcomingTasks.isNotEmpty() ||
                (showCompleted && completedTasks.isNotEmpty()) ||
                skippedTasks.isNotEmpty()

        if (!hasVisibleTasks) {

            item(key = "empty_tasks") {

                TaskEmptyState(
                    title = "No tasks here",
                    description =
                        "No independent tasks yet. Ask AI Chat to create a task, for example: \"Study Physics tomorrow at 6 PM\"."
                )
            }
        }

        // OVERDUE TASKS

        if (overdueTasks.isNotEmpty()) {

            item(key = "overdue_header") {

                TaskSectionHeader(
                    title = "OVERDUE",
                    count = overdueTasks.size
                )
            }

            items(
                overdueTasks,
                key = { "overdue_${it.id}" }
            ) { task ->

                TaskItemCard(
                    task = task,
                    subject = subjects.firstOrNull {
                        it.id == task.subjectId
                    },
                    statusLabel = "OVERDUE",
                    onCompletionChanged = { checked ->
                        updateTaskCompletion(task, checked)
                    },
                    onDelete = {
                        taskToDelete = task
                    },
                    onReschedule = {
                        showRescheduleDialog(task)
                    },
                    onSkip = {
                        taskToSkip = task
                    }
                )
            }
        }

        // TODAY TASKS

        if (todayTasks.isNotEmpty()) {

            item(key = "today_header") {

                TaskSectionHeader(
                    title = "TODAY",
                    count = todayTasks.size
                )
            }

            items(
                todayTasks,
                key = { "today_${it.id}" }
            ) { task ->

                TaskItemCard(
                    task = task,
                    subject = subjects.firstOrNull {
                        it.id == task.subjectId
                    },
                    statusLabel = "TODAY",
                    onCompletionChanged = { checked ->
                        updateTaskCompletion(task, checked)
                    },
                    onDelete = {
                        taskToDelete = task
                    },
                    onSkip = {
                        taskToSkip = task
                    }
                )
            }
        }

        // UPCOMING TASKS

        if (upcomingTasks.isNotEmpty()) {

            item(key = "upcoming_header") {

                TaskSectionHeader(
                    title = "UPCOMING",
                    count = upcomingTasks.size
                )
            }

            items(
                upcomingTasks,
                key = { "upcoming_${it.id}" }
            ) { task ->

                TaskItemCard(
                    task = task,
                    subject = subjects.firstOrNull {
                        it.id == task.subjectId
                    },
                    statusLabel = "UPCOMING",
                    onCompletionChanged = { checked ->
                        updateTaskCompletion(task, checked)
                    },
                    onDelete = {
                        taskToDelete = task
                    },
                    onReschedule = {
                        showRescheduleDialog(task)
                    },
                    onSkip = {
                        taskToSkip = task
                    }
                )
            }
        }

        // COMPLETED TASKS

        if (completedTasks.isNotEmpty()) {

            item(key = "completed_header") {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    TaskSectionHeader(
                        title = "COMPLETED",
                        count = completedTasks.size
                    )

                    Spacer(Modifier.weight(1f))

                    TextButton(
                        onClick = {
                            showCompleted = !showCompleted
                        }
                    ) {
                        Text(
                            if (showCompleted) "Hide" else "Show",
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            if (showCompleted) {

                items(
                    completedTasks,
                    key = { "completed_${it.id}" }
                ) { task ->

                    TaskItemCard(
                        task = task,
                        subject = subjects.firstOrNull {
                            it.id == task.subjectId
                        },
                        statusLabel = "COMPLETED",
                        onCompletionChanged = { checked ->
                            updateTaskCompletion(task, checked)
                        },
                        onDelete = {
                            taskToDelete = task
                        }
                    )
                }
            }
        }

        // SKIPPED TASK HISTORY

        if (skippedTasks.isNotEmpty()) {

            item(key = "skipped_header") {

                TaskSectionHeader(
                    title = "SKIPPED HISTORY",
                    count = skippedTasks.size
                )
            }

            items(
                skippedTasks,
                key = { "skipped_${it.id}" }
            ) { task ->

                TaskItemCard(
                    task = task,
                    subject = subjects.firstOrNull {
                        it.id == task.subjectId
                    },
                    statusLabel = "SKIPPED",
                    showCheckbox = false,
                    onCompletionChanged = {},
                    onDelete = {
                        taskToDelete = task
                    }
                )
            }
        }

        // BOTTOM SPACING

        item(key = "task_bottom_spacing") {
            Spacer(Modifier.height(24.dp))
        }
    }

    // DELETE TASK CONFIRMATION

    taskToDelete?.let { task ->

        AlertDialog(
            onDismissRequest = {
                taskToDelete = null
            },
            title = {
                Text("Delete task?")
            },
            text = {
                Text(
                    "Are you sure you want to permanently delete \"${task.title}\"?"
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {

                        tasks.removeAll {
                            it.id == task.id
                        }

                        persistTasks()
                        taskToDelete = null
                    }
                ) {
                    Text(
                        "Delete",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        taskToDelete = null
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // SKIP TASK CONFIRMATION

    taskToSkip?.let { task ->

        AlertDialog(
            onDismissRequest = {
                taskToSkip = null
            },
            title = {
                Text("Skip this task?")
            },
            text = {
                Text(
                    "This task will move to Skipped History. It will no longer appear in your active task list."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {

                        val index = tasks.indexOfFirst {
                            it.id == task.id
                        }

                        if (index >= 0) {

                            val updatedTask = task.copy(
                                isSkipped = true,
                                skippedAt = System.currentTimeMillis(),
                                isCompleted = false,
                                completedAt = 0L
                            )

                            tasks[index] = updatedTask

                            persistTasks()
                        }

                        taskToSkip = null
                    }
                ) {
                    Text(
                        "Skip task",
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        taskToSkip = null
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

// --------------------------------------------------
// TASK SECTION HEADER
// --------------------------------------------------

@Composable
private fun TaskSectionHeader(
    title: String,
    count: Int
) {

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {

        Text(
            text = title,
            color = MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(Modifier.width(8.dp))

        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {

            Text(
                text = count.toString(),
                modifier = Modifier.padding(
                    horizontal = 9.dp,
                    vertical = 4.dp
                ),
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// --------------------------------------------------
// TASK RECOVERY CARD
// --------------------------------------------------

@Composable
private fun TaskRecoveryCard(
    overdueCount: Int
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {

        Column(
            modifier = Modifier.padding(16.dp)
        ) {

            Text(
                text = "Review overdue tasks",
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = "You have $overdueCount overdue task(s). Reschedule only what realistically fits your remaining study time. Start with the oldest or highest-priority work instead of moving everything to tomorrow.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

// --------------------------------------------------
// TASK EMPTY STATE
// --------------------------------------------------

@Composable
private fun TaskEmptyState(
    title: String,
    description: String
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = title,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = description,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

// --------------------------------------------------
// TASK ITEM CARD
// --------------------------------------------------

@Composable
private fun TaskItemCard(
    task: StudyTask,
    subject: Subject?,
    statusLabel: String,
    onCompletionChanged: (Boolean) -> Unit,
    onDelete: () -> Unit,
    onReschedule: (() -> Unit)? = null,
    onSkip: (() -> Unit)? = null,
    showCheckbox: Boolean = true
) {

    val context = LocalContext.current

    val uid = FirebaseAuth.getInstance().currentUser?.uid

    val resourceStorage = remember(uid) {
        ResourceStorage(accountUid = uid.orEmpty())
    }

    val scope = rememberCoroutineScope()

    var actionMenuExpanded by remember(task.id) {
        mutableStateOf(false)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {

        Column(
            modifier = Modifier.padding(14.dp)
        ) {

            Row(
                verticalAlignment = Alignment.Top
            ) {

                if (showCheckbox) {

                    Checkbox(
                        checked = task.isCompleted,
                        onCheckedChange = onCompletionChanged,
                        colors = CheckboxDefaults.colors(
                            checkedColor = MaterialTheme.colorScheme.onSurface,
                            uncheckedColor = MaterialTheme.colorScheme.outline,
                            checkmarkColor = MaterialTheme.colorScheme.surface
                        )
                    )

                    Spacer(Modifier.width(6.dp))
                }

                Column(
                    modifier = Modifier.weight(1f)
                ) {

                    Text(
                        text = task.title,
                        color = if (task.isCompleted || task.isSkipped) {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        textDecoration = if (
                            task.isCompleted || task.isSkipped
                        ) {
                            TextDecoration.LineThrough
                        } else {
                            TextDecoration.None
                        }
                    )

                    Spacer(Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        TaskTag(
                            text = "GENERAL TASK"
                        )

                        Spacer(Modifier.width(6.dp))

                        TaskTag(
                            text = statusLabel
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Text(
                        text = subject?.name ?: "No subject assigned",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )

                    if (task.scheduledDate > 0L) {

                        Spacer(Modifier.height(4.dp))

                        Text(
                            text = buildString {
                                append("Scheduled: ")
                                append(formatTaskDate(task.scheduledDate))
                                if (task.scheduledDateTime > 0L) {
                                    append(" • ")
                                    append(formatTaskTime(task.scheduledDateTime))
                                }
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    if (task.estimatedMinutes > 0) {

                        Spacer(Modifier.height(4.dp))

                        Text(
                            text = "${task.estimatedMinutes} minutes",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    if (task.isSkipped) {

                        Spacer(Modifier.height(4.dp))

                        Text(
                            text = "Skipped on ${formatTaskDate(task.skippedAt)}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    if (task.description.isNotBlank()) {

                        Spacer(Modifier.height(8.dp))

                        Text(
                            text = task.description,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Box {

                    TextButton(
                        onClick = {
                            actionMenuExpanded = true
                        }
                    ) {

                        Text(
                            text = "More",
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    DropdownMenu(
                        expanded = actionMenuExpanded,
                        onDismissRequest = {
                            actionMenuExpanded = false
                        }
                    ) {

                        if (onReschedule != null) {

                            DropdownMenuItem(
                                text = {
                                    Text("Reschedule")
                                },
                                onClick = {
                                    actionMenuExpanded = false
                                    onReschedule()
                                }
                            )
                        }

                        if (onSkip != null) {

                            DropdownMenuItem(
                                text = {
                                    Text("Skip task")
                                },
                                onClick = {
                                    actionMenuExpanded = false
                                    onSkip()
                                }
                            )
                        }

                        DropdownMenuItem(
                            text = {
                                Text(
                                    "Delete",
                                    color = MaterialTheme.colorScheme.error
                                )
                            },
                            onClick = {
                                actionMenuExpanded = false
                                onDelete()
                            }
                        )
                    }
                }
            }

            // LEARNING RESOURCES

            if (task.resources.isNotEmpty()) {

                Spacer(Modifier.height(12.dp))

                ScaiDivider()

                Spacer(Modifier.height(12.dp))

                Text(
                    text = "LEARNING RESOURCES (${task.resources.size})",
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(Modifier.height(6.dp))

                task.resources.forEach { resource ->

                    TextButton(
                        onClick = {

                            val url = resource.url.trim()

                            if (
                                url.startsWith("https://", ignoreCase = true) ||
                                url.startsWith("http://", ignoreCase = true)
                            ) {

                                val resourceItem = resource.toResourceItem(
                                    subject = subject?.name.orEmpty()
                                )

                                scope.launch {

                                    if (
                                        uid != null &&
                                        FirebaseAuth.getInstance().currentUser?.uid == uid
                                    ) {

                                        runCatching {
                                            withContext(Dispatchers.IO) {
                                                resourceStorage.recordResourceOpened(
                                                    resourceItem
                                                )
                                            }
                                        }
                                    }
                                }

                                runCatching {
                                    context.startActivity(
                                        Intent(
                                            Intent.ACTION_VIEW,
                                            Uri.parse(url)
                                        )
                                    )
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {

                            Text(
                                text = "↗ ${resource.title}",
                                color = MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.bodyMedium
                            )

                            Text(
                                text = buildString {

                                    append(resource.type.name)

                                    if (resource.provider.isNotBlank()) {
                                        append(" • ")
                                        append(resource.provider)
                                    }
                                },
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

// --------------------------------------------------
// TASK TAG
// --------------------------------------------------

@Composable
private fun TaskTag(
    text: String
) {

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {

        Text(
            text = text,
            modifier = Modifier.padding(
                horizontal = 8.dp,
                vertical = 4.dp
            ),
            color = MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium
        )
    }
}

// --------------------------------------------------
// DATE AND OVERDUE HELPERS
// --------------------------------------------------

private fun getStartOfToday(): Long {

    return Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}

private fun isTaskOverdue(
    task: StudyTask,
    todayStart: Long
): Boolean {

    return !task.isCompleted &&
        !task.isSkipped &&
        task.scheduledDate > 0L &&
        task.scheduledDate < todayStart
}

private fun formatTaskDate(timestamp: Long): String {

    if (timestamp <= 0L) return "Not scheduled"

    return SimpleDateFormat(
        "dd MMM yyyy",
        Locale.getDefault()
    ).format(Date(timestamp))
}

private fun formatTaskTime(timestamp: Long): String {

    if (timestamp <= 0L) return ""

    return SimpleDateFormat(
        "h:mm a",
        Locale.getDefault()
    ).format(Date(timestamp))
}
