
package com.studentcompanionai.app.data

/**
 * Overall performance classification for a topic.
 */
enum class TopicPerformanceLevel {
    INSUFFICIENT_DATA,
    WEAK,
    NEEDS_IMPROVEMENT,
    GOOD
}

/**
 * Direction of a learner's recent performance.
 */
enum class PerformanceTrend {
    INSUFFICIENT_DATA,
    IMPROVING,
    DECLINING,
    STABLE
}

/**
 * Recommended difficulty for the learner's next practice session.
 */
enum class AdaptiveDifficulty {
    EASY,
    MEDIUM,
    HARD
}

/**
 * Detailed performance information for one subject-topic combination.
 *
 * Existing properties are preserved so existing UI code remains
 * compatible. New properties support adaptive learning.
 */
data class TopicPerformanceInsight(
    val topic: String,
    val correctAnswers: Int,
    val incorrectAnswers: Int,
    val evaluatedAnswers: Int,
    val accuracy: Int,
    val level: TopicPerformanceLevel,
    val recommendation: String,

    val subject: String = "",
    val recentAccuracy: Int? = null,
    val previousAccuracy: Int? = null,
    val trend: PerformanceTrend = PerformanceTrend.INSUFFICIENT_DATA,
    val recommendedDifficulty: AdaptiveDifficulty =
        AdaptiveDifficulty.MEDIUM,
    val recommendedQuestionCount: Int = 5,
    val priorityScore: Int = 0
) {
    /**
     * Stable identifier for UI lists.
     * Different subjects can contain identically named topics.
     */
    val id: String
        get() = "${subject.trim().lowercase()}::${topic.trim().lowercase()}"

    val isSufficientlyAnalyzed: Boolean
        get() = level != TopicPerformanceLevel.INSUFFICIENT_DATA
}

/**
 * Complete analysis across the supplied practice history.
 *
 * Existing properties remain available.
 */
data class PracticePerformanceAnalysis(
    val topics: List<TopicPerformanceInsight>,
    val weakTopics: List<TopicPerformanceInsight>,
    val topicsNeedingImprovement: List<TopicPerformanceInsight>,
    val insufficientDataTopics: List<TopicPerformanceInsight>,
    val totalTopics: Int,

    val goodTopics: List<TopicPerformanceInsight> = emptyList(),
    val recommendedTopics: List<TopicPerformanceInsight> = emptyList(),
    val improvingTopics: List<TopicPerformanceInsight> = emptyList(),
    val decliningTopics: List<TopicPerformanceInsight> = emptyList(),
    val overallAccuracy: Int = 0,
    val totalEvaluatedAnswers: Int = 0,
    val totalCorrectAnswers: Int = 0,
    val subject: String? = null
) {
    val hasEnoughData: Boolean
        get() = totalEvaluatedAnswers >=
            PracticePerformanceAnalyzer.MINIMUM_ANSWERS_FOR_ANALYSIS

    val overallRecommendedDifficulty: AdaptiveDifficulty
        get() = when {
            !hasEnoughData -> AdaptiveDifficulty.MEDIUM
            overallAccuracy < 60 -> AdaptiveDifficulty.EASY
            overallAccuracy < 80 -> AdaptiveDifficulty.MEDIUM
            else -> AdaptiveDifficulty.HARD
        }
}

/**
 * Analyzes practice history and produces deterministic adaptive
 * learning recommendations.
 *
 * The analyzer does not make AI calls and does not modify storage.
 */
object PracticePerformanceAnalyzer {

    internal const val MINIMUM_ANSWERS_FOR_ANALYSIS = 3

    private const val WEAK_ACCURACY_THRESHOLD = 60
    private const val GOOD_ACCURACY_THRESHOLD = 80

    private const val RECENT_ATTEMPT_WINDOW = 3

    private const val MINIMUM_ANSWERS_FOR_TREND = 2

    private const val TREND_CHANGE_THRESHOLD = 10

    private const val MINIMUM_PRIORITY_SCORE = 0
    private const val MAXIMUM_PRIORITY_SCORE = 100

    private const val DEFAULT_QUESTION_COUNT = 5
    private const val MINIMUM_QUESTION_COUNT = 5
    private const val MAXIMUM_QUESTION_COUNT = 15

    /**
     * Analyze all available practice results.
     *
     * Results from different subjects are analyzed separately.
     */
    fun analyze(
        results: List<StoredPracticeResult>
    ): PracticePerformanceAnalysis {
        return analyzeInternal(
            results = results,
            requestedSubject = null
        )
    }

    /**
     * Analyze practice results for one specific subject.
     *
     * Subject matching ignores leading/trailing whitespace
     * and letter casing.
     */
    fun analyze(
        results: List<StoredPracticeResult>,
        subject: String
    ): PracticePerformanceAnalysis {
        return analyzeInternal(
            results = results,
            requestedSubject = subject
        )
    }

    /**
     * Returns the recommended difficulty for one topic.
     *
     * If there is insufficient evidence, MEDIUM is returned
     * instead of making an unreliable adjustment.
     */
    fun recommendDifficulty(
        results: List<StoredPracticeResult>,
        subject: String,
        topic: String
    ): AdaptiveDifficulty {

        val insight = analyze(
            results = results,
            subject = subject
        ).topics.firstOrNull {
            normalize(it.topic) == normalize(topic)
        }

        return insight?.recommendedDifficulty
            ?: AdaptiveDifficulty.MEDIUM
    }

    /**
     * Returns the complete insight for a specific topic.
     */
    fun getTopicInsight(
        results: List<StoredPracticeResult>,
        subject: String,
        topic: String
    ): TopicPerformanceInsight? {

        return analyze(
            results = results,
            subject = subject
        ).topics.firstOrNull {
            normalize(it.topic) == normalize(topic)
        }
    }

    /**
     * Returns topics that should receive additional practice.
     *
     * Weak topics appear first, followed by topics needing
     * improvement and topics with insufficient data.
     */
    fun getPriorityTopics(
        results: List<StoredPracticeResult>,
        subject: String,
        limit: Int = 5
    ): List<TopicPerformanceInsight> {

        if (limit <= 0) {
            return emptyList()
        }

        return analyze(
            results = results,
            subject = subject
        ).recommendedTopics.take(limit)
    }

    /**
     * Returns an adaptive question count for a topic.
     */
    fun recommendQuestionCount(
        results: List<StoredPracticeResult>,
        subject: String,
        topic: String
    ): Int {

        return getTopicInsight(
            results = results,
            subject = subject,
            topic = topic
        )?.recommendedQuestionCount ?: DEFAULT_QUESTION_COUNT
    }

    private fun analyzeInternal(
        results: List<StoredPracticeResult>,
        requestedSubject: String?
    ): PracticePerformanceAnalysis {

        val normalizedRequestedSubject =
            requestedSubject?.let(::normalize)

        /*
         * Only evaluated answers are allowed to influence
         * performance analysis.
         *
         * Pending AI evaluations must never count as incorrect.
         */
        val validResults = results
            .filter { result ->
                normalizedRequestedSubject == null ||
                    normalize(result.subject) == normalizedRequestedSubject
            }
            .sortedBy {
                it.completedAt
            }

        val evaluatedAnswers = validResults.flatMap { result ->
            result.answers.filter { answer ->
                answer.isEvaluated &&
                    answer.topic.isNotBlank()
            }.map { answer ->
                AnalyzedAnswer(
                    subject = result.subject.trim(),
                    topic = normalizeTopic(answer.topic),
                    isCorrect = answer.isCorrect,
                    difficulty = normalizeDifficulty(answer.difficulty),
                    completedAt = result.completedAt,
                    attemptId = result.attemptId
                )
            }
        }

        val totalCorrect = evaluatedAnswers.count {
            it.isCorrect
        }

        val totalEvaluated = evaluatedAnswers.size

        val overallAccuracy = calculateAccuracy(
            correct = totalCorrect,
            total = totalEvaluated
        )

        /*
         * Group by both subject and topic.
         *
         * For example:
         * Mathematics -> Algebra
         * Physics -> Algebra
         *
         * These must not be treated as the same topic.
         */
        val topicGroups = evaluatedAnswers.groupBy {
            TopicKey(
                subject = normalize(it.subject),
                topic = normalize(it.topic)
            )
        }

        val insights = topicGroups.map { (_, answers) ->

            val correct = answers.count {
                it.isCorrect
            }

            val incorrect = answers.count {
                !it.isCorrect
            }

            val total = answers.size

            val accuracy = calculateAccuracy(
                correct = correct,
                total = total
            )

            val level = determinePerformanceLevel(
                accuracy = accuracy,
                total = total
            )

            val trendData = calculateTrend(
                answers = answers
            )

            val recommendedDifficulty = determineDifficulty(
                level = level,
                accuracy = accuracy,
                recentAccuracy = trendData.recentAccuracy,
                recentAnswerCount = trendData.recentAnswerCount
            )

            val priorityScore = calculatePriorityScore(
                level = level,
                accuracy = accuracy,
                trend = trendData.trend,
                totalAnswers = total
            )

            val recommendedQuestionCount =
                determineQuestionCount(
                    level = level,
                    trend = trendData.trend,
                    priorityScore = priorityScore
                )

            TopicPerformanceInsight(
                topic = answers.first().topic,
                correctAnswers = correct,
                incorrectAnswers = incorrect,
                evaluatedAnswers = total,
                accuracy = accuracy,
                level = level,
                recommendation = getRecommendation(
                    level = level,
                    trend = trendData.trend,
                    difficulty = recommendedDifficulty,
                    accuracy = accuracy,
                    recentAccuracy = trendData.recentAccuracy
                ),
                subject = answers.first().subject,
                recentAccuracy = trendData.recentAccuracy,
                previousAccuracy = trendData.previousAccuracy,
                trend = trendData.trend,
                recommendedDifficulty = recommendedDifficulty,
                recommendedQuestionCount = recommendedQuestionCount,
                priorityScore = priorityScore
            )
        }.sortedWith(
            compareBy<TopicPerformanceInsight> {
                levelPriority(it.level)
            }.thenByDescending {
                it.priorityScore
            }.thenBy {
                it.accuracy
            }.thenByDescending {
                it.evaluatedAnswers
            }
        )

        val weakTopics = insights.filter {
            it.level == TopicPerformanceLevel.WEAK
        }

        val improvementTopics = insights.filter {
            it.level == TopicPerformanceLevel.NEEDS_IMPROVEMENT
        }

        val insufficientTopics = insights.filter {
            it.level == TopicPerformanceLevel.INSUFFICIENT_DATA
        }

        val goodTopics = insights.filter {
            it.level == TopicPerformanceLevel.GOOD
        }

        /*
         * Recommended topic order:
         *
         * 1. Weak topics.
         * 2. Topics needing improvement.
         * 3. Declining topics.
         * 4. Topics with insufficient evidence.
         *
         * Good and stable topics are not prioritized unnecessarily.
         */
        val recommendedTopics = insights
            .filter { insight ->
                insight.level == TopicPerformanceLevel.WEAK ||
                    insight.level == TopicPerformanceLevel.NEEDS_IMPROVEMENT ||
                    insight.trend == PerformanceTrend.DECLINING ||
                    insight.level == TopicPerformanceLevel.INSUFFICIENT_DATA
            }
            .distinctBy {
                it.id
            }
            .sortedWith(
                compareBy<TopicPerformanceInsight> {
                    recommendationPriority(it)
                }.thenByDescending {
                    it.priorityScore
                }.thenBy {
                    it.accuracy
                }
            )

        return PracticePerformanceAnalysis(
            topics = insights,
            weakTopics = weakTopics,
            topicsNeedingImprovement = improvementTopics,
            insufficientDataTopics = insufficientTopics,
            totalTopics = insights.size,
            goodTopics = goodTopics,
            recommendedTopics = recommendedTopics,
            improvingTopics = insights.filter {
                it.trend == PerformanceTrend.IMPROVING
            },
            decliningTopics = insights.filter {
                it.trend == PerformanceTrend.DECLINING
            },
            overallAccuracy = overallAccuracy,
            totalEvaluatedAnswers = totalEvaluated,
            totalCorrectAnswers = totalCorrect,
            subject = requestedSubject?.trim()
        )
    }

    private fun determinePerformanceLevel(
        accuracy: Int,
        total: Int
    ): TopicPerformanceLevel {

        return when {
            total < MINIMUM_ANSWERS_FOR_ANALYSIS ->
                TopicPerformanceLevel.INSUFFICIENT_DATA

            accuracy < WEAK_ACCURACY_THRESHOLD ->
                TopicPerformanceLevel.WEAK

            accuracy < GOOD_ACCURACY_THRESHOLD ->
                TopicPerformanceLevel.NEEDS_IMPROVEMENT

            else ->
                TopicPerformanceLevel.GOOD
        }
    }

    /**
     * Compares the most recent three attempts with the preceding
     * three attempts for the same subject-topic combination.
     *
     * Multiple answers from one attempt remain grouped together.
     */
    private fun calculateTrend(
        answers: List<AnalyzedAnswer>
    ): TrendData {

        val attempts = answers
            .groupBy { it.attemptId }
            .values
            .sortedBy { attemptAnswers ->
                attemptAnswers.maxOfOrNull {
                    it.completedAt
                } ?: 0L
            }

        if (attempts.size < 2) {
            return TrendData()
        }

        val recentAttempts = attempts.takeLast(
            RECENT_ATTEMPT_WINDOW
        )

        val previousAttempts = attempts
            .dropLast(RECENT_ATTEMPT_WINDOW)
            .takeLast(RECENT_ATTEMPT_WINDOW)

        val recentAnswers = recentAttempts.flatten()
        val previousAnswers = previousAttempts.flatten()

        val recentAccuracy = calculateAccuracy(
            correct = recentAnswers.count { it.isCorrect },
            total = recentAnswers.size
        )

        /*
         * A previous comparison window is required.
         * Without it, the analyzer cannot claim improvement
         * or decline.
         */
        if (
            previousAnswers.size < MINIMUM_ANSWERS_FOR_TREND ||
            recentAnswers.size < MINIMUM_ANSWERS_FOR_TREND
        ) {
            return TrendData(
                recentAccuracy = recentAccuracy,
                previousAccuracy = null,
                recentAnswerCount = recentAnswers.size,
                trend = PerformanceTrend.INSUFFICIENT_DATA
            )
        }

        val previousAccuracy = calculateAccuracy(
            correct = previousAnswers.count { it.isCorrect },
            total = previousAnswers.size
        )

        val difference = recentAccuracy - previousAccuracy

        val trend = when {
            difference >= TREND_CHANGE_THRESHOLD ->
                PerformanceTrend.IMPROVING

            difference <= -TREND_CHANGE_THRESHOLD ->
                PerformanceTrend.DECLINING

            else ->
                PerformanceTrend.STABLE
        }

        return TrendData(
            recentAccuracy = recentAccuracy,
            previousAccuracy = previousAccuracy,
            recentAnswerCount = recentAnswers.size,
            trend = trend
        )
    }

    /**
     * Difficulty decisions use both lifetime performance
     * and recent performance when sufficient recent evidence
     * exists.
     */
    private fun determineDifficulty(
        level: TopicPerformanceLevel,
        accuracy: Int,
        recentAccuracy: Int?,
        recentAnswerCount: Int
    ): AdaptiveDifficulty {

        if (level == TopicPerformanceLevel.INSUFFICIENT_DATA) {
            return AdaptiveDifficulty.MEDIUM
        }

        val effectiveAccuracy =
            if (
                recentAccuracy != null &&
                recentAnswerCount >= MINIMUM_ANSWERS_FOR_TREND
            ) {
                /*
                 * Recent performance receives more weight.
                 * Lifetime accuracy prevents extreme decisions
                 * based on a tiny recent sample.
                 */
                (recentAccuracy * 2 + accuracy) / 3
            } else {
                accuracy
            }

        return when {
            effectiveAccuracy < WEAK_ACCURACY_THRESHOLD ->
                AdaptiveDifficulty.EASY

            effectiveAccuracy < GOOD_ACCURACY_THRESHOLD ->
                AdaptiveDifficulty.MEDIUM

            else ->
                AdaptiveDifficulty.HARD
        }
    }

    /**
     * Priority score is a deterministic ranking signal.
     *
     * Higher scores indicate that the topic deserves more
     * immediate attention.
     */
    private fun calculatePriorityScore(
        level: TopicPerformanceLevel,
        accuracy: Int,
        trend: PerformanceTrend,
        totalAnswers: Int
    ): Int {

        var score = when (level) {
            TopicPerformanceLevel.WEAK -> 60
            TopicPerformanceLevel.NEEDS_IMPROVEMENT -> 35
            TopicPerformanceLevel.INSUFFICIENT_DATA -> 15
            TopicPerformanceLevel.GOOD -> 0
        }

        if (level != TopicPerformanceLevel.INSUFFICIENT_DATA) {
            score += ((100 - accuracy) * 25) / 100
        }

        score += when (trend) {
            PerformanceTrend.DECLINING -> 20
            PerformanceTrend.IMPROVING -> -10
            PerformanceTrend.STABLE -> 0
            PerformanceTrend.INSUFFICIENT_DATA -> 0
        }

        /*
         * A topic with very little data should not receive
         * an exaggerated priority based on unreliable results.
         */
        if (
            totalAnswers < MINIMUM_ANSWERS_FOR_ANALYSIS
        ) {
            score = minOf(score, 25)
        }

        return score.coerceIn(
            MINIMUM_PRIORITY_SCORE,
            MAXIMUM_PRIORITY_SCORE
        )
    }

    private fun determineQuestionCount(
        level: TopicPerformanceLevel,
        trend: PerformanceTrend,
        priorityScore: Int
    ): Int {

        val count = when {
            level == TopicPerformanceLevel.INSUFFICIENT_DATA ->
                DEFAULT_QUESTION_COUNT

            level == TopicPerformanceLevel.WEAK ->
                12

            level == TopicPerformanceLevel.NEEDS_IMPROVEMENT ->
                10

            trend == PerformanceTrend.DECLINING ->
                10

            level == TopicPerformanceLevel.GOOD &&
                trend == PerformanceTrend.IMPROVING ->
                8

            level == TopicPerformanceLevel.GOOD ->
                5

            priorityScore >= 60 ->
                12

            else ->
                DEFAULT_QUESTION_COUNT
        }

        return count.coerceIn(
            MINIMUM_QUESTION_COUNT,
            MAXIMUM_QUESTION_COUNT
        )
    }

    private fun getRecommendation(
        level: TopicPerformanceLevel,
        trend: PerformanceTrend,
        difficulty: AdaptiveDifficulty,
        accuracy: Int,
        recentAccuracy: Int?
    ): String {

        return when (level) {

            TopicPerformanceLevel.INSUFFICIENT_DATA ->
                "Complete more evaluated questions on this topic. At least 3 answers are required before making a reliable performance classification."

            TopicPerformanceLevel.WEAK -> {
                if (trend == PerformanceTrend.IMPROVING) {
                    "Your recent performance is improving, but overall accuracy is still low. Continue revising fundamentals and practise easier questions."
                } else {
                    "Revise the fundamentals, review incorrect answers and practise easier questions before increasing difficulty."
                }
            }

            TopicPerformanceLevel.NEEDS_IMPROVEMENT -> {
                if (trend == PerformanceTrend.DECLINING) {
                    "Your recent accuracy has declined. Revisit the concepts behind your mistakes and reinforce them with focused practice."
                } else {
                    "Review the concepts behind incorrect answers and practise more questions. Increase difficulty after your accuracy becomes consistent."
                }
            }

            TopicPerformanceLevel.GOOD -> {
                if (trend == PerformanceTrend.DECLINING) {
                    "Your overall accuracy is good, but recent performance has declined. Review recent mistakes before moving to harder questions."
                } else {
                    "Your performance is strong. Maintain regular practice and gradually challenge yourself with harder questions."
                }
            }
        }
    }

    private fun recommendationPriority(
        insight: TopicPerformanceInsight
    ): Int {

        return when {
            insight.level == TopicPerformanceLevel.WEAK -> 0

            insight.level == TopicPerformanceLevel.NEEDS_IMPROVEMENT &&
                insight.trend == PerformanceTrend.DECLINING -> 1

            insight.level == TopicPerformanceLevel.NEEDS_IMPROVEMENT -> 2

            insight.trend == PerformanceTrend.DECLINING -> 3

            insight.level == TopicPerformanceLevel.INSUFFICIENT_DATA -> 4

            else -> 5
        }
    }

    private fun levelPriority(
        level: TopicPerformanceLevel
    ): Int {

        return when (level) {
            TopicPerformanceLevel.WEAK -> 0
            TopicPerformanceLevel.NEEDS_IMPROVEMENT -> 1
            TopicPerformanceLevel.GOOD -> 2
            TopicPerformanceLevel.INSUFFICIENT_DATA -> 3
        }
    }

    private fun calculateAccuracy(
        correct: Int,
        total: Int
    ): Int {

        return if (total <= 0) {
            0
        } else {
            ((correct.toFloat() / total.toFloat()) * 100)
                .toInt()
                .coerceIn(0, 100)
        }
    }

    private fun normalize(value: String): String {
        return value.trim()
            .replace(Regex("""\s+"""), " ")
            .lowercase()
    }

    private fun normalizeTopic(value: String): String {
        return value.trim()
            .replace(Regex("""\s+"""), " ")
    }

    private fun normalizeDifficulty(value: String): String {
        return when (value.trim().uppercase()) {
            "EASY", "BEGINNER" -> "EASY"
            "HARD", "ADVANCED" -> "HARD"
            else -> "MEDIUM"
        }
    }

    private data class TopicKey(
        val subject: String,
        val topic: String
    )

    private data class AnalyzedAnswer(
        val subject: String,
        val topic: String,
        val isCorrect: Boolean,
        val difficulty: String,
        val completedAt: Long,
        val attemptId: String
    )

    private data class TrendData(
        val recentAccuracy: Int? = null,
        val previousAccuracy: Int? = null,
        val recentAnswerCount: Int = 0,
        val trend: PerformanceTrend =
            PerformanceTrend.INSUFFICIENT_DATA
    )
}
