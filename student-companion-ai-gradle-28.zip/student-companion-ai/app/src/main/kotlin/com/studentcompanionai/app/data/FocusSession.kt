
package com.studentcompanionai.app.data

data class FocusSession(
    val id: Long,
    val minutes: Int,
    val timestamp: Long,
    val subjectId: Int? = null,
    val taskId: Int? = null,

    // AI Planner relationships
    val learningPlanId: String? = null,
    val learningActivityId: String? = null,

    // Actual session timing
    val startedAt: Long = 0L,
    val endedAt: Long = 0L,

    // Session completion state
    val completed: Boolean = true
)
