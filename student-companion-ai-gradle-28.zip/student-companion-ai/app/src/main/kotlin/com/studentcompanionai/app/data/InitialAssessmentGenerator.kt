
package com.studentcompanionai.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class InitialAssessmentGenerator {

    private val aiService = StudyAIService()

    suspend fun generateAssessment(
        profile: LearningCoachProfile,
        questionCount: Int = 12
    ): List<InitialAssessmentQuestion> = withContext(Dispatchers.IO) {

        require(profile.isValid()) {
            "The learner profile is invalid. Please update it first."
        }

        require(questionCount in 5..30) {
            "Assessment must contain between 5 and 30 questions."
        }

        val prompt = """
            You are the diagnostic assessment engine for
            Student Companion AI.

            Your task is to measure the learner's existing knowledge.
            Do not create a teaching quiz or assume that the learner
            already knows the subject.

            LEARNER PROFILE
            Learning goal: ${profile.learningGoal}
            Subject or skill: ${profile.subject}
            Self-reported level: ${profile.currentLevel.displayName}
            Target duration: ${profile.targetDays} days
            Daily study time: ${profile.dailyStudyMinutes} minutes
            Preferred learning style: ${profile.preferredLearningStyle.displayName}

            ASSESSMENT REQUIREMENTS

            1. Generate exactly $questionCount questions.
            2. Cover different important topics within the subject.
            3. Questions must relate to the learner's stated goal.
            4. Do not rely only on the learner's self-reported level.
            5. Include a balanced mixture of:
               - MCQ
               - SHORT_ANSWER
               - PROBLEM_SOLVING
            6. Include EASY, MEDIUM and HARD questions.
            7. Use clear, unambiguous language.
            8. Avoid duplicate or nearly identical questions.
            9. Questions must test understanding, not just memorization.
            10. Every question must have a reliable reference answer.
            11. Short-answer and problem-solving questions must include
                specific evaluation criteria.
            12. MCQ questions must have exactly four options.
            13. For MCQ, correctAnswer must be the zero-based option index
                represented as a JSON string: "0", "1", "2" or "3".
            14. For written questions, correctAnswer must contain a
                reference answer or expected solution.
            15. Do not include answers in the question text.
            16. Return ONLY valid JSON. No markdown or extra text.

            REQUIRED JSON STRUCTURE

            {
              "questions": [
                {
                  "question": "Question text",
                  "type": "MCQ",
                  "topic": "Topic name",
                  "difficulty": "EASY",
                  "options": [
                    "Option A",
                    "Option B",
                    "Option C",
                    "Option D"
                  ],
                  "correctAnswer": "2",
                  "explanation": "Explanation of the correct answer",
                  "evaluationCriteria": [],
                  "maximumMarks": 1
                },
                {
                  "question": "Explain the concept...",
                  "type": "SHORT_ANSWER",
                  "topic": "Topic name",
                  "difficulty": "MEDIUM",
                  "options": [],
                  "correctAnswer": "Expected reference answer",
                  "explanation": "Explanation of the expected answer",
                  "evaluationCriteria": [
                    "Identifies the main concept",
                    "Explains its purpose correctly"
                  ],
                  "maximumMarks": 3
                },
                {
                  "question": "Solve the following problem...",
                  "type": "PROBLEM_SOLVING",
                  "topic": "Topic name",
                  "difficulty": "HARD",
                  "options": [],
                  "correctAnswer": "Expected solution",
                  "explanation": "Explanation of the solution",
                  "evaluationCriteria": [
                    "Uses the correct method",
                    "Shows valid intermediate steps",
                    "Obtains the correct final answer"
                  ],
                  "maximumMarks": 5
                }
              ]
            }

            VALID QUESTION TYPES:
            MCQ, SHORT_ANSWER, PROBLEM_SOLVING

            VALID DIFFICULTIES:
            EASY, MEDIUM, HARD

            Return exactly $questionCount questions.
            Do not generate IDs. The application generates IDs locally.
        """.trimIndent()

        val response = aiService.generateStructuredReply(prompt)

        parseQuestions(
            response = response,
            expectedCount = questionCount
        )
    }

    private fun parseQuestions(
        response: String,
        expectedCount: Int
    ): List<InitialAssessmentQuestion> {

        val root = JSONObject(extractJson(response))

        val jsonQuestions = root.optJSONArray("questions")
            ?: throw IllegalStateException(
                "The AI response does not contain assessment questions."
            )

        if (jsonQuestions.length() != expectedCount) {
            throw IllegalStateException(
                "The AI generated ${jsonQuestions.length()} questions, " +
                    "but $expectedCount were required. Please try again."
            )
        }

        val questions = mutableListOf<InitialAssessmentQuestion>()
        val questionTexts = mutableSetOf<String>()

        for (i in 0 until jsonQuestions.length()) {

            val item = jsonQuestions.optJSONObject(i)
                ?: throw IllegalStateException(
                    "Question ${i + 1} is not a valid JSON object."
                )

            val questionText = requiredString(item, "question")
            val normalizedText = questionText
                .trim()
                .lowercase()

            if (!questionTexts.add(normalizedText)) {
                throw IllegalStateException(
                    "The AI generated duplicate questions. Please try again."
                )
            }

            val type = parseEnum<AssessmentQuestionType>(
                requiredString(item, "type"),
                "question type"
            )

            val difficulty = parseEnum<AssessmentDifficulty>(
                requiredString(item, "difficulty"),
                "question difficulty"
            )

            val topic = requiredString(item, "topic")
            val correctAnswer = requiredString(item, "correctAnswer")
            val explanation = requiredString(item, "explanation")

            val options = readStringArray(
                item.optJSONArray("options")
            )

            val evaluationCriteria = readStringArray(
                item.optJSONArray("evaluationCriteria")
            )

            val maximumMarks = item.optInt("maximumMarks", -1)

            if (maximumMarks <= 0) {
                throw IllegalStateException(
                    "Question ${i + 1} has invalid maximum marks."
                )
            }

            if (type == AssessmentQuestionType.MCQ) {

                if (options.size != 4) {
                    throw IllegalStateException(
                        "MCQ question ${i + 1} must have exactly four options."
                    )
                }

                val correctIndex = correctAnswer.toIntOrNull()

                if (correctIndex == null || correctIndex !in options.indices) {
                    throw IllegalStateException(
                        "MCQ question ${i + 1} has an invalid correct answer."
                    )
                }

                if (maximumMarks != 1) {
                    throw IllegalStateException(
                        "MCQ questions must have exactly one mark."
                    )
                }

                if (evaluationCriteria.isNotEmpty()) {
                    throw IllegalStateException(
                        "MCQ questions must not contain written evaluation criteria."
                    )
                }

            } else {

                if (options.isNotEmpty()) {
                    throw IllegalStateException(
                        "Written questions must not contain MCQ options."
                    )
                }

                if (evaluationCriteria.isEmpty()) {
                    throw IllegalStateException(
                        "Written question ${i + 1} has no evaluation criteria."
                    )
                }
            }

            questions.add(
                InitialAssessmentQuestion(
                    id = UUID.randomUUID().toString(),
                    question = questionText,
                    type = type,
                    topic = topic,
                    difficulty = difficulty,
                    options = options,
                    correctAnswer = correctAnswer,
                    explanation = explanation,
                    evaluationCriteria = evaluationCriteria,
                    maximumMarks = maximumMarks
                )
            )
        }

        return questions
    }

    private fun requiredString(
        json: JSONObject,
        key: String
    ): String {

        if (!json.has(key) || json.isNull(key)) {
            throw IllegalStateException(
                "The AI response is missing required field: $key"
            )
        }

        val value = json.optString(key, "").trim()

        if (value.isEmpty()) {
            throw IllegalStateException(
                "The AI response contains an empty field: $key"
            )
        }

        return value
    }

    private fun readStringArray(
        array: JSONArray?
    ): List<String> {

        if (array == null) {
            return emptyList()
        }

        return buildList {
            for (i in 0 until array.length()) {

                val value = array.optString(i, "").trim()

                if (value.isEmpty()) {
                    throw IllegalStateException(
                        "The AI response contains an empty array item."
                    )
                }

                add(value)
            }
        }
    }

    private inline fun <reified T : Enum<T>> parseEnum(
        value: String,
        fieldName: String
    ): T {

        return enumValues<T>().firstOrNull {
            it.name == value.trim().uppercase()
        } ?: throw IllegalStateException(
            "The AI returned an unsupported $fieldName: $value"
        )
    }

    private fun extractJson(response: String): String {

        val cleaned = response
            .trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')

        if (start == -1 || end <= start) {
            throw IllegalStateException(
                "The AI did not return valid JSON. Please try again."
            )
        }

        return cleaned.substring(start, end + 1)
    }
}
