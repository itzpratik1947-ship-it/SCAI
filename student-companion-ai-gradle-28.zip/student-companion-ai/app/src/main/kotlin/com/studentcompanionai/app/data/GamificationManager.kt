
package com.studentcompanionai.app.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class GamificationSnapshot(
    val totalXp: Int,
    val level: Int,
    val xpInCurrentLevel: Int,
    val xpForNextLevel: Int,
    val streakDays: Int,
    val totalActivities: Int,
    val achievements: List<String>
)

data class XpBreakdown(
    val correctAnswers: Int,
    val incorrectAnswers: Int,
    val xpEarned: Int,
    val xpDeducted: Int,
    val netXpChange: Int,
    val totalXp: Int,
    val level: Int,
    val alreadyProcessed: Boolean = false
)

class GamificationManager(
    context: Context,
    uid: String? = null
) {

    private val appContext = context.applicationContext

    private val accountUid = uid?.trim()?.also {
        require(it.isNotBlank()) {
            "Firebase UID cannot be blank."
        }
    }

    private val legacyPreferences = appContext.getSharedPreferences(
        LEGACY_PREFERENCES_NAME,
        Context.MODE_PRIVATE
    )

    private val preferences = appContext.getSharedPreferences(
        if (accountUid == null) {
            LEGACY_PREFERENCES_NAME
        } else {
            ACCOUNT_PREFERENCES_PREFIX + accountUid
        },
        Context.MODE_PRIVATE
    )

    private val legacyClaimPreferences = appContext.getSharedPreferences(
        LEGACY_CLAIM_PREFERENCES_NAME,
        Context.MODE_PRIVATE
    )

    companion object {

        private const val LEGACY_PREFERENCES_NAME =
            "student_gamification"

        private const val ACCOUNT_PREFERENCES_PREFIX =
            "student_gamification_"

        private const val LEGACY_CLAIM_PREFERENCES_NAME =
            "student_gamification_legacy_claim"

        private const val KEY_CLAIMED_UID =
            "claimed_uid"

        private const val KEY_MIGRATION_COMPLETED =
            "legacy_gamification_migration_completed"

        private const val KEY_TOTAL_XP =
            "total_xp"

        private const val KEY_STREAK =
            "streak_days"

        private const val KEY_LAST_ACTIVE =
            "last_active"

        private const val KEY_TOTAL_ACTIVITIES =
            "total_activities"

        private const val KEY_COMPLETED_EVENTS =
            "completed_events"

        private const val KEY_ACHIEVEMENTS =
            "achievements"

        private const val XP_PER_CORRECT = 10

        private const val XP_PER_INCORRECT = 5

        private const val MAX_STORED_EVENTS = 500

        private val GAMIFICATION_KEYS = setOf(
            KEY_TOTAL_XP,
            KEY_STREAK,
            KEY_LAST_ACTIVE,
            KEY_TOTAL_ACTIVITIES,
            KEY_COMPLETED_EVENTS,
            KEY_ACHIEVEMENTS
        )

        private val migrationLock = Any()
    }

    private val dateFormat =
        SimpleDateFormat("yyyy-MM-dd", Locale.US)

    init {
        accountUid?.let { uid ->
            migrateLegacyData(
                uid = uid,
                confirmedUnknownOwner = false
            )
        }
    }

    // =============================================
    // LEGACY DATA MIGRATION
    // =============================================

    @Synchronized
    fun migrateLegacyDataIfSafe(): LegacyMigrationStatus {

        val uid = accountUid
            ?: return LegacyMigrationStatus.NOT_ACCOUNT_SCOPED

        return migrateLegacyData(
            uid = uid,
            confirmedUnknownOwner = false
        )
    }

    @Synchronized
    fun claimLegacyDataForCurrentUser(
        confirmedOwnership: Boolean
    ): LegacyMigrationStatus {

        val uid = accountUid
            ?: return LegacyMigrationStatus.NOT_ACCOUNT_SCOPED

        return migrateLegacyData(
            uid = uid,
            confirmedUnknownOwner = confirmedOwnership
        )
    }

    private fun migrateLegacyData(
        uid: String,
        confirmedUnknownOwner: Boolean
    ): LegacyMigrationStatus {

        return synchronized(migrationLock) {

            if (
                preferences.getBoolean(
                    KEY_MIGRATION_COMPLETED,
                    false
                )
            ) {
                return@synchronized LegacyMigrationStatus.ALREADY_MIGRATED
            }

            if (!hasLegacyGamificationData()) {
                return@synchronized LegacyMigrationStatus.NO_LEGACY_DATA
            }

            val legacyOwnerUid = StudentStorage(
                appContext,
                uid
            ).getLegacyDataOwnerUid()

            if (
                !legacyOwnerUid.isNullOrBlank() &&
                legacyOwnerUid != uid
            ) {
                return@synchronized LegacyMigrationStatus.OWNER_MISMATCH
            }

            val previouslyClaimedUid =
                legacyClaimPreferences.getString(
                    KEY_CLAIMED_UID,
                    null
                )

            if (
                !previouslyClaimedUid.isNullOrBlank() &&
                previouslyClaimedUid != uid
            ) {
                return@synchronized LegacyMigrationStatus.OWNER_MISMATCH
            }

            if (
                legacyOwnerUid.isNullOrBlank() &&
                previouslyClaimedUid.isNullOrBlank() &&
                !confirmedUnknownOwner
            ) {
                return@synchronized LegacyMigrationStatus.OWNERSHIP_CONFIRMATION_REQUIRED
            }

            if (
                legacyOwnerUid.isNullOrBlank() &&
                previouslyClaimedUid.isNullOrBlank()
            ) {

                val claimSaved = legacyClaimPreferences.edit()
                    .putString(KEY_CLAIMED_UID, uid)
                    .commit()

                if (!claimSaved) {
                    return@synchronized LegacyMigrationStatus.FAILED
                }
            }

            try {

                val legacyXp = legacyPreferences.getInt(
                    KEY_TOTAL_XP,
                    0
                ).coerceAtLeast(0)

                val accountXp = preferences.getInt(
                    KEY_TOTAL_XP,
                    0
                ).coerceAtLeast(0)

                val legacyActivities = legacyPreferences.getInt(
                    KEY_TOTAL_ACTIVITIES,
                    0
                ).coerceAtLeast(0)

                val accountActivities = preferences.getInt(
                    KEY_TOTAL_ACTIVITIES,
                    0
                ).coerceAtLeast(0)

                val legacyStreak = legacyPreferences.getInt(
                    KEY_STREAK,
                    0
                ).coerceAtLeast(0)

                val accountStreak = preferences.getInt(
                    KEY_STREAK,
                    0
                ).coerceAtLeast(0)

                val mergedXp = maxOf(legacyXp, accountXp)
                val mergedActivities = maxOf(
                    legacyActivities,
                    accountActivities
                )
                val mergedStreak = maxOf(
                    legacyStreak,
                    accountStreak
                )

                val mergedLastActive = latestDate(
                    legacyPreferences.getString(
                        KEY_LAST_ACTIVE,
                        null
                    ),
                    preferences.getString(
                        KEY_LAST_ACTIVE,
                        null
                    )
                )

                val mergedEvents = mergeCompletedEvents(
                    legacyPreferences,
                    preferences
                )

                val mergedAchievements = mergeAchievements(
                    legacyPreferences,
                    preferences
                )

                val editor = preferences.edit()

                editor.putInt(KEY_TOTAL_XP, mergedXp)
                editor.putInt(
                    KEY_TOTAL_ACTIVITIES,
                    mergedActivities
                )
                editor.putInt(KEY_STREAK, mergedStreak)

                if (mergedLastActive != null) {
                    editor.putString(
                        KEY_LAST_ACTIVE,
                        mergedLastActive
                    )
                }

                editor.putString(
                    KEY_COMPLETED_EVENTS,
                    mergedEvents.toString()
                )

                editor.putString(
                    KEY_ACHIEVEMENTS,
                    mergedAchievements.toString()
                )

                editor.putBoolean(
                    KEY_MIGRATION_COMPLETED,
                    true
                )

                if (editor.commit()) {
                    LegacyMigrationStatus.MIGRATED
                } else {
                    LegacyMigrationStatus.FAILED
                }

            } catch (_: Exception) {
                LegacyMigrationStatus.FAILED
            }
        }
    }

    private fun hasLegacyGamificationData(): Boolean {
        return GAMIFICATION_KEYS.any { key ->
            legacyPreferences.contains(key)
        }
    }

    private fun latestDate(
        first: String?,
        second: String?
    ): String? {

        val validFirst = first?.takeIf {
            isValidDate(it)
        }

        val validSecond = second?.takeIf {
            isValidDate(it)
        }

        return listOfNotNull(
            validFirst,
            validSecond
        ).maxOrNull()
    }

    private fun isValidDate(value: String): Boolean {
        return try {
            val formatter = SimpleDateFormat(
                "yyyy-MM-dd",
                Locale.US
            ).apply {
                isLenient = false
            }

            val parsed = formatter.parse(value) ?: return false

            formatter.format(parsed) == value

        } catch (_: Exception) {
            false
        }
    }

    private fun mergeCompletedEvents(
        legacy: SharedPreferences,
        account: SharedPreferences
    ): JSONArray {

        val merged = LinkedHashSet<String>()

        readStringArray(
            legacy.getString(KEY_COMPLETED_EVENTS, null)
        ).forEach {
            if (it.isNotBlank()) merged.add(it)
        }

        readStringArray(
            account.getString(KEY_COMPLETED_EVENTS, null)
        ).forEach {
            if (it.isNotBlank()) merged.add(it)
        }

        return JSONArray(
            merged.toList().takeLast(MAX_STORED_EVENTS)
        )
    }

    private fun readStringArray(
        json: String?
    ): List<String> {

        if (json.isNullOrBlank()) {
            return emptyList()
        }

        return try {

            val array = JSONArray(json)

            buildList {
                for (index in 0 until array.length()) {
                    val value = array.optString(index, "")

                    if (value.isNotBlank()) {
                        add(value)
                    }
                }
            }

        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun mergeAchievements(
        legacy: SharedPreferences,
        account: SharedPreferences
    ): JSONArray {

        val merged = LinkedHashSet<String>()

        readStringArray(
            legacy.getString(KEY_ACHIEVEMENTS, null)
        ).forEach {
            merged.add(it)
        }

        readStringArray(
            account.getString(KEY_ACHIEVEMENTS, null)
        ).forEach {
            merged.add(it)
        }

        return JSONArray(merged.toList())
    }

    // =============================================
    // QUIZ XP PROCESSING
    // =============================================

    @Synchronized
    fun recordCompletedQuiz(
        eventId: String,
        answers: List<PracticeAnswer>
    ): XpBreakdown {

        require(eventId.isNotBlank()) {
            "Event ID cannot be empty."
        }

        require(answers.isNotEmpty()) {
            "Cannot process a quiz without answers."
        }

        // Only evaluated answers can affect XP.
        val evaluatedAnswers = answers.filter {
            it.isEvaluated
        }

        require(evaluatedAnswers.isNotEmpty()) {
            "Cannot award or deduct XP because no answers have been evaluated."
        }

        val completedEvents = preferences
            .getString(KEY_COMPLETED_EVENTS, null)
            ?.let {
                try {
                    JSONArray(it)
                } catch (_: Exception) {
                    JSONArray()
                }
            }
            ?: JSONArray()

        val correctAnswers = evaluatedAnswers.count {
            it.isCorrect
        }

        val incorrectAnswers =
            evaluatedAnswers.size - correctAnswers

        // Prevent duplicate processing for the same event ID.
        for (index in 0 until completedEvents.length()) {

            if (
                completedEvents.optString(index) == eventId
            ) {

                val snapshot = getSnapshot()

                return XpBreakdown(
                    correctAnswers = correctAnswers,
                    incorrectAnswers = incorrectAnswers,
                    xpEarned = 0,
                    xpDeducted = 0,
                    netXpChange = 0,
                    totalXp = snapshot.totalXp,
                    level = snapshot.level,
                    alreadyProcessed = true
                )
            }
        }

        val xpEarned =
            correctAnswers * XP_PER_CORRECT

        val xpDeducted =
            incorrectAnswers * XP_PER_INCORRECT

        val netXpChange =
            xpEarned - xpDeducted

        val currentXp = preferences.getInt(
            KEY_TOTAL_XP,
            0
        ).coerceAtLeast(0)

        val newXp = (
            currentXp + netXpChange
        ).coerceAtLeast(0)

        val currentActivities = preferences.getInt(
            KEY_TOTAL_ACTIVITIES,
            0
        ).coerceAtLeast(0)

        val updatedEvents = JSONArray()

        val startIndex = maxOf(
            0,
            completedEvents.length() - MAX_STORED_EVENTS + 1
        )

        for (
            index in startIndex until completedEvents.length()
        ) {
            updatedEvents.put(
                completedEvents.optString(index)
            )
        }

        updatedEvents.put(eventId)

        val editor = preferences.edit()

        editor.putInt(
            KEY_TOTAL_XP,
            newXp
        )

        editor.putInt(
            KEY_TOTAL_ACTIVITIES,
            currentActivities + 1
        )

        editor.putString(
            KEY_COMPLETED_EVENTS,
            updatedEvents.toString()
        )

        updateStreak(editor)

        // Commit synchronously so the XP update and event ID
        // are persisted before reporting the transaction as applied.
        val saved = editor.commit()

        check(saved) {
            "Could not save the quiz XP transaction. Please retry."
        }

        updateAchievements()

        val snapshot = getSnapshot()

        return XpBreakdown(
            correctAnswers = correctAnswers,
            incorrectAnswers = incorrectAnswers,
            xpEarned = xpEarned,
            xpDeducted = xpDeducted,
            netXpChange = newXp - currentXp,
            totalXp = snapshot.totalXp,
            level = snapshot.level,
            alreadyProcessed = false
        )
    }

    // =============================================
    // GAMIFICATION SNAPSHOT
    // =============================================

    @Synchronized
    fun getSnapshot(): GamificationSnapshot {

        val totalXp = preferences
            .getInt(KEY_TOTAL_XP, 0)
            .coerceAtLeast(0)

        val streak = preferences
            .getInt(KEY_STREAK, 0)
            .coerceAtLeast(0)

        val activities = preferences
            .getInt(KEY_TOTAL_ACTIVITIES, 0)
            .coerceAtLeast(0)

        var level = 1
        var remainingXp = totalXp

        while (remainingXp >= level * 100) {
            remainingXp -= level * 100
            level++
        }

        return GamificationSnapshot(
            totalXp = totalXp,
            level = level,
            xpInCurrentLevel = remainingXp,
            xpForNextLevel = level * 100,
            streakDays = streak,
            totalActivities = activities,
            achievements = getAchievements()
        )
    }

    // =============================================
    // STREAK MANAGEMENT
    // =============================================

    private fun updateStreak(
        editor: SharedPreferences.Editor
    ) {

        val today = dateFormat.format(Date())

        val lastActive = preferences.getString(
            KEY_LAST_ACTIVE,
            null
        )

        var streak = preferences.getInt(
            KEY_STREAK,
            0
        )

        if (lastActive != today) {

            streak = if (
                lastActive == getPreviousDate()
            ) {
                streak + 1
            } else {
                1
            }

            editor.putInt(
                KEY_STREAK,
                streak
            )

            editor.putString(
                KEY_LAST_ACTIVE,
                today
            )
        }
    }

    private fun getPreviousDate(): String {

        val calendar = Calendar.getInstance()

        calendar.add(
            Calendar.DAY_OF_YEAR,
            -1
        )

        return dateFormat.format(calendar.time)
    }

    // =============================================
    // ACHIEVEMENTS
    // =============================================

    private fun updateAchievements() {

        val activities = preferences.getInt(
            KEY_TOTAL_ACTIVITIES,
            0
        )

        val xp = preferences.getInt(
            KEY_TOTAL_XP,
            0
        )

        val streak = preferences.getInt(
            KEY_STREAK,
            0
        )

        val achievements = getAchievements()
            .toMutableSet()

        if (activities >= 1) {
            achievements.add("FIRST_STEP")
        }

        if (activities >= 10) {
            achievements.add("CONSISTENCY")
        }

        if (activities >= 50) {
            achievements.add("DEDICATED_LEARNER")
        }

        if (xp >= 500) {
            achievements.add("XP_COLLECTOR")
        }

        if (xp >= 2000) {
            achievements.add("XP_MASTER")
        }

        if (streak >= 3) {
            achievements.add("THREE_DAY_STREAK")
        }

        if (streak >= 7) {
            achievements.add("WEEK_WARRIOR")
        }

        if (streak >= 30) {
            achievements.add("MONTHLY_CHAMPION")
        }

        preferences.edit()
            .putString(
                KEY_ACHIEVEMENTS,
                JSONArray(achievements.toList()).toString()
            )
            .apply()
    }

    private fun getAchievements(): List<String> {

        val json = preferences.getString(
            KEY_ACHIEVEMENTS,
            null
        ) ?: return emptyList()

        return try {

            val array = JSONArray(json)

            (0 until array.length()).mapNotNull {
                array.optString(it)
                    .takeIf { achievement ->
                        achievement.isNotBlank()
                    }
            }.distinct()

        } catch (_: Exception) {
            emptyList()
        }
    }
}
