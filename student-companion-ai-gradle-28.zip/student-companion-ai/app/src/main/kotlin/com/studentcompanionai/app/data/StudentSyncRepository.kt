
package com.studentcompanionai.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class StudentSyncRepository(
    private val firestore: FirebaseFirestore =
        FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth =
        FirebaseAuth.getInstance()
) {

    private fun requireUserUid(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException(
                "Please sign in before syncing."
            )
    }

    private fun userDocument(expectedUid: String? = null) =
        firestore.collection("users").document(
            requireUserUid().also { currentUid ->
                if (
                    expectedUid != null &&
                    currentUid != expectedUid
                ) {
                    throw IllegalStateException(
                        "The signed-in account changed. Please sync again."
                    )
                }
            }
        )

    // --------------------------------------------------
    // SUBJECTS
    // --------------------------------------------------

    suspend fun uploadSubjects(subjects: List<Subject>) {
        val uid = requireUserUid()
        val user = userDocument(uid)

        for (subject in subjects.distinctBy { it.id }) {
            check(auth.currentUser?.uid == uid) {
                "The signed-in account changed during sync."
            }

            user.collection("subjects")
                .document(subject.id.toString())
                .set(
                    mapOf(
                        "id" to subject.id,
                        "name" to subject.name
                    )
                )
                .await()
        }
    }

    suspend fun downloadSubjects(): List<Subject> {
        val uid = requireUserUid()

        val snapshot = userDocument(uid)
            .collection("subjects")
            .get()
            .await()

        check(auth.currentUser?.uid == uid) {
            "The signed-in account changed during sync."
        }

        return snapshot.documents.mapNotNull { document ->
            val id = document.getLong("id")?.toInt()
            val name = document.getString("name")

            if (id != null && !name.isNullOrBlank()) {
                Subject(id = id, name = name)
            } else {
                null
            }
        }
    }

    suspend fun deleteSubjects(ids: Set<Int>) {
        deleteSubjects(ids, requireUserUid())
    }

    suspend fun deleteSubjects(
        ids: Set<Int>,
        expectedUid: String
    ) {
        deleteDocuments(
            collectionName = "subjects",
            ids = ids.map { it.toString() },
            expectedUid = expectedUid
        )
    }

    // --------------------------------------------------
    // TASKS
    // --------------------------------------------------

    suspend fun uploadTasks(tasks: List<StudyTask>) {
        val uid = requireUserUid()
        val user = userDocument(uid)

        for (task in tasks.distinctBy { it.id }) {

            check(auth.currentUser?.uid == uid) {
                "The signed-in account changed during sync."
            }

            val taskData = mapOf(
                "id" to task.id,
                "title" to task.title,
                "subjectId" to task.subjectId,
                "isCompleted" to task.isCompleted,
                "description" to task.description,
                "learningPlanId" to task.learningPlanId,
                "learningActivityId" to task.learningActivityId,
                "scheduledDate" to task.scheduledDate,
                "estimatedMinutes" to task.estimatedMinutes,
                "actualMinutes" to task.actualMinutes,
                "completedAt" to task.completedAt,
                "isSkipped" to task.isSkipped,
                "skippedAt" to task.skippedAt,
                "resources" to task.resources.map {
                    learningResourceToMap(it)
                }
            )

            user.collection("tasks")
                .document(task.id.toString())
                .set(taskData)
                .await()
        }

        check(auth.currentUser?.uid == uid) {
            "The signed-in account changed during sync."
        }
    }

    suspend fun downloadTasks(): List<StudyTask> {
        val uid = requireUserUid()

        val snapshot = userDocument(uid)
            .collection("tasks")
            .get()
            .await()

        check(auth.currentUser?.uid == uid) {
            "The signed-in account changed during sync."
        }

        return snapshot.documents.mapNotNull { document ->

            val id = document.getLong("id")?.toInt()
            val title = document.getString("title")

            if (id == null || title.isNullOrBlank()) {
                return@mapNotNull null
            }

            val resources = readLearningResources(
                document.get("resources")
            )

            StudyTask(
                id = id,
                title = title,
                subjectId = document.getLong("subjectId")?.toInt(),
                isCompleted =
                    document.getBoolean("isCompleted") ?: false,
                description =
                    document.getString("description") ?: "",
                learningPlanId =
                    document.getString("learningPlanId"),
                learningActivityId =
                    document.getString("learningActivityId"),
                scheduledDate =
                    document.getLong("scheduledDate") ?: 0L,
                estimatedMinutes =
                    document.getLong("estimatedMinutes")?.toInt() ?: 0,
                actualMinutes =
                    document.getLong("actualMinutes")?.toInt() ?: 0,
                completedAt =
                    document.getLong("completedAt") ?: 0L,
                isSkipped =
                    document.getBoolean("isSkipped") ?: false,
                skippedAt =
                    document.getLong("skippedAt") ?: 0L,
                resources = resources
            )
        }
    }

    suspend fun deleteTasks(ids: Set<Int>) {
        deleteTasks(ids, requireUserUid())
    }

    suspend fun deleteTasks(
        ids: Set<Int>,
        expectedUid: String
    ) {
        deleteDocuments(
            collectionName = "tasks",
            ids = ids.map { it.toString() },
            expectedUid = expectedUid
        )
    }

    // --------------------------------------------------
    // LEARNING RESOURCE SERIALIZATION
    // --------------------------------------------------

    private fun learningResourceToMap(
        resource: LearningResource
    ): Map<String, Any?> {

        return mapOf(
            "id" to resource.id,
            "title" to resource.title,
            "url" to resource.url,
            "type" to resource.type.name,
            "provider" to resource.provider,
            "description" to resource.description,
            "estimatedMinutes" to resource.estimatedMinutes,
            "allocatedMinutes" to resource.allocatedMinutes,
            "topic" to resource.topic
        )
    }

    private fun readLearningResources(
        rawResources: Any?
    ): List<LearningResource> {

        val resourceList = rawResources as? List<*>
            ?: return emptyList()

        return resourceList.mapNotNull { rawResource ->

            val data = rawResource as? Map<*, *>
                ?: return@mapNotNull null

            val id = data["id"] as? String
                ?: return@mapNotNull null

            val title = data["title"] as? String
                ?: return@mapNotNull null

            val url = data["url"] as? String
                ?: return@mapNotNull null

            if (id.isBlank() || title.isBlank() || url.isBlank()) {
                return@mapNotNull null
            }

            val typeName = data["type"] as? String ?: "WEBSITE"

            val resourceType = runCatching {
                LearningResourceType.valueOf(typeName)
            }.getOrDefault(LearningResourceType.WEBSITE)

            LearningResource(
                id = id,
                title = title,
                url = url,
                type = resourceType,
                provider = data["provider"] as? String ?: "",
                description = data["description"] as? String ?: "",
                estimatedMinutes =
                    (data["estimatedMinutes"] as? Number)?.toInt() ?: 0,
                allocatedMinutes =
                    (data["allocatedMinutes"] as? Number)?.toInt() ?: 0,
                topic = data["topic"] as? String ?: ""
            )
        }
    }

    // --------------------------------------------------
    // FOCUS SESSIONS
    // --------------------------------------------------

    suspend fun uploadFocusSessions(
        sessions: List<FocusSession>
    ) {
        val uid = requireUserUid()
        val user = userDocument(uid)

        for (session in sessions.distinctBy { it.id }) {

            check(auth.currentUser?.uid == uid) {
                "The signed-in account changed during sync."
            }

            user.collection("focusSessions")
                .document(session.id.toString())
                .set(
                    mapOf(
                        "id" to session.id,
                        "minutes" to session.minutes,
                        "timestamp" to session.timestamp,
                        "subjectId" to session.subjectId,
                        "taskId" to session.taskId
                    )
                )
                .await()
        }
    }

    suspend fun downloadFocusSessions(): List<FocusSession> {
        val uid = requireUserUid()

        val snapshot = userDocument(uid)
            .collection("focusSessions")
            .get()
            .await()

        check(auth.currentUser?.uid == uid) {
            "The signed-in account changed during sync."
        }

        return snapshot.documents.mapNotNull { document ->

            val id = document.getLong("id")
            val minutes = document.getLong("minutes")?.toInt()
            val timestamp = document.getLong("timestamp")

            if (id != null && minutes != null && timestamp != null) {
                FocusSession(
                    id = id,
                    minutes = minutes,
                    timestamp = timestamp,
                    subjectId =
                        document.getLong("subjectId")?.toInt(),
                    taskId =
                        document.getLong("taskId")?.toInt()
                )
            } else {
                null
            }
        }
    }

    // --------------------------------------------------
    // SAFE CLOUD DELETION
    // --------------------------------------------------

    private suspend fun deleteDocuments(
        collectionName: String,
        ids: List<String>,
        expectedUid: String
    ) {
        if (ids.isEmpty()) return

        val user = userDocument(expectedUid)
        val collection = user.collection(collectionName)

        // Firestore batches support at most 500 writes.
        // Keep a margin below that limit.
        ids.distinct().chunked(400).forEach { chunk ->

            check(auth.currentUser?.uid == expectedUid) {
                "The signed-in account changed during deletion."
            }

            val batch = firestore.batch()

            chunk.forEach { id ->
                batch.delete(collection.document(id))
            }

            batch.commit().await()
        }

        check(auth.currentUser?.uid == expectedUid) {
            "The signed-in account changed after deletion."
        }
    }
}
