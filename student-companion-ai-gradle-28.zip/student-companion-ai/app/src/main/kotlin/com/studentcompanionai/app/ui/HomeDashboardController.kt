
package com.studentcompanionai.app.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studentcompanionai.app.data.GamificationSnapshot
import com.studentcompanionai.app.ui.components.ScaiCard
import com.studentcompanionai.app.ui.components.ScaiDivider
import com.studentcompanionai.app.ui.components.ScaiPrimaryButton
import com.studentcompanionai.app.ui.components.ScaiScreen
import com.studentcompanionai.app.ui.components.ScaiSectionTitle
import com.studentcompanionai.app.ui.components.ScaiTopBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

class HomeDashboardController {

    data class ActiveFocus(
        val isActive: Boolean = false,
        val isPaused: Boolean = false,
        val remainingSeconds: Int = 0,
        val subjectName: String? = null,
        val taskTitle: String? = null
    )
}

@Composable
fun HomeDashboardScreen(
    focusSessions: Int,
    focusMinutes: Int,
    totalTasks: Int,
    completedTasks: Int,
    subjectCount: Int,
    email: String?,
    gamification: GamificationSnapshot,
    onTasksClick: () -> Unit,
    onFocusClick: () -> Unit,
    onLearningCoachClick: () -> Unit,
    onAIChatClick: () -> Unit,
    onProgressClick: () -> Unit = {},
    onProfileClick: () -> Unit = {},
    activeFocus: HomeDashboardController.ActiveFocus =
        HomeDashboardController.ActiveFocus(),
    preferredName: String? = null,
    photoUrl: String? = null,
    onMenuClick: () -> Unit = {}
) {
    val learnerName = preferredName
        ?.trim()
        ?.takeIf { it.isNotBlank() }
        ?: "Learner"

    val safeCompletedTasks = completedTasks.coerceAtLeast(0)
    val safeTotalTasks = totalTasks.coerceAtLeast(0)

    val pendingTasks =
        (safeTotalTasks - safeCompletedTasks).coerceAtLeast(0)

    val taskPercentage = if (safeTotalTasks > 0) {
        (safeCompletedTasks.toFloat() / safeTotalTasks)
            .coerceIn(0f, 1f)
    } else {
        0f
    }

    val nextMove = when {
        activeFocus.isActive -> {
            val subject = activeFocus.subjectName
                ?.takeIf { it.isNotBlank() }
                ?: "Independent study"

            val task = activeFocus.taskTitle
                ?.takeIf { it.isNotBlank() }

            val remaining =
                formatRemainingTime(activeFocus.remainingSeconds)

            Triple(
                when {
                    activeFocus.remainingSeconds <= 0 ->
                        "Your focus session has ended"

                    activeFocus.isPaused ->
                        "Resume your focus session"

                    else ->
                        "Continue your focus session"
                },
                buildString {
                    append(subject)

                    if (task != null) {
                        append(" • ")
                        append(task)
                    }

                    append("\n")

                    when {
                        activeFocus.remainingSeconds <= 0 ->
                            append("Your timer has reached zero. Open the session to finish it.")

                        activeFocus.isPaused ->
                            append("Your session is paused with $remaining remaining.")

                        else ->
                            append("$remaining remaining. Keep your attention on the current session.")
                    }
                },
                when {
                    activeFocus.remainingSeconds <= 0 ->
                        "View focus session"

                    activeFocus.isPaused ->
                        "Resume focus session"

                    else ->
                        "Continue focus session"
                }
            )
        }

        subjectCount <= 0 -> Triple(
            "Set up your learning journey",
            "Add your first subject or learning goal to begin building a personalized study plan.",
            "Start learning"
        )

        pendingTasks > 0 -> Triple(
            "Complete your pending tasks",
            "You have $pendingTasks unfinished task${if (pendingTasks == 1) "" else "s"}. Completing one will move your learning forward.",
            "View my tasks"
        )

        focusMinutes < 120 -> {
            val remainingMinutes =
                (120 - focusMinutes).coerceAtLeast(0)

            Triple(
                "Start a focused study session",
                "$remainingMinutes minutes remain to reach your daily focus goal of 120 minutes.",
                "Start focus session"
            )
        }

        else -> Triple(
            "Continue learning with AI",
            "Your daily focus goal is complete. Use your AI learning coach to strengthen your understanding and plan your next step.",
            "Open AI Learning Coach"
        )
    }

    val nextMoveAction: () -> Unit = when {
        activeFocus.isActive -> onFocusClick
        subjectCount <= 0 -> onLearningCoachClick
        pendingTasks > 0 -> onTasksClick
        focusMinutes < 120 -> onFocusClick
        else -> onLearningCoachClick
    }

    ScaiScreen(
        scrollable = true
    ) {
        ScaiTopBar(
            title = "Home",
            subtitle = "Your learning overview",
            onMenuClick = onMenuClick,
            actions = {
                ProfileAvatar(
                    name = learnerName,
                    email = email,
                    photoUrl = photoUrl,
                    onClick = onProfileClick
                )
            }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "${getGreeting()}, $learnerName",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 25.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(5.dp))

        Text(
            text = "SCAI is here to support your learning journey.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Your overview",
            description = "A quick look at today's progress"
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OverviewMetric(
                title = "Focus time",
                value = focusMinutes.coerceAtLeast(0).toString(),
                subtitle = "Minutes",
                modifier = Modifier.weight(1f)
            )

            OverviewMetric(
                title = "Sessions",
                value = focusSessions.coerceAtLeast(0).toString(),
                subtitle = "Today",
                modifier = Modifier.weight(1f)
            )

            OverviewMetric(
                title = "Subjects",
                value = subjectCount.coerceAtLeast(0).toString(),
                subtitle = "Added",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        ScaiCard {
            Text(
                text = "Task progress",
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "$safeCompletedTasks of $safeTotalTasks tasks completed",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )

                Text(
                    text = "${(taskPercentage * 100).toInt()}%",
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(taskPercentage)
                        .height(7.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurface)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Completed tasks",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )

                Text(
                    text = safeCompletedTasks.toString(),
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Your next move",
            description = "A suggested next step based on your activity"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScaiCard {
            Text(
                text = nextMove.first,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = nextMove.second,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
                lineHeight = 21.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            ScaiPrimaryButton(
                text = nextMove.third,
                onClick = nextMoveAction
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Learning activity",
            description = "Your focus and consistency"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScaiCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Daily focus",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = "${focusMinutes.coerceAtLeast(0)} min",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "Focus sessions",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = focusSessions.coerceAtLeast(0).toString(),
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            ScaiDivider()
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Your daily focus goal is 120 minutes.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            ScaiPrimaryButton(
                text = when {
                    activeFocus.isActive && activeFocus.isPaused ->
                        "Resume focus"

                    activeFocus.isActive ->
                        "Continue focus"

                    else ->
                        "Start focus session"
                },
                onClick = onFocusClick
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Your achievements",
            description = "Keep building your learning streak"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScaiCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "LEVEL ${gamification.level}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = "${gamification.totalXp} XP",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "Learning streak",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = "${gamification.streakDays} days",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            ScaiDivider()
            Spacer(modifier = Modifier.height(12.dp))

            val xpRequired =
                gamification.xpForNextLevel.coerceAtLeast(1)

            val currentLevelXp =
                gamification.xpInCurrentLevel.coerceIn(0, xpRequired)

            val xpProgress =
                currentLevelXp.toFloat() / xpRequired.toFloat()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Progress to next level",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )

                Text(
                    text = "$currentLevelXp / $xpRequired XP",
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(9.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(xpProgress)
                        .height(7.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurface)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "${gamification.achievements.size} achievements unlocked",
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(12.dp))

            ScaiPrimaryButton(
                text = "View progress",
                onClick = onProgressClick
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        ScaiSectionTitle(
            title = "Quick access"
        )

        Spacer(modifier = Modifier.height(12.dp))

        QuickActionRow(
            title = "My tasks",
            description = "View and manage your tasks",
            onClick = onTasksClick
        )

        QuickActionRow(
            title = "AI learning coach",
            description = "Plan and improve your learning",
            onClick = onLearningCoachClick
        )

        QuickActionRow(
            title = "AI chat",
            description = "Ask questions and explore ideas",
            onClick = onAIChatClick
        )

        Spacer(modifier = Modifier.height(28.dp))
    }
}

@Composable
private fun OverviewMetric(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    ScaiCard(
        modifier = modifier
    ) {
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(7.dp))

        Text(
            text = value,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = subtitle,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun QuickActionRow(
    title: String,
    description: String,
    onClick: () -> Unit
) {
    ScaiCard(
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = description,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }

            Text(
                text = "›",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 26.sp
            )
        }
    }

    Spacer(modifier = Modifier.height(9.dp))
}

@Composable
private fun ProfileAvatar(
    name: String,
    email: String?,
    photoUrl: String?,
    onClick: () -> Unit
) {
    var profileBitmap by remember(photoUrl) {
        mutableStateOf<android.graphics.Bitmap?>(null)
    }

    LaunchedEffect(photoUrl) {
        profileBitmap = withContext(Dispatchers.IO) {
            val validUrl = photoUrl
                ?.trim()
                ?.takeIf {
                    it.startsWith("https://") ||
                        it.startsWith("http://")
                }

            if (validUrl == null) {
                null
            } else {
                var connection: HttpURLConnection? = null

                try {
                    connection =
                        URL(validUrl).openConnection() as HttpURLConnection

                    connection.connectTimeout = 10000
                    connection.readTimeout = 10000
                    connection.instanceFollowRedirects = true

                    connection.inputStream.use { input ->
                        BitmapFactory.decodeStream(input)
                    }
                } catch (_: Exception) {
                    null
                } finally {
                    connection?.disconnect()
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        if (profileBitmap != null) {
            Image(
                bitmap = profileBitmap!!.asImageBitmap(),
                contentDescription = "Profile",
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        } else {
            Text(
                text = name.firstOrNull()
                    ?.uppercaseChar()
                    ?.toString()
                    ?: email
                        ?.substringBefore("@")
                        ?.firstOrNull()
                        ?.uppercaseChar()
                        ?.toString()
                    ?: "S",
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private fun getGreeting(): String {
    val hour = Calendar.getInstance()
        .get(Calendar.HOUR_OF_DAY)

    return when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..20 -> "Good evening"
        else -> "Good night"
    }
}

private fun formatRemainingTime(seconds: Int): String {
    val safeSeconds = seconds.coerceAtLeast(0)
    val minutes = safeSeconds / 60
    val remainingSeconds = safeSeconds % 60

    return String.format(
        "%02d:%02d",
        minutes,
        remainingSeconds
    )
}
