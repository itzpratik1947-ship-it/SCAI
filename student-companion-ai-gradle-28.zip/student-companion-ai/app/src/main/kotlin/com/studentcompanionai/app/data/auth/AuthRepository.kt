
package com.studentcompanionai.app.data.auth

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore =
        FirebaseFirestore.getInstance()
) {

    companion object {
        private const val TAG = "AuthRepository"

        private const val WEB_CLIENT_ID =
            "260052201037-3plm7cd18f9342k940meacfem457qmrd.apps.googleusercontent.com"
    }

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    suspend fun register(
        name: String,
        email: String,
        password: String
    ): FirebaseUser {
        require(name.isNotBlank()) { "Enter your name." }
        require(email.isNotBlank()) { "Enter your email." }
        require(password.length >= 6) {
            "Password must contain at least 6 characters."
        }

        val result = auth.createUserWithEmailAndPassword(
            email.trim(),
            password
        ).await()

        val user = result.user
            ?: error("Account created, but user information is unavailable.")

        try {
            ensureUserProfile(user, name.trim())
        } catch (e: Exception) {
            Log.e(TAG, "Profile creation failed", e)
            throw e
        }

        return user
    }

    suspend fun signIn(
        email: String,
        password: String
    ): FirebaseUser {
        require(email.isNotBlank()) { "Enter your email." }
        require(password.isNotBlank()) { "Enter your password." }

        val result = auth.signInWithEmailAndPassword(
            email.trim(),
            password
        ).await()

        val user = result.user
            ?: error("Sign-in succeeded, but user information is unavailable.")

        try {
            ensureUserProfile(user)
        } catch (e: Exception) {
            Log.e(TAG, "Profile repair failed", e)
            throw e
        }

        return user
    }

    suspend fun signInWithGoogle(
        context: Context
    ): FirebaseUser {

        val credentialManager = CredentialManager.create(context)

        val googleOption = GetGoogleIdOption.Builder()
            .setServerClientId(WEB_CLIENT_ID)
            .setFilterByAuthorizedAccounts(false)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleOption)
            .build()

        val result = credentialManager.getCredential(
            context = context,
            request = request
        )

        val credential = result.credential

        if (
            credential !is CustomCredential ||
            credential.type !=
            GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            error("Google sign-in returned an unsupported credential.")
        }

        val googleCredential =
            GoogleIdTokenCredential.createFrom(credential.data)

        val firebaseCredential = GoogleAuthProvider.getCredential(
            googleCredential.idToken,
            null
        )

        val authResult = auth.signInWithCredential(
            firebaseCredential
        ).await()

        val user = authResult.user
            ?: error("Google sign-in succeeded, but user information is unavailable.")

        try {
            ensureUserProfile(user, googleCredential.displayName)
        } catch (e: Exception) {
            Log.e(TAG, "Google profile creation failed", e)
            throw e
        }

        return user
    }

    private suspend fun ensureUserProfile(
        user: FirebaseUser,
        suppliedName: String? = null
    ) {
        val email = user.email
            ?: error("Your account has no email address.")

        val profileRef = firestore.collection("users")
            .document(user.uid)

        val snapshot = profileRef.get().await()

        if (snapshot.exists()) {
            profileRef.update(
                mapOf(
                    "email" to email,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            val fallbackName = email.substringBefore("@")

            val profile = mapOf(
                "uid" to user.uid,
                "name" to (
                    suppliedName
                        ?: user.displayName
                        ?: fallbackName
                ),
                "email" to email,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            profileRef.set(profile).await()
        }
    }

    suspend fun sendPasswordReset(email: String) {
        require(email.isNotBlank()) {
            "Enter your email address."
        }

        auth.sendPasswordResetEmail(email.trim()).await()
    }

    fun signOut() {
        auth.signOut()
    }
}
