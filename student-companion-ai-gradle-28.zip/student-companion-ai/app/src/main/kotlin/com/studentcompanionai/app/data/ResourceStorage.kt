
package com.studentcompanionai.app.data

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

class ResourceStorage(
    private val accountUid: String,
    private val firestore: FirebaseFirestore =
        FirebaseFirestore.getInstance()
) {

    init {
        require(accountUid.isNotBlank()) {
            "Firebase account UID cannot be blank."
        }
    }

    private val userResourceData
        get() = firestore
            .collection("users")
            .document(accountUid)
            .collection("resource_data")

    private val bookmarks
        get() = userResourceData.document("bookmarks")
            .collection("items")

    private val history
        get() = userResourceData.document("history")
            .collection("items")

    // --------------------------------------------------
    // SAVE RESOURCE
    // --------------------------------------------------

    suspend fun saveResource(
        resource: ResourceItem,
        linkedPlanId: String? = null,
        linkedActivityId: String? = null
    ) {
        validateResource(resource)

        val document = bookmarks.document(resource.id)
        val existing = document.get().await()

        val data = resource.toFirestoreMap().toMutableMap().apply {

            put(
                "savedAt",
                if (existing.exists()) {
                    existing.get("savedAt")
                        ?: FieldValue.serverTimestamp()
                } else {
                    FieldValue.serverTimestamp()
                }
            )

            linkedPlanId?.let {
                put("linkedPlanId", it)
            }

            linkedActivityId?.let {
                put("linkedActivityId", it)
            }
        }

        document.set(data, SetOptions.merge()).await()
    }

    // --------------------------------------------------
    // REMOVE BOOKMARK
    // --------------------------------------------------

    suspend fun removeResource(resourceId: String) {
        require(resourceId.isNotBlank()) {
            "Resource ID cannot be blank."
        }

        bookmarks.document(resourceId)
            .delete()
            .await()
    }

    // --------------------------------------------------
    // CHECK BOOKMARK STATUS
    // --------------------------------------------------

    suspend fun isResourceSaved(resourceId: String): Boolean {
        if (resourceId.isBlank()) return false

        return bookmarks.document(resourceId)
            .get()
            .await()
            .exists()
    }

    // --------------------------------------------------
    // GET SAVED RESOURCES
    // --------------------------------------------------

    suspend fun getSavedResources(): List<SavedResource> {

        val snapshot = bookmarks
            .get()
            .await()

        return snapshot.documents
            .mapNotNull { document ->
                document.toSavedResource()
            }
            .sortedByDescending { it.savedAt }
    }

    // --------------------------------------------------
    // RECORD RESOURCE OPENED
    // --------------------------------------------------

    suspend fun recordResourceOpened(resource: ResourceItem) {

        validateResource(resource)

        val document = history.document(resource.id)

        val data = resource.toFirestoreMap().toMutableMap().apply {
            put("lastOpenedAt", FieldValue.serverTimestamp())
            put("openCount", FieldValue.increment(1))
        }

        document.set(data, SetOptions.merge()).await()
    }

    // --------------------------------------------------
    // GET RECENTLY OPENED RESOURCES
    // --------------------------------------------------

    suspend fun getRecentlyOpenedResources(
        limit: Long = 30
    ): List<SavedResource> {

        val snapshot = history
            .orderBy("lastOpenedAt", Query.Direction.DESCENDING)
            .limit(limit.coerceIn(1, 100))
            .get()
            .await()

        return snapshot.documents.mapNotNull { document ->

            val resource = document.toResourceItem()
                ?: return@mapNotNull null

            val lastOpenedAt = document
                .getTimestamp("lastOpenedAt")
                ?.toDate()
                ?.time ?: 0L

            SavedResource(
                resource = resource,
                savedAt = 0L,
                lastOpenedAt = lastOpenedAt,
                openCount = (document.getLong("openCount") ?: 0L)
                    .toInt(),
                linkedPlanId = null,
                linkedActivityId = null
            )
        }
    }

    // --------------------------------------------------
    // CLEAR BROWSING HISTORY
    // --------------------------------------------------

    suspend fun clearBrowsingHistory() {

        val snapshot = history.get().await()

        if (snapshot.isEmpty) return

        val batch = firestore.batch()

        snapshot.documents.forEach { document ->
            batch.delete(document.reference)
        }

        batch.commit().await()
    }

    // --------------------------------------------------
    // CLEAR ALL BOOKMARKS
    // --------------------------------------------------

    suspend fun clearSavedResources() {

        val snapshot = bookmarks.get().await()

        if (snapshot.isEmpty) return

        val batch = firestore.batch()

        snapshot.documents.forEach { document ->
            batch.delete(document.reference)
        }

        batch.commit().await()
    }

    // --------------------------------------------------
    // RESOURCE VALIDATION
    // --------------------------------------------------

    private fun validateResource(resource: ResourceItem) {

        require(resource.id.isNotBlank()) {
            "Resource ID cannot be blank."
        }

        require(resource.title.isNotBlank()) {
            "Resource title cannot be blank."
        }

        require(resource.hasValidUrl) {
            "Resource URL must be a valid HTTP or HTTPS URL."
        }
    }

    // --------------------------------------------------
    // FIRESTORE SERIALIZATION
    // --------------------------------------------------

    private fun ResourceItem.toFirestoreMap(): Map<String, Any> {

        return mapOf(
            "id" to id,
            "title" to title,
            "url" to url,
            "description" to description,
            "type" to type.name,
            "provider" to provider,
            "thumbnailUrl" to thumbnailUrl,
            "author" to author,
            "languageCode" to languageCode,
            "subject" to subject,
            "topic" to topic,
            "difficulty" to difficulty,
            "durationSeconds" to durationSeconds,
            "isFree" to isFree,
            "publishedAt" to publishedAt,
            "retrievedAt" to retrievedAt,
            "relevanceScore" to relevanceScore
        )
    }

    // --------------------------------------------------
    // FIRESTORE DESERIALIZATION
    // --------------------------------------------------

    private fun DocumentSnapshot.toResourceItem(): ResourceItem? {

        val resourceId = getString("id")
            ?: id

        val title = getString("title")
            ?: return null

        val url = getString("url")
            ?: return null

        val type = try {
            ResourceType.valueOf(
                getString("type") ?: "WEBSITE"
            )
        } catch (_: Exception) {
            ResourceType.WEBSITE
        }

        return ResourceItem(
            id = resourceId,
            title = title,
            url = url,
            description = getString("description") ?: "",
            type = type,
            provider = getString("provider") ?: "",
            thumbnailUrl = getString("thumbnailUrl") ?: "",
            author = getString("author") ?: "",
            languageCode = getString("languageCode") ?: "en",
            subject = getString("subject") ?: "",
            topic = getString("topic") ?: "",
            difficulty = getString("difficulty") ?: "",
            durationSeconds = getLong("durationSeconds") ?: 0L,
            isFree = getBoolean("isFree") ?: false,
            publishedAt = getString("publishedAt") ?: "",
            retrievedAt = getLong("retrievedAt")
                ?: System.currentTimeMillis(),
            relevanceScore = getDouble("relevanceScore") ?: 0.0
        )
    }

    // --------------------------------------------------
    // SAVED RESOURCE MAPPING
    // --------------------------------------------------

    private fun DocumentSnapshot.toSavedResource(): SavedResource? {

        val resource = toResourceItem()
            ?: return null

        return SavedResource(
            resource = resource,
            savedAt = getTimestamp("savedAt")
                ?.toDate()?.time ?: 0L,
            lastOpenedAt = getLong("lastOpenedAt") ?: 0L,
            openCount = (getLong("openCount") ?: 0L).toInt(),
            linkedPlanId = getString("linkedPlanId"),
            linkedActivityId = getString("linkedActivityId")
        )
    }
}
